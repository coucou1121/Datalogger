/****************************************************************************
** Meta object code from reading C++ file 'settingTriggerSetting.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "settingTriggerSetting.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settingTriggerSetting.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SettingTriggerSetting_t {
    QByteArrayData data[48];
    char stringdata[1336];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SettingTriggerSetting_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SettingTriggerSetting_t qt_meta_stringdata_SettingTriggerSetting = {
    {
QT_MOC_LITERAL(0, 0, 21),
QT_MOC_LITERAL(1, 22, 29),
QT_MOC_LITERAL(2, 52, 0),
QT_MOC_LITERAL(3, 53, 29),
QT_MOC_LITERAL(4, 83, 29),
QT_MOC_LITERAL(5, 113, 29),
QT_MOC_LITERAL(6, 143, 32),
QT_MOC_LITERAL(7, 176, 8),
QT_MOC_LITERAL(8, 185, 32),
QT_MOC_LITERAL(9, 218, 32),
QT_MOC_LITERAL(10, 251, 32),
QT_MOC_LITERAL(11, 284, 28),
QT_MOC_LITERAL(12, 313, 5),
QT_MOC_LITERAL(13, 319, 28),
QT_MOC_LITERAL(14, 348, 28),
QT_MOC_LITERAL(15, 377, 28),
QT_MOC_LITERAL(16, 406, 28),
QT_MOC_LITERAL(17, 435, 28),
QT_MOC_LITERAL(18, 464, 33),
QT_MOC_LITERAL(19, 498, 5),
QT_MOC_LITERAL(20, 504, 33),
QT_MOC_LITERAL(21, 538, 33),
QT_MOC_LITERAL(22, 572, 33),
QT_MOC_LITERAL(23, 606, 33),
QT_MOC_LITERAL(24, 640, 33),
QT_MOC_LITERAL(25, 674, 11),
QT_MOC_LITERAL(26, 686, 12),
QT_MOC_LITERAL(27, 699, 10),
QT_MOC_LITERAL(28, 710, 30),
QT_MOC_LITERAL(29, 741, 30),
QT_MOC_LITERAL(30, 772, 30),
QT_MOC_LITERAL(31, 803, 30),
QT_MOC_LITERAL(32, 834, 30),
QT_MOC_LITERAL(33, 865, 30),
QT_MOC_LITERAL(34, 896, 30),
QT_MOC_LITERAL(35, 927, 30),
QT_MOC_LITERAL(36, 958, 29),
QT_MOC_LITERAL(37, 988, 29),
QT_MOC_LITERAL(38, 1018, 29),
QT_MOC_LITERAL(39, 1048, 29),
QT_MOC_LITERAL(40, 1078, 29),
QT_MOC_LITERAL(41, 1108, 29),
QT_MOC_LITERAL(42, 1138, 32),
QT_MOC_LITERAL(43, 1171, 32),
QT_MOC_LITERAL(44, 1204, 32),
QT_MOC_LITERAL(45, 1237, 32),
QT_MOC_LITERAL(46, 1270, 32),
QT_MOC_LITERAL(47, 1303, 32)
    },
    "SettingTriggerSetting\0"
    "_pushButtonRangeAI1WasChanged\0\0"
    "_pushButtonRangeAI2WasChanged\0"
    "_pushButtonRangeAI3WasChanged\0"
    "_pushButtonRangeAI4WasChanged\0"
    "_pushButtonRangeAI1TXTWasChanged\0"
    "rangeTxt\0_pushButtonRangeAI2TXTWasChanged\0"
    "_pushButtonRangeAI3TXTWasChanged\0"
    "_pushButtonRangeAI4TXTWasChanged\0"
    "_pushButtonEdgeDI1WasChanged\0eEdge\0"
    "_pushButtonEdgeDI2WasChanged\0"
    "_pushButtonEdgeDI3WasChanged\0"
    "_pushButtonEdgeDI4WasChanged\0"
    "_pushButtonEdgeAI1WasChanged\0"
    "_pushButtonEdgeAI2WasChanged\0"
    "_doubleSpinBoxDI1_valueWasChanged\0"
    "value\0_doubleSpinBoxDI2_valueWasChanged\0"
    "_doubleSpinBoxDI3_valueWasChanged\0"
    "_doubleSpinBoxDI4_valueWasChanged\0"
    "_doubleSpinBoxAI1_valueWasChanged\0"
    "_doubleSpinBoxAI2_valueWasChanged\0"
    "_btSelected\0buttonNumber\0btSelected\0"
    "on_pushButtonRangeDI1_released\0"
    "on_pushButtonRangeDI2_released\0"
    "on_pushButtonRangeDI3_released\0"
    "on_pushButtonRangeDI4_released\0"
    "on_pushButtonRangeAI1_released\0"
    "on_pushButtonRangeAI2_released\0"
    "on_pushButtonRangeAI3_released\0"
    "on_pushButtonRangeAI4_released\0"
    "on_pushButtonEdgeDI1_released\0"
    "on_pushButtonEdgeDI2_released\0"
    "on_pushButtonEdgeDI3_released\0"
    "on_pushButtonEdgeDI4_released\0"
    "on_pushButtonEdgeAI1_released\0"
    "on_pushButtonEdgeAI2_released\0"
    "on_doubleSpinBoxDI1_valueChanged\0"
    "on_doubleSpinBoxDI2_valueChanged\0"
    "on_doubleSpinBoxDI3_valueChanged\0"
    "on_doubleSpinBoxDI4_valueChanged\0"
    "on_doubleSpinBoxAI1_valueChanged\0"
    "on_doubleSpinBoxAI2_valueChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SettingTriggerSetting[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      41,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      20,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  219,    2, 0x06 /* Public */,
       3,    0,  220,    2, 0x06 /* Public */,
       4,    0,  221,    2, 0x06 /* Public */,
       5,    0,  222,    2, 0x06 /* Public */,
       6,    1,  223,    2, 0x06 /* Public */,
       8,    1,  226,    2, 0x06 /* Public */,
       9,    1,  229,    2, 0x06 /* Public */,
      10,    1,  232,    2, 0x06 /* Public */,
      11,    1,  235,    2, 0x06 /* Public */,
      13,    1,  238,    2, 0x06 /* Public */,
      14,    1,  241,    2, 0x06 /* Public */,
      15,    1,  244,    2, 0x06 /* Public */,
      16,    1,  247,    2, 0x06 /* Public */,
      17,    1,  250,    2, 0x06 /* Public */,
      18,    1,  253,    2, 0x06 /* Public */,
      20,    1,  256,    2, 0x06 /* Public */,
      21,    1,  259,    2, 0x06 /* Public */,
      22,    1,  262,    2, 0x06 /* Public */,
      23,    1,  265,    2, 0x06 /* Public */,
      24,    1,  268,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      25,    2,  271,    2, 0x0a /* Public */,
      28,    0,  276,    2, 0x08 /* Private */,
      29,    0,  277,    2, 0x08 /* Private */,
      30,    0,  278,    2, 0x08 /* Private */,
      31,    0,  279,    2, 0x08 /* Private */,
      32,    0,  280,    2, 0x08 /* Private */,
      33,    0,  281,    2, 0x08 /* Private */,
      34,    0,  282,    2, 0x08 /* Private */,
      35,    0,  283,    2, 0x08 /* Private */,
      36,    0,  284,    2, 0x08 /* Private */,
      37,    0,  285,    2, 0x08 /* Private */,
      38,    0,  286,    2, 0x08 /* Private */,
      39,    0,  287,    2, 0x08 /* Private */,
      40,    0,  288,    2, 0x08 /* Private */,
      41,    0,  289,    2, 0x08 /* Private */,
      42,    1,  290,    2, 0x08 /* Private */,
      43,    1,  293,    2, 0x08 /* Private */,
      44,    1,  296,    2, 0x08 /* Private */,
      45,    1,  299,    2, 0x08 /* Private */,
      46,    1,  302,    2, 0x08 /* Private */,
      47,    1,  305,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::QString,    7,
    QMetaType::Void, QMetaType::UChar,   12,
    QMetaType::Void, QMetaType::UChar,   12,
    QMetaType::Void, QMetaType::UChar,   12,
    QMetaType::Void, QMetaType::UChar,   12,
    QMetaType::Void, QMetaType::UChar,   12,
    QMetaType::Void, QMetaType::UChar,   12,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,

 // slots: parameters
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   26,   27,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,
    QMetaType::Void, QMetaType::Double,   19,

       0        // eod
};

void SettingTriggerSetting::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SettingTriggerSetting *_t = static_cast<SettingTriggerSetting *>(_o);
        switch (_id) {
        case 0: _t->_pushButtonRangeAI1WasChanged(); break;
        case 1: _t->_pushButtonRangeAI2WasChanged(); break;
        case 2: _t->_pushButtonRangeAI3WasChanged(); break;
        case 3: _t->_pushButtonRangeAI4WasChanged(); break;
        case 4: _t->_pushButtonRangeAI1TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->_pushButtonRangeAI2TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->_pushButtonRangeAI3TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 7: _t->_pushButtonRangeAI4TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 8: _t->_pushButtonEdgeDI1WasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 9: _t->_pushButtonEdgeDI2WasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 10: _t->_pushButtonEdgeDI3WasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 11: _t->_pushButtonEdgeDI4WasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 12: _t->_pushButtonEdgeAI1WasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 13: _t->_pushButtonEdgeAI2WasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 14: _t->_doubleSpinBoxDI1_valueWasChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 15: _t->_doubleSpinBoxDI2_valueWasChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 16: _t->_doubleSpinBoxDI3_valueWasChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 17: _t->_doubleSpinBoxDI4_valueWasChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 18: _t->_doubleSpinBoxAI1_valueWasChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 19: _t->_doubleSpinBoxAI2_valueWasChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 20: _t->_btSelected((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 21: _t->on_pushButtonRangeDI1_released(); break;
        case 22: _t->on_pushButtonRangeDI2_released(); break;
        case 23: _t->on_pushButtonRangeDI3_released(); break;
        case 24: _t->on_pushButtonRangeDI4_released(); break;
        case 25: _t->on_pushButtonRangeAI1_released(); break;
        case 26: _t->on_pushButtonRangeAI2_released(); break;
        case 27: _t->on_pushButtonRangeAI3_released(); break;
        case 28: _t->on_pushButtonRangeAI4_released(); break;
        case 29: _t->on_pushButtonEdgeDI1_released(); break;
        case 30: _t->on_pushButtonEdgeDI2_released(); break;
        case 31: _t->on_pushButtonEdgeDI3_released(); break;
        case 32: _t->on_pushButtonEdgeDI4_released(); break;
        case 33: _t->on_pushButtonEdgeAI1_released(); break;
        case 34: _t->on_pushButtonEdgeAI2_released(); break;
        case 35: _t->on_doubleSpinBoxDI1_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 36: _t->on_doubleSpinBoxDI2_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 37: _t->on_doubleSpinBoxDI3_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 38: _t->on_doubleSpinBoxDI4_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 39: _t->on_doubleSpinBoxAI1_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 40: _t->on_doubleSpinBoxAI2_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SettingTriggerSetting::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI1WasChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI2WasChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI3WasChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI4WasChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI1TXTWasChanged)) {
                *result = 4;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI2TXTWasChanged)) {
                *result = 5;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI3TXTWasChanged)) {
                *result = 6;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonRangeAI4TXTWasChanged)) {
                *result = 7;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonEdgeDI1WasChanged)) {
                *result = 8;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonEdgeDI2WasChanged)) {
                *result = 9;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonEdgeDI3WasChanged)) {
                *result = 10;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonEdgeDI4WasChanged)) {
                *result = 11;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonEdgeAI1WasChanged)) {
                *result = 12;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_pushButtonEdgeAI2WasChanged)) {
                *result = 13;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_doubleSpinBoxDI1_valueWasChanged)) {
                *result = 14;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_doubleSpinBoxDI2_valueWasChanged)) {
                *result = 15;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_doubleSpinBoxDI3_valueWasChanged)) {
                *result = 16;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_doubleSpinBoxDI4_valueWasChanged)) {
                *result = 17;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_doubleSpinBoxAI1_valueWasChanged)) {
                *result = 18;
            }
        }
        {
            typedef void (SettingTriggerSetting::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerSetting::_doubleSpinBoxAI2_valueWasChanged)) {
                *result = 19;
            }
        }
    }
}

const QMetaObject SettingTriggerSetting::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_SettingTriggerSetting.data,
      qt_meta_data_SettingTriggerSetting,  qt_static_metacall, 0, 0}
};


const QMetaObject *SettingTriggerSetting::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SettingTriggerSetting::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SettingTriggerSetting.stringdata))
        return static_cast<void*>(const_cast< SettingTriggerSetting*>(this));
    return QFrame::qt_metacast(_clname);
}

int SettingTriggerSetting::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 41)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 41;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 41)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 41;
    }
    return _id;
}

// SIGNAL 0
void SettingTriggerSetting::_pushButtonRangeAI1WasChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 0, 0);
}

// SIGNAL 1
void SettingTriggerSetting::_pushButtonRangeAI2WasChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 1, 0);
}

// SIGNAL 2
void SettingTriggerSetting::_pushButtonRangeAI3WasChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, 0);
}

// SIGNAL 3
void SettingTriggerSetting::_pushButtonRangeAI4WasChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 3, 0);
}

// SIGNAL 4
void SettingTriggerSetting::_pushButtonRangeAI1TXTWasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SettingTriggerSetting::_pushButtonRangeAI2TXTWasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SettingTriggerSetting::_pushButtonRangeAI3TXTWasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SettingTriggerSetting::_pushButtonRangeAI4TXTWasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void SettingTriggerSetting::_pushButtonEdgeDI1WasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void SettingTriggerSetting::_pushButtonEdgeDI2WasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void SettingTriggerSetting::_pushButtonEdgeDI3WasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void SettingTriggerSetting::_pushButtonEdgeDI4WasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void SettingTriggerSetting::_pushButtonEdgeAI1WasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void SettingTriggerSetting::_pushButtonEdgeAI2WasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 13, _a);
}

// SIGNAL 14
void SettingTriggerSetting::_doubleSpinBoxDI1_valueWasChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 14, _a);
}

// SIGNAL 15
void SettingTriggerSetting::_doubleSpinBoxDI2_valueWasChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 15, _a);
}

// SIGNAL 16
void SettingTriggerSetting::_doubleSpinBoxDI3_valueWasChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void SettingTriggerSetting::_doubleSpinBoxDI4_valueWasChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void SettingTriggerSetting::_doubleSpinBoxAI1_valueWasChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void SettingTriggerSetting::_doubleSpinBoxAI2_valueWasChanged(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}
QT_END_MOC_NAMESPACE
