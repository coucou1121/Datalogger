#ifndef SETTINGWINDOW_H
#define SETTINGWINDOW_H

//*

/**
  * \file settingWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief windows for the setting menu
  */

#include <QWidget>
#include "commonStyle.h"
#include "triggerFunctions.h"

namespace Ui {
class SettingWindow;
}

class SettingWindow : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn explicit SettingWindow(QWidget *parent = 0)
      * \brief constructor for SettingWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit SettingWindow(QWidget *parent = 0);

    /**
      * \fn  ~SettingWindow()
      * \brief destructor for SettingWindow
      */
    ~SettingWindow();

    /**
      * \fn bool triggerFunctionEnable() const
      * \brief Getter for triggerFunctionEnable attribute
      * \return a boolean
      */
    bool triggerFunctionEnable() const;

    /**
      * \fn TriggerFunctions *getTriggerFuntion()
      * \brief get the trigger function setting
      * use to synchronize the widget
      * \return a TriggerFunctions
      */
    TriggerFunctions *getTriggerFuntion();

    //check if there is minimum one selected trace
    //check if there is minimum one selected trace
    /**
      * \fn void _checkIfAreSelectedTrace()
      * \brief check if there is minimum one selected trace
      * \return void : nothing
      */
    void checkIfAreSelectedTrace();

private:
    Ui::SettingWindow *ui;
//    CommonStyle _myStyle;

    //setup signal and slot
    /**
      * \fn  void _setupSignalAndSlot()
      * \brief setup signal and slot for the widget
      * \return void : nothing
      */
    void _setupSignalAndSlot();

    bool _triggerFunctionEnable;

    //trigger function setting
    TriggerFunctions *_triggerFunction;

    //trigger setting
    TriggerFunctions *_triggerSetting;

    //double to int converter
    /**
      * \fn  quint8 _doubleToQint8(double value, GlobalEnumatedAndExtern::eRangeValue range)
      * \brief converter from double to quint8 value
      * \return a quint8
      */
    quint8 _doubleToQint8(double value, GlobalEnumatedAndExtern::eRangeValue range);

public slots:
    void _received_NbFrameSavedChanged(quint64 nbFrameChanged);
    void _received_SizeFrameChange(int frameSize);
    void _received_FTDIBaudrateChange(int FTDIBaudrate);
    void _received_percentPreTriggerChanged(double percent);

//    void enableWindows(bool enableState);

    void pushButtonRangeAI1_changeRange();
    void pushButtonRangeAI2_changeRange();
    void pushButtonRangeAI3_changeRange();
    void pushButtonRangeAI4_changeRange();

    void pushButtonEdgeDI1_changeEdge(quint8 eEdge);
    void pushButtonEdgeDI2_changeEdge(quint8 eEdge);
    void pushButtonEdgeDI3_changeEdge(quint8 eEdge);
    void pushButtonEdgeDI4_changeEdge(quint8 eEdge);
    void pushButtonEdgeAI1_changeEdge(quint8 eEdge);
    void pushButtonEdgeAI2_changeEdge(quint8 eEdge);

    void doubleSpinBoxDI1_changeValue(double value);
    void doubleSpinBoxDI2_changeValue(double value);
    void doubleSpinBoxDI3_changeValue(double value);
    void doubleSpinBoxDI4_changeValue(double value);
    void doubleSpinBoxAI1_changeValue(double value);
    void doubleSpinBoxAI2_changeValue(double value);

    void comboBoxTopLeft_changeCurrentIndex(quint8 index);
    void comboBoxTopRight_changeCurrentIndex(quint8 index);
    void comboBoxBottomLeft_changeCurrentIndex(quint8 index);
    void comboBoxBottomRight_changeCurrentIndex(quint8 index);
    void comboBoxTopMiddle_changeCurrentIndex(quint8 index);
    void comboBoxMiddle_changeCurrentIndex(quint8 index);
    void comboBoxBottomMiddle_changeCurrentIndex(quint8 index);

private slots:
    void _received_AddTraceFromChannelSelection(quint8 traceNumber);
    void _received_RemoveTraceFromChannelSelection(quint8 traceNumber);

    void _received_errorNoSelectedTrace(quint8 errorNumber, bool active);
    void _received_errorNoSectedTriggerTrace(quint8 errorNumber,bool active);
    void _received_errorFrequencyToLow(quint8 errorNumber, bool active);
    void _received_errorWrongEquation(quint8 errorNumber,bool active);

    void _received_pushButtonRangeAI1Changed();
    void _received_pushButtonRangeAI2Changed();
    void _received_pushButtonRangeAI3Changed();
    void _received_pushButtonRangeAI4Changed();
    void _received_pushButtonRangeAI1TXTWasChanged(QString rangeTXT);
    void _received_pushButtonRangeAI2TXTWasChanged(QString rangeTXT);
    void _received_pushButtonRangeAI3TXTWasChanged(QString rangeTXT);
    void _received_pushButtonRangeAI4TXTWasChanged(QString rangeTXT);

    void _received_pushButtonEdgeDI1Changed(quint8 eEdge);
    void _received_pushButtonEdgeDI2Changed(quint8 eEdge);
    void _received_pushButtonEdgeDI3Changed(quint8 eEdge);
    void _received_pushButtonEdgeDI4Changed(quint8 eEdge);
    void _received_pushButtonEdgeAI1Changed(quint8 eEdge);
    void _received_pushButtonEdgeAI2Changed(quint8 eEdge);

    void _received_doubleSpinBoxDI1_valueChanged(double value);
    void _received_doubleSpinBoxDI2_valueChanged(double value);
    void _received_doubleSpinBoxDI3_valueChanged(double value);
    void _received_doubleSpinBoxDI4_valueChanged(double value);
    void _received_doubleSpinBoxAI1_valueChanged(double value);
    void _received_doubleSpinBoxAI2_valueChanged(double value);

    void _received_ComboBoxTopLeft_currentIndexChanged(quint8 index);
    void _received_ComboBoxTopRight_currentIndexChanged(quint8 index);
    void _received_ComboBoxBottomLeft_currentIndexChanged(quint8 index);
    void _received_ComboBoxBottomRight_currentIndexChanged(quint8 index);
    void _received_ComboBoxTopMiddle_currentIndexChanged(quint8 index);
    void _received_ComboBoxMiddle_currentIndexChanged(quint8 index);
    void _received_ComboBoxBottomMiddle_currentIndexChanged(quint8 index);

signals:
    void _addTraceInTriggerMenu(quint8 traceNumber);
    void _removeTraceInTriggerMenu(quint8 traceNumber);
    void _addTraceInDisplayMenu(quint8 traceNumber);
    void _removeTraceInDisplayMenu(quint8 traceNumber);
    void _nbFrameSavedChange(quint64 nbFrameChanges);
    void _sizeFrameChange(int frameSize);
    void _FTDIBaudrateChange(int FTDIBaudrate);
    void _percentPreTriggerWasChanged(double percent);

    void _errorNoSelectedTrace(quint8 errorNumber, bool active);
    void _errorNoSelectedTriggerTrace(quint8 errorNumber, bool active);
    void _errorFrequencyToLow(quint8 errorNumber,bool active);
    void _errorWrongEquation(quint8 errorNumber,bool active);

    void _pushButtonRangeAI1WasChangedFromSettingMenu();
    void _pushButtonRangeAI2WasChangedFromSettingMenu();
    void _pushButtonRangeAI3WasChangedFromSettingMenu();
    void _pushButtonRangeAI4WasChangedFromSettingMenu();
    void _pushButtonRangeTXTAI1WasChanged(QString rangeTXT);
    void _pushButtonRangeTXTAI2WasChanged(QString rangeTXT);
    void _pushButtonRangeTXTAI3WasChanged(QString rangeTXT);
    void _pushButtonRangeTXTAI4WasChanged(QString rangeTXT);


    void _pushButtonEdgeDI1WasChangedFromSettingMenu(quint8 eEdge);
    void _pushButtonEdgeDI2WasChangedFromSettingMenu(quint8 eEdge);
    void _pushButtonEdgeDI3WasChangedFromSettingMenu(quint8 eEdge);
    void _pushButtonEdgeDI4WasChangedFromSettingMenu(quint8 eEdge);
    void _pushButtonEdgeAI1WasChangedFromSettingMenu(quint8 eEdge);
    void _pushButtonEdgeAI2WasChangedFromSettingMenu(quint8 eEdge);

    void _doubleSpinBoxDI1_valueWasChangedFromSettingMenu(double value);
    void _doubleSpinBoxDI2_valueWasChangedFromSettingMenu(double value);
    void _doubleSpinBoxDI3_valueWasChangedFromSettingMenu(double value);
    void _doubleSpinBoxDI4_valueWasChangedFromSettingMenu(double value);
    void _doubleSpinBoxAI1_valueWasChangedFromSettingMenu(double value);
    void _doubleSpinBoxAI2_valueWasChangedFromSettingMenu(double value);

    void _comboBoxTopLeft_currentIndexWasChanged(quint8 index);
    void _comboBoxTopRight_currentIndexWasChanged(quint8 index);
    void _comboBoxBottomLeft_currentIndexWasChanged(quint8 index);
    void _comboBoxBottomRight_currentIndexWasChanged(quint8 index);
    void _comboBoxTopMiddle_currentIndexWasChanged(quint8 index);
    void _comboBoxMiddle_currentIndexWasChanged(quint8 index);
    void _comboBoxBottomMiddle_currentIndexWasChanged(quint8 index);
};

#endif // SETTINGWINDOW_H
