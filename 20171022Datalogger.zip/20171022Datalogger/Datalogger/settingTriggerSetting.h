#ifndef SETTINGTRIGGERSETTING_H
#define SETTINGTRIGGERSETTING_H


/**
  * \file settingTriggerSetting.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Frame in setting menu for the trigger setting
  */


#include <QDebug>
#include <QFrame>
#include <QPushButton>
#include "commonStyle.h"
#include "globalEnumatedAndExtern.h"
#include "triggerFunctions.h"


namespace Ui {
class SettingTriggerSetting;
}

class SettingTriggerSetting : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn  explicit SettingTriggerSetting(QWidget *parent = 0)
      * \brief constructor for SettingTriggerSetting
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit SettingTriggerSetting(QWidget *parent = 0);

    /**
      * \fn  ~SettingTriggerSetting()
      * \brief destructor for SettingTriggerSetting
      */
    ~SettingTriggerSetting();

    //change range selection
    /**
      * \fn  pushButtonRangeAI1_ChangeRange()
      * \brief change the range type and text for AI1 channel
      * use to synchronize the widget
      * \return void : nothing
      */
    void pushButtonRangeAI1_ChangeRange();

    /**
      * \fn  pushButtonRangeAI2_ChangeRange()
      * \brief change the range type and text for AI2 channel
      * use to synchronize the widget
      * \return void : nothing
      */
    void pushButtonRangeAI2_ChangeRange();

    /**
      * \fn  pushButtonRangeAI3_ChangeRange()
      * \brief change the range type and text for AI3 channel
      * use to synchronize the widget
      * \return void : nothing
      */
    void pushButtonRangeAI3_ChangeRange();

    /**
      * \fn  pushButtonRangeAI4_ChangeRange()
      * \brief change the range type and text for AI4 channel
      * use to synchronize the widget
      * \return void : nothing
      */
    void pushButtonRangeAI4_ChangeRange();

    //change edge selection
    /**
      * \fn  pushButtonEdgeDI1_changeEdge(quint8 eEdge)
      * \brief change the edge type and icon for DI1 channel
      * use to synchronize the widget
      * \param[in] eEdge is the type of edge for the DI1 channel
      * \return void : nothing
      */
    void pushButtonEdgeDI1_changeEdge(quint8 eEdge);

    /**
      * \fn  pushButtonEdgeDI1_changeEdge(quint8 eEdge)
      * \brief change the edge type and icon for DI2 channel
      * use to synchronize the widget
      * \param[in] eEdge is the type of edge for the DI2 channel
      * \return void : nothing
      */
    void pushButtonEdgeDI2_changeEdge(quint8 eEdge);

    /**
      * \fn  pushButtonEdgeDI1_changeEdge(quint8 eEdge)
      * \brief change the edge type and icon for DI13 channel
      * use to synchronize the widget
      * \param[in] eEdge is the type of edge for the DI3 channel
      * \return void : nothing
      */
    void pushButtonEdgeDI3_changeEdge(quint8 eEdge);

    /**
      * \fn  pushButtonEdgeDI1_changeEdge(quint8 eEdge)
      * \brief change the edge type and icon for DI4 channel
      * use to synchronize the widget
      * \param[in] eEdge is the type of edge for the DI4 channel
      * \return void : nothing
      */
    void pushButtonEdgeDI4_changeEdge(quint8 eEdge);

    /**
      * \fn  pushButtonEdgeDI1_changeEdge(quint8 eEdge)
      * \brief change the edge type and icon for AI1 channel
      * use to synchronize the widget
      * \param[in] eEdge is the type of edge for the AI1 channel
      * \return void : nothing
      */
    void pushButtonEdgeAI1_changeEdge(quint8 eEdge);

    /**
      * \fn  pushButtonEdgeDI1_changeEdge(quint8 eEdge)
      * \brief change the edge type and icon for AI2 channel
      * use to synchronize the widget
      * \param[in] eEdge is the type of edge for the AI2 channel
      * \return void : nothing
      */
    void pushButtonEdgeAI2_changeEdge(quint8 eEdge);

    //change value in doubleSpinBox
    /**
      * \fn  void doubleSpinBoxDI1_changeValue(double value)
      * \brief change the value in the double spinbox for DI1 channel
      * use to synchronize the widget
      * \param[in] value is the value set in the double spinbox
      * \return void : nothing
      */
    void doubleSpinBoxDI1_changeValue(double value);

    /**
      * \fn  void doubleSpinBoxDI1_changeValue(double value)
      * \brief change the value in the double spinbox for DI2 channel
      * use to synchronize the widget
      * \param[in] value is the value set in the double spinbox
      * \return void : nothing
      */
    void doubleSpinBoxDI2_changeValue(double value);

    /**
      * \fn  void doubleSpinBoxDI1_changeValue(double value)
      * \brief change the value in the double spinbox for DI3 channel
      * use to synchronize the widget
      * \param[in] value is the value set in the double spinbox
      * \return void : nothing
      */
    void doubleSpinBoxDI3_changeValue(double value);

    /**
      * \fn  void doubleSpinBoxDI1_changeValue(double value)
      * \brief change the value in the double spinbox for DI4 channel
      * use to synchronize the widget
      * \param[in] value is the value set in the double spinbox
      * \return void : nothing
      */
    void doubleSpinBoxDI4_changeValue(double value);

    /**
      * \fn  void doubleSpinBoxDI1_changeValue(double value)
      * \brief change the value in the double spinbox for AI1 channel
      * use to synchronize the widget
      * \param[in] value is the value set in the double spinbox
      * \return void : nothing
      */
    void doubleSpinBoxAI1_changeValue(double value);

    /**
      * \fn  void doubleSpinBoxDI1_changeValue(double value)
      * \brief change the value in the double spinbox for AI2 channel
      * use to synchronize the widget
      * \param[in] value is the value set in the double spinbox
      * \return void : nothing
      */
    void doubleSpinBoxAI2_changeValue(double value);

    /**
      * \fn TriggerFunctions *triggerSetting() const
      * \brief Getter for triggerSetting attribute
      * \return triggerSetting : TriggerFunctions
      */
    TriggerFunctions *triggerSetting() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeDI1() const
      * \brief Getter for rangeDI1 attribute
      * \return rangeDI1 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeDI1() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeDI2() const
      * \brief Getter for rangeDI2 attribute
      * \return rangeDI2 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeDI2() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeDI3() const
      * \brief Getter for rangeDI3 attribute
      * \return rangeDI3 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeDI3() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeDI4() const
      * \brief Getter for rangeDI4 attribute
      * \return rangeDI4 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeDI4() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeAI1() const
      * \brief Getter for rangeAI1 attribute
      * \return rangeAI1 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeAI1() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeAI2() const
      * \brief Getter for rangeAI2 attribute
      * \return rangeAI2 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeAI2() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeAI3() const
      * \brief Getter for rangeAI3 attribute
      * \return rangeAI3 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeAI3() const;

    /**
      * \fn  GlobalEnumatedAndExtern::eRangeValue rangeAI4() const
      * \brief Getter for rangeAI4 attribute
      * \return rangeAI4 : eRangeValue
      */
    GlobalEnumatedAndExtern::eRangeValue rangeAI4() const;

    /**
      * \fn  double triggerValueAI1() const
      * \brief Getter for triggerValueAI1 attribute
      * \return a double value
      */
    double triggerValueAI1() const;

    /**
      * \fn  double triggerValueAI2() const
      * \brief Getter for triggerValueAI1 attribute
      * \return a double value
      */
    double triggerValueAI2() const;


private:
    Ui::SettingTriggerSetting *ui;

    CommonStyle _myStyle;

    /**
      * \fn  void setupStyle()
      * \brief use to set the style of this object.
      * \return void : nothing
      */
    void setupStyle();

    //key value for Trace label name
    QMap<int, QString> _triggerTracePossible;

    //value of the selected trigger function
    TriggerFunctions *_triggerSetting;

    //state of edge
    GlobalEnumatedAndExtern::eEdge _btDI1Edge;
    GlobalEnumatedAndExtern::eEdge _btDI2Edge;
    GlobalEnumatedAndExtern::eEdge _btDI3Edge;
    GlobalEnumatedAndExtern::eEdge _btDI4Edge;
    GlobalEnumatedAndExtern::eEdge _btAI1Edge;
    GlobalEnumatedAndExtern::eEdge _btAI2Edge;

    void _setEdgeIcon(QPushButton *pushbutton, GlobalEnumatedAndExtern::eEdge edgeType);

    /**
      * \fn  void _setRangeValue()
      * \brief use to set the range value of the
      * \return void : nothing
      */
    void _setRangeValue();

    //picture on button
    QPixmap _pixmapFallingEdge;
    QPixmap _pixmapRisingEdge;
    QPixmap _pixmapNoEdge;

    //select or unselect the button
    void _DI1select(bool btselected);
    void _DI2select(bool btselected);
    void _DI3select(bool btselected);
    void _DI4select(bool btselected);
    void _AI1select(bool btselected);
    void _AI2select(bool btselected);
    void _AI3select(bool btselected);
    void _AI4select(bool btselected);

    //selected range
     GlobalEnumatedAndExtern::eRangeValue _rangeDI1;
     GlobalEnumatedAndExtern::eRangeValue _rangeDI2;
     GlobalEnumatedAndExtern::eRangeValue _rangeDI3;
     GlobalEnumatedAndExtern::eRangeValue _rangeDI4;
     GlobalEnumatedAndExtern::eRangeValue _rangeAI1;
     GlobalEnumatedAndExtern::eRangeValue _rangeAI2;
     GlobalEnumatedAndExtern::eRangeValue _rangeAI3;
     GlobalEnumatedAndExtern::eRangeValue _rangeAI4;

     //set range and text in trace setting button and doubleSpinBox
     //double to int converter
     /**
       * \fn void _setRangeAndTextTrace(GlobalEnumatedAndExtern::eTracePossible trace,
       *                GlobalEnumatedAndExtern::eRangeValue range)
       * \brief transforme a double value to quint8 value for futur trigger analysing
       * \param[in] trace is the channel to set
       * \param[in] range is the type of range for the channel
       * \return void : nothing
       */
     void _setRangeAndTextTrace(GlobalEnumatedAndExtern::eTracePossible trace, GlobalEnumatedAndExtern::eRangeValue range);

     //trigger value
     double _triggerValueAI1;
     double _triggerValueAI2;

     //double to int converter
     /**
       * \fn  quint8 _doubleToQuint8(double value, GlobalEnumatedAndExtern::eRangeValue range);
       * \brief transforme a double value to quint8 value for futur trigger analysing
       * \param[in] value is the value to tranforme
       * \param[in] range is the range of voltage
       * \return a quint8 as the transformed value from double
       */
     quint8 _doubleToQuint8(double value, GlobalEnumatedAndExtern::eRangeValue range);

public slots:
    void _btSelected(quint8 buttonNumber, bool btSelected);

private slots:
    void on_pushButtonRangeDI1_released();
    void on_pushButtonRangeDI2_released();
    void on_pushButtonRangeDI3_released();
    void on_pushButtonRangeDI4_released();
    void on_pushButtonRangeAI1_released();
    void on_pushButtonRangeAI2_released();
    void on_pushButtonRangeAI3_released();
    void on_pushButtonRangeAI4_released();

    void on_pushButtonEdgeDI1_released();
    void on_pushButtonEdgeDI2_released();
    void on_pushButtonEdgeDI3_released();
    void on_pushButtonEdgeDI4_released();
    void on_pushButtonEdgeAI1_released();
    void on_pushButtonEdgeAI2_released();

    void on_doubleSpinBoxDI1_valueChanged(double value);
    void on_doubleSpinBoxDI2_valueChanged(double value);
    void on_doubleSpinBoxDI3_valueChanged(double value);
    void on_doubleSpinBoxDI4_valueChanged(double value);
    void on_doubleSpinBoxAI1_valueChanged(double value);
    void on_doubleSpinBoxAI2_valueChanged(double value);

signals:
    void _pushButtonRangeAI1WasChanged();
    void _pushButtonRangeAI2WasChanged();
    void _pushButtonRangeAI3WasChanged();
    void _pushButtonRangeAI4WasChanged();
    void _pushButtonRangeAI1TXTWasChanged(QString rangeTxt);
    void _pushButtonRangeAI2TXTWasChanged(QString rangeTxt);
    void _pushButtonRangeAI3TXTWasChanged(QString rangeTxt);
    void _pushButtonRangeAI4TXTWasChanged(QString rangeTxt);

    void _pushButtonEdgeDI1WasChanged(quint8 eEdge);
    void _pushButtonEdgeDI2WasChanged(quint8 eEdge);
    void _pushButtonEdgeDI3WasChanged(quint8 eEdge);
    void _pushButtonEdgeDI4WasChanged(quint8 eEdge);
    void _pushButtonEdgeAI1WasChanged(quint8 eEdge);
    void _pushButtonEdgeAI2WasChanged(quint8 eEdge);

    void _doubleSpinBoxDI1_valueWasChanged(double value);
    void _doubleSpinBoxDI2_valueWasChanged(double value);
    void _doubleSpinBoxDI3_valueWasChanged(double value);
    void _doubleSpinBoxDI4_valueWasChanged(double value);
    void _doubleSpinBoxAI1_valueWasChanged(double value);
    void _doubleSpinBoxAI2_valueWasChanged(double value);
};

#endif // SETTINGTRIGGERSETTING_H
