#ifndef LOGODATETIME_H
#define LOGODATETIME_H

//*

/**
  * \file logoDateTime.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Manage the date and time display window
  */

#include <QWidget>
#include <QDateTime>
#include <QTimer>
#include "commonStyle.h"

namespace Ui {
class LogoDateTime;
}

class LogoDateTime : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn explicit LogoDateTime(QWidget *parent = 0)
      * \brief constructor for LogoDateTime
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit LogoDateTime(QWidget *parent = 0);

    /**
      * \fn  ~LogoDateTime()
      * \brief destructor for LogoDateTime
      */
    ~LogoDateTime();

private:
    Ui::LogoDateTime *ui;
    QTimer *_timer;
    QDate _dateToDay;
    QTime _timeToDay;
    QDateTime _dateTimeToDay;

    //style
    CommonStyle _myStyle;

private slots:
    void _showTime();

};

#endif // LOGODATETIME_H
