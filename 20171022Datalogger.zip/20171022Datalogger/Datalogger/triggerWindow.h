#ifndef TRIGGERWINDOW_H
#define TRIGGERWINDOW_H

//*

/**
  * \file triggerWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief windows for the trigger menu
  */

#include <QFrame>
#include "globalEnumatedAndExtern.h"
#include "dataFrame.h"

namespace Ui {
class TriggerWindow;
}

class TriggerWindow : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn explicit TriggerWindow(QWidget *parent = 0)
      * \brief constructor for TriggerWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit TriggerWindow(QWidget *parent = 0);

    /**
      * \fn  ~TriggerWindow()
      * \brief destructor for TriggerWindow
      */
    ~TriggerWindow();

    /**
      * \fn void setDrawRightToLeft(bool drawRightToLeft)
      * \brief Use to set the direction of the plotting
      * \param[in] drawRightToLeft if is true , the direction is right to left "Roll on", false is reversed "Trig"
      * \return void : nothing
      */
    void setDrawRightToLeft(bool drawRightToLeft);

    /**
      * \fn void setSizeOfPlots(int nbPixels)
      * \brief set the size of plot, it's the maximum value
      * \param[in] nbPixels is the width of the plot
      * \return void : nothing
      */
    void setSizeOfPlot(int valuePixels);

    // update the plot
    /**
      * \fn void refreshPlot()
      * \brief Use to update the value in the plot
      * \return void : nothing
      */
    void refreshPlot();

private:
    Ui::TriggerWindow *ui;

    //key value for Trace label name
    QMap<int, QString> _TriggerTracePossible;

    /**
      * \fn void _setAllTraceName()
      * \brief set the name of all widget traces
      * \return void : nothing
      */
    void _setAllTraceName();

    /**
      * \fn  void _hideAllTrace()
      * \brief hide all widget trace
      * \return void : nothing
      */
    void _hideAllTrace();
    DataFrame *_memoDataFrame;

    //setup signal and slot
    /**
      * \fn  void _setupSignalAndSlot()
      * \brief setup signal and slot for the widget
      * \return void : nothing
      */
    void _setupSignalAndSlot();

    //trigger function enable
    bool _triggerFunctionEnable;

    //trigger range
    quint8 _AI1SettingTriggerValue;
    quint8 _AI2SettingTriggerValue;

    //trigger range
    quint8 _AI1TriggerRange;
    quint8 _AI2TriggerRange;
    quint8 _AI3TriggerRange;
    quint8 _AI4TriggerRange;

    quint8 _doubleToQuint8(double value, GlobalEnumatedAndExtern::eRangeValue range);

    /**
      * \fn void updatePlot()
      * \brief Use to update all the selected plot
      * \return void : nothing
      */
    void _updateAllPlot();

public slots:
    void addTrace(quint8 enumTrace);
    void hideTrace(quint8 enumTrace);

    void pushButtonRangeAI1_changeRange();
    void pushButtonRangeAI2_changeRange();
    void pushButtonRangeAI3_changeRange();
    void pushButtonRangeAI4_changeRange();

    void pushButtonEdgeDI1_changeEdge(quint8 eEdge);
    void pushButtonEdgeDI2_changeEdge(quint8 eEdge);
    void pushButtonEdgeDI3_changeEdge(quint8 eEdge);
    void pushButtonEdgeDI4_changeEdge(quint8 eEdge);
    void pushButtonEdgeAI1_changeEdge(quint8 eRange);
    void pushButtonEdgeAI2_changeEdge(quint8 eRange);

    void doubleSpinBoxDI1_changeValue(double value);
    void doubleSpinBoxDI2_changeValue(double value);
    void doubleSpinBoxDI3_changeValue(double value);
    void doubleSpinBoxDI4_changeValue(double value);
    void doubleSpinBoxAI1_changeValue(double value);
    void doubleSpinBoxAI2_changeValue(double value);

    void comboBoxTopLeft_changeCurrentIndex(quint8 index);
    void comboBoxTopRight_changeCurrentIndex(quint8 index);
    void comboBoxBottomLeft_changeCurrentIndex(quint8 index);
    void comboBoxBottomRight_changeCurrentIndex(quint8 index);
    void comboBoxTopMiddle_changeCurrentIndex(quint8 index);
    void comboBoxMiddle_changeCurrentIndex(quint8 index);
    void comboBoxBottomMiddle_changeCurrentIndex(quint8 index);

    void addNewDataFrame(DataFrame *newDataFrame);

private slots:
    void _recieved_pushButtonRangeAI1Changed();
    void _recieved_pushButtonRangeAI2Changed();
    void _received_pushButtonRangeAI1TXTWasChanged(QString rangeTXT);
    void _received_pushButtonRangeAI2TXTWasChanged(QString rangeTXT);
    void _received_pushButtonRangeAI3TXTWasChanged(QString rangeTXT);
    void _received_pushButtonRangeAI4TXTWasChanged(QString rangeTXT);
    void _recieved_pushButtonEdgeDI1Changed(quint8 eEdge);
    void _recieved_pushButtonEdgeDI2Changed(quint8 eEdge);
    void _recieved_pushButtonEdgeDI3Changed(quint8 eEdge);
    void _recieved_pushButtonEdgeDI4Changed(quint8 eEdge);
    void _recieved_pushButtonEdgeAI1Changed(quint8 eEdge);
    void _recieved_pushButtonEdgeAI2Changed(quint8 eEdge);

    void _recieved_doubleSpinBoxDI1_valueChanged(double value);
    void _recieved_doubleSpinBoxDI2_valueChanged(double value);
    void _recieved_doubleSpinBoxDI3_valueChanged(double value);
    void _recieved_doubleSpinBoxDI4_valueChanged(double value);
    void _recieved_doubleSpinBoxAI1_valueChanged(double value);
    void _recieved_doubleSpinBoxAI2_valueChanged(double value);

    void _recieved_ComboBoxTopLeft_currentIndexChanged(quint8 index);
    void _recieved_ComboBoxTopRight_currentIndexChanged(quint8 index);
    void _recieved_ComboBoxBottomLeft_currentIndexChanged(quint8 index);
    void _recieved_ComboBoxBottomRight_currentIndexChanged(quint8 index);
    void _recieved_ComboBoxTopMiddle_currentIndexChanged(quint8 index);
    void _recieved_ComboBoxMiddle_currentIndexChanged(quint8 index);
    void _recieved_ComboBoxBottomMiddle_currentIndexChanged(quint8 index);

    void _received_errorWrongEquation(quint8 errorNumber,bool active);

signals:
    void _pushButtonRangeAI1WasChanged();
    void _pushButtonRangeAI2WasChanged();
    void _pushButtonRangeAI3WasChanged();
    void _pushButtonRangeAI4WasChanged();
    void _pushButtonRangeTXTAI1WasChanged(QString rangeTXT);
    void _pushButtonRangeTXTAI2WasChanged(QString rangeTXT);
    void _pushButtonRangeTXTAI3WasChanged(QString rangeTXT);
    void _pushButtonRangeTXTAI4WasChanged(QString rangeTXT);

    void _pushButtonEdgeDI1WasChanged(quint8 eEdge);
    void _pushButtonEdgeDI2WasChanged(quint8 eEdge);
    void _pushButtonEdgeDI3WasChanged(quint8 eEdge);
    void _pushButtonEdgeDI4WasChanged(quint8 eEdge);
    void _pushButtonEdgeAI1WasChanged(quint8 eEdge);
    void _pushButtonEdgeAI2WasChanged(quint8 eEdge);

    void _doubleSpinBoxDI1_valueWasChangedFromTriggerMenu(double value);
    void _doubleSpinBoxDI2_valueWasChangedFromTriggerMenu(double value);
    void _doubleSpinBoxDI3_valueWasChangedFromTriggerMenu(double value);
    void _doubleSpinBoxDI4_valueWasChangedFromTriggerMenu(double value);
    void _doubleSpinBoxAI1_valueWasChangedFromTriggerMenu(double value);
    void _doubleSpinBoxAI2_valueWasChangedFromTriggerMenu(double value);

    void _comboBoxTopLeft_currentIndexWasChanged(quint8 index);
    void _comboBoxTopRight_currentIndexWasChanged(quint8 index);
    void _comboBoxBottomLeft_currentIndexWasChanged(quint8 index);
    void _comboBoxBottomRight_currentIndexWasChanged(quint8 index);
    void _comboBoxTopMiddle_currentIndexWasChanged(quint8 index);
    void _comboBoxMiddle_currentIndexWasChanged(quint8 index);
    void _comboBoxBottomMiddle_currentIndexWasChanged(quint8 index);

    void _errorWrongEquation(quint8 errorNumber,bool active);
};

#endif // TRIGGERWINDOW_H
