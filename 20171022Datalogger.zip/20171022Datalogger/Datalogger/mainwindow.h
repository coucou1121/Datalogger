#ifndef MAINWINDOW_H
#define MAINWINDOW_H

//*

/**
  * \file mainWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Management of the analogue trace display
  */

/**
  * \def LINUX
  * \brief preprocessor symbol for LINUX
  *
  * This symbol is to select the linux OS on 1, for OS Windows change to 0
  */
#define LINUX 1

/**
  * \def CYCLETIME_FOR_FRAME_ACQUISITION
  * \brief preprocessor symbol for CYCLETIME_FOR_FRAME_ACQUISITION
  *
  * This symbol is the tick cycle time in miliseconds for frame acquisition
  */
#define CYCLETIME_FOR_FRAME_ACQUISITION 50  //ms //10

/**
  * \def NB_FRAME_READ_EVERY_CYCLE
  * \brief preprocessor symbol for NB_FRAME_READ_EVERY_CYCLE
  *
  * This symbol is the amont of data read every tick
  */
#define NB_FRAME_READ_EVERY_CYCLE 3500 //350

/**
  * \def INI_MESSAGE_DISPLAY
  * \brief preprocessor symbol for INI_MESSAGE_DISPLAY
  *
  * This symbol is show the FTDI status
  */
#define INI_MESSAGE_DISPLAY 1

/**
  * \def SIZE_OF_PLOT
  * \brief preprocessor symbol for SIZE_OF_PLOT
  *
  * This symbol is to set the minimum width of the trace plot
  */
#define SIZE_OF_PLOT 795

/**
  * \def NB_FRAME_MEMORIZED
  * \brief preprocessor symbol for NB_FRAME_MEMORIZED
  *
  * This symbol is to set circular buffer size for data saving
  */
#define NB_FRAME_MEMORIZED 65536 // SIZE_OF_PLOT

/**
  * \def PUSH_BOUTTON_INPUT
  * \brief preprocessor symbol for PUSH_BOUTTON_INPUT
  *
  * This symbol is to set input pin for hold buton
  */
#define PUSH_BOUTTON_INPUT 29

#include <QMainWindow>
#include <QPushButton>
#include <QHBoxLayout>
#include <QTimer>
#include <QThread>

#include "main.h"
#include "commonStyle.h"
#include "initWindow.h"
#include "homeWindow.h"
#include "settingWindow.h"
#include "triggerWindow.h"
#include "rollWindow.h"
#include "debugWindow.h"
#include "dataFrameSimulator.h"
#include "triggerWindow.h"
#include "triggerFunctions.h"
#include "dataFrameLiveReading.h"
#include "frameThread.h"
#include "pushbuttonWatchingThread.h"

#if LINUX
#include "FTDI/ftd2xx.h"
#include "FTDIFunction.h"
#endif

#if RASPI
#include "ledManager.h"
#endif
namespace Ui {

class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    /**
      * \fn explicit MainWindow(QWidget *parent = 0)
      * \brief constructor for MainWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit MainWindow(QWidget *parent = 0);

    /**
      * \fn  ~MainWindow()
      * \brief destructor for MainWindow
      */
    ~MainWindow();

    //setup basic style for the main wondows
    /**
      * \fn void setupStyle();
      * \brief setup the main style on this application
      * \return void : nothing
      */
    void setupStyle();

    //set the application with default value
    /**
      * \fn void mainSetup();
      * \brief startup setup of this application
      * \return void : nothing
      */
    void mainSetup();

private:
    Ui::MainWindow *ui;

    //value of the selected trigger function
    //quint16 _valueTriggerFunction;

    //actif wait delay
    /**
      * \fn void _waitDelay(int delayInSeconde)
      * \brief Active wait delay
      * \param[in] Delay to wait in seconds.
      * \return void : nothing
      */
    void _waitDelay(int delayInSeconde);

    //speed of plot
    quint8 _speedOfPlot;


    //pushButton green and blue activated
    bool _pushButtonActivated;

    //thread
    FrameThread *_threadSimulationDataAnalysis;               // create tick for frequency simulation
    FrameThread *_threadLiveDataAnalysis;               // create tick for frequency simulation
    FrameThread *_threadNewDataFrame;       // create a new data
    FrameThread *_threadDisplayRefresh;     // Display refreshement
    QThread *_threadRealTimeReading;          // Manage the real time reading
    FrameThread *_frameThread;
    FrameThread *_threadLedFlashing;
    PushButtonWatchingThread *_threadMainHardPushButtonn;

    //ui windows
    InitWindow *_initWindow;
    HomeWindow *_homeWindow;
    SettingWindow *_settingWindow;
    TriggerWindow *_triggerWindow;
    RollWindow *_rollWindow;
    DebugWindow *_debugWindow;

    /**
      * \fn void _hideAllWindows()
      * \brief Hide all windows
      * \return void : nothing
      */
    void _hideAllWindows();

    //Style
//    CommonStyle _myStyle;

    //widget for status bar
    QWidget *_widgetStatusBar;

    QHBoxLayout *_hlayoutStatus;

    QPushButton *_btHome;
    QPushButton *_btSetting;
    QPushButton *_btTrigger;
    QPushButton *_btRoll;
    QPushButton *_btDebug;

    //For activate the external button
    QPushButton *_btButton;

    bool _btHomeWasPressed;
    bool _btSettingWasPressed;
    bool _btTriggerWasPressed;
    bool _btRollWasPressed;
    bool _btDebugWasPressed;
    bool _btButtonWasPressed;

    //main state graph
    /**
      * \fn void _mainStateGraphe()
      * \brief Fucntion use to apply if was a main state modifcation
      * \return void : nothing
      */
    void _mainStateGraphe();

    /**
      * \fn void _mainStateGraphe()
      * \brief Fucntion use to go to the next step
      * \return void : nothing
      */
    void _goToNextState();
    GlobalEnumatedAndExtern::eMainStateApplication _mainStateStep;
    GlobalEnumatedAndExtern::eMainStateDisplay _mainStateDisplay;

    //trig state graph
    /**
      * \fn void _trigStateGraph()
      * \brief Fucntion use to apply if was a trig state modifcation
      * \return void : nothing
      */
    void _trigStateGraph();
    GlobalEnumatedAndExtern::eTrigState _trigStateStep;

    //roll state graph
    /**
      * \fn void _trigStateGraph()
      * \brief Fucntion use to apply if was a roll state modifcation
      * \return void : nothing
      */
    void _rollStateGraph();
    GlobalEnumatedAndExtern::eRollState _rollStateStep;

    //evaluation of the trigger function
    bool _triggerFunctionEvaluatedTrue;

    //set the bottom status bar
    /**
      * \fn void _setStatusBar()
      * \brief Setup of the status bar
      * \return void : nothing
      */
    void _setStatusBar();

    //set the pushbutton color to grey
    /**
      * \fn void _resetPushButtonColor()
      * \brief set all button on the status bar to light grey, mean unselected
      * \return void : nothing
      */
    void _resetPushButtonColor();

    //setup signal and slot
    /**
      * \fn  void _setupSignalAndSlot()
      * \brief setup signal and slot for the application bettween the windows
      * \return void : nothing
      */
    void _setupSignalAndSlot();

    //setup default start value for all variable in this application
    /**
      * \fn  void _setupDefaultValue()
      * \brief setup all application default values
      * \return void : nothing
      */
    void _setupDefaultValue();

    //manage state of the startStop button
    /**
      * \fn      void _startStopButtonTextAndColorManager(GlobalEnumatedAndExtern::eBPStartStopState state)
      * \brief Manage state of the startStop button
      * \param[in] State of the main pushbutton
      * \return void : nothing
      */
    void _startStopButtonTextAndColorManager(GlobalEnumatedAndExtern::eBPStartStopState state);

    //array for data recorder
    QVector<DataFrame> _dataFrameRecorder;
    QVector<DataFrame> _dataFrameTrace;
    QVector<DataFrame>::iterator _itProducer;
    int _itIntProducer;
    QVector<DataFrame>::iterator _itConsumer;
    QVector<DataFrame>::iterator _itTrace;

    //frame simulator
    DataFrameSimulator *_dataFrameSimulator;

    //value of the selected trigger function
    TriggerFunctions *_triggerFuntion;

    //check if on trig
    bool _onTrigTrue;

    //number of value after trig
    quint32 _amontOfValueAfterTrig;
    quint32 _nbValueAfterTrig;

    //memorise simulation mode
    bool _inSimulation;

    //FTDI connection
#if RASPI
    FTDIFunction *_FTDIdevice;
#endif
    quint32 _baudRateSpeed2M;
    quint16 _baudRateSpeed9600;
#if LINUX
    //FTDI management
    /**
      * \fn  bool _FTDIconnection()
      * \brief Cehck the FTDI connection and configuration
      * return true if correct
      * return false if not
      * \return a boolean
      */
    bool _FTDIconnection();
    bool _FTDI_OK;
    QMap<int, QString> _FTDIStatePossibleTXT;

    //realtime reading
    DataFrameLiveReading *_dataFrameLiveReading;

    //timer for statictics
    QElapsedTimer timerElapse;
    QElapsedTimer timerFrameCycle;
    quint64 _minTime;
    quint64 _maxTime;
    quint64 _avgTime;
#endif

public slots:
    void changeStateStartStopButton(int state);
    void startThread();
    void stopThread();
    void addNewProducteurAdress(int itProducerAdress);
    void addNewSimulatedDataFrame();
    void addNewLiveDataFrame();
    void refreshDisplay();
    void checkBoxEmulationModeChanged(bool checked);
    void received_settingSizeOfPlotWasChanged(int nbPixels);
    void received_speedOfPlotWasChanged(int dataPerSecond);
    void received_percentPreTriggerChanged(double percent);
    void greenLedFlashing();
    void hardMainpushButtonOn();

private slots:
    void _btHome_released();
    void _btSetting_released();
    void _btTrigger_released();
    void _btRoll_released();
    void _btDebug_released();
    void _btButton_released();
    void on_pushButton_StartStop_released();

signals:
    void _errorFTDIDeviceNotFound(quint8 errorNumber, bool active);
};

#endif // MAINWINDOW_H
