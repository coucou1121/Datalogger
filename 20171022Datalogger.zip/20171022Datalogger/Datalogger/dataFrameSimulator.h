#ifndef DATAFRAMESIMULATOR_H
#define DATAFRAMESIMULATOR_H

/**
  * \file dataFrameSimulator.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief create the data for simulation mode
  */

/**
  * \def NB_FRAME_CREATE_AT_EVERY_TICK
  * \brief preprocessor symbole for NB_FRAME_CREATE_AT_EVERY_TICK
  *
  * This symbole is the amont of data created evry tick
  */
#define NB_FRAME_CREATE_AT_EVERY_TICK 10000

#include <QObject>
#include <QDebug>
#include <QElapsedTimer>
#include "dataFrame.h"
#include "triggerFunctions.h"

class DataFrameSimulator : public QObject
{
    Q_OBJECT

public:
    /**
      * \fn DataFrameSimulator(QString name, QObject *parent = 0)
      * \brief constructor for DataFrameSimulator
      * \param[in] name is the name of the object
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    DataFrameSimulator(QString name, QObject *parent = 0);

    /**
      * \fn quint8 CPT() const
      * \brief Getter for CPT attribute
      * \return CPT : quint64
      */
    quint64 CPT() const;

    /**
      * \fn  void setCPT(const quint64 &CPT)
      * \brief Setter for CPT attribute
      * \return void : nothing
      */
    void setCPT(const quint64 &CPT);

    /**
      * \fn  void setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder)
      * \brief circilar buffer for data storage
      * \param[in] dataFrameVectorReccorder is the array for data storage fixe to 65536 values
      * \return void : nothing
      */
    void setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder);

    /**
      * \fn DataFrame *dataFrame() const
      * \brief Getter for dataFrame attribute
      * \return dataFrame : DataFrame
      */
    DataFrame *dataFrame() const;

    /**
      * \fn  void setDataFrame(DataFrame *dataFrame)
      * \brief Setter for dataFrame attribute
      * \return void : nothing
      */
    void setDataFrame(DataFrame *dataFrame);

    /**
      * \fn  setItProducer(const QVector<DataFrame>::iterator &itProducer)
      * \brief iterator for the circular buffer
      * \param[in] itProducer is the iterator on array for the saving data position
      * \return void : nothing
      */
    void setItProducer(const QVector<DataFrame>::iterator &itProducer);

    /**
      * \fn  setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress)
      * \brief iterator for the circular buffer, use to stop the entry of data from this thread
      * \param[in] itConsumerAdress is the iterator adresse for of the reading data position
      * \return void : nothing
      */
    void setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress);

private:
    DataFrame *_dataFrame;
    quint16 _CPT;
    QElapsedTimer _timerElapse;
    QVector<DataFrame> _dataFrameVector;
    TriggerFunctions *_triggerFunction;
    void _resetFrame();
    void _incValue();

    QVector<DataFrame> *_dataFrameVectorReccorder;
    QVector<DataFrame>::iterator _itProducer;
    QVector<DataFrame>::iterator _itConsumerAdress;

public slots:
    void createDataFrame();

signals:
    void dataFrameWasSent(int itProducerAdress);
};

#endif // DATAFRAMESIMULATOR_H
