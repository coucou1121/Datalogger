#ifndef PLOTSETTING_H
#define PLOTSETTING_H

//*

/**
  * \file plotSetting.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Frame Size of plots, use to set the amont of dot in plot
  */

#include <QFrame>
#include "commonStyle.h"
#include "globalEnumatedAndExtern.h"

namespace Ui {
class PlotSetting;
}

class PlotSetting : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn explicit PlotSetting(QWidget *parent = 0)
      * \brief constructor for PlotSetting
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit PlotSetting(QWidget *parent = 0);

    /**
      * \fn  ~PlotSetting()
      * \brief destructor for PlotSetting
      */
    ~PlotSetting();


    /**
      * \fn void setSizeOfPlots(int nbPixels)
      * \brief set the size of plot, it's the maximum value
      * \param[in] nbPixels is the width of the plot
      * \return void : nothing
      */
    void setSizeOfPlots(int nbPixels);

    /**
      * \fn void setTitle(QString nameTxt)
      * \brief Use to set the title name of the frame
      * \param[in] nameTxt is the name of the frame in string
      * \return void : nothing
      */
    void setTitle(QString nameTxt);

    /**
      * \fn void setStartValue(double startValue)
      * \brief Use to set the start application value
      * \param[in] startValue is the value when the application start
      * \return void : nothing
      */
    void setStartValue(double startValue);

    /**
      * \fn  void setMinimum(double valueMin);
      * \brief Use to set the minimum value in the double spinbox
      * \param[in] valueMin is minimum value for the double spinbox
      * \return void : nothing
      */
    void setMinimum(double valueMin);

    /**
      * \fn  void setMaximum(double valueMax);
      * \brief Use to set the maximum value in the double spinbox
      * \param[in] valueMax is maximum value for the double spinbox
      * \return void : nothing
      */
    void setMaximum(double valueMax);

    /**
      * \fn  void setStep(double stepValue);
      * \brief Use to set the step value when we clic on the side flow
      * \param[in] stepValue the step value when we clic on the flow
      * \return void : nothing
      */
    void setStep(double stepValue);

private:
    Ui::PlotSetting *ui;

    CommonStyle _myStyle;
    void setupStyle();

private slots:
    void on_doubleSpinBox_valueChanged(double arg1);

signals:
     void _settingSizeOfPlotWasChanged(int nbPixels);
};

#endif // PLOTSETTING_H
