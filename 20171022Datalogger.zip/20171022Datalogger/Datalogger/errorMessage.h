#ifndef ERRORMESSAGE_H
#define ERRORMESSAGE_H

/**
  * \file errorMessage.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Management of the error message
  */

#include <QWidget>
#include <QDebug>
#include "commonStyle.h"
#include "globalEnumatedAndExtern.h"
#include "ledManager.h"

namespace Ui {
class ErrorMessage;
}

class ErrorMessage : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn  explicit ErrorMessage(QWidget *parent = 0)
      * \brief constructor for ErrorMessage
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit ErrorMessage(QWidget *parent = 0);

    /**
      * \fn  ~ErrorMessage()
      * \brief destructor for ErrorMessage
      */
    ~ErrorMessage();


private:
    Ui::ErrorMessage *ui;

    //Style
    CommonStyle _myStyle;

    QMap<int, QString> _errorListPossible;
    QMap<int, QString> _errorListNow;

    /**
      * \fn void _setColor(bool inTrouble)
      * \brief Use to change the color of the message display.
      * Red in case of errors messages, grey no error message at all.
      * \param[in] inTrouble is the status of the message
      * \return void : nothing
      */
    void _setColor(bool inTrouble);


    /**
      * \fn void _displayMessage()
      * \brief Use to display the message in the dedicated frame.
      * \return void : nothing
      */
    void _displayMessage();

private slots:
    void _reveived_Error(quint8 errorNumber, bool active);

};

#endif // ERRORMESSAGE_H
