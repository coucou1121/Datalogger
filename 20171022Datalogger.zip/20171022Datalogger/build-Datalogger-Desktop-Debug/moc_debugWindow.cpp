/****************************************************************************
** Meta object code from reading C++ file 'debugWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Datalogger/debugWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'debugWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_DebugWindow_t {
    QByteArrayData data[21];
    char stringdata[524];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DebugWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DebugWindow_t qt_meta_stringdata_DebugWindow = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 20),
QT_MOC_LITERAL(2, 33, 0),
QT_MOC_LITERAL(3, 34, 13),
QT_MOC_LITERAL(4, 48, 17),
QT_MOC_LITERAL(5, 66, 10),
QT_MOC_LITERAL(6, 77, 20),
QT_MOC_LITERAL(7, 98, 38),
QT_MOC_LITERAL(8, 137, 7),
QT_MOC_LITERAL(9, 145, 35),
QT_MOC_LITERAL(10, 181, 4),
QT_MOC_LITERAL(11, 186, 32),
QT_MOC_LITERAL(12, 219, 31),
QT_MOC_LITERAL(13, 251, 30),
QT_MOC_LITERAL(14, 282, 31),
QT_MOC_LITERAL(15, 314, 34),
QT_MOC_LITERAL(16, 349, 32),
QT_MOC_LITERAL(17, 382, 30),
QT_MOC_LITERAL(18, 413, 39),
QT_MOC_LITERAL(19, 453, 38),
QT_MOC_LITERAL(20, 492, 31)
    },
    "DebugWindow\0_nbFrameSavedChanged\0\0"
    "_nbSavedFrame\0_frameSizeChanged\0"
    "_frameSize\0_FTDIBaudrateChanged\0"
    "_checkBoxEmulationModeStatusWasChanged\0"
    "checked\0on_lineEditNbSavedFrame_textChanged\0"
    "arg1\0on_lineEditFrameSize_textChanged\0"
    "on_lineEditBaudrate_textChanged\0"
    "on_pushButtonFTDIInfo_released\0"
    "on_pushButtonSendStart_released\0"
    "on_pushButtonFTDIStopRead_released\0"
    "on_checkBoxEmulationMode_toggled\0"
    "on_pushButtonSendChar_released\0"
    "on_pushButtonFTDIStartReadData_released\0"
    "on_pushButtonFTDIStopReadData_released\0"
    "on_pushButtonCleanText_released"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DebugWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   89,    2, 0x06 /* Public */,
       4,    1,   92,    2, 0x06 /* Public */,
       6,    1,   95,    2, 0x06 /* Public */,
       7,    1,   98,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    1,  101,    2, 0x08 /* Private */,
      11,    1,  104,    2, 0x08 /* Private */,
      12,    1,  107,    2, 0x08 /* Private */,
      13,    0,  110,    2, 0x08 /* Private */,
      14,    0,  111,    2, 0x08 /* Private */,
      15,    0,  112,    2, 0x08 /* Private */,
      16,    1,  113,    2, 0x08 /* Private */,
      17,    0,  116,    2, 0x08 /* Private */,
      18,    0,  117,    2, 0x08 /* Private */,
      19,    0,  118,    2, 0x08 /* Private */,
      20,    0,  119,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::ULongLong,    3,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Int,    5,
    QMetaType::Void, QMetaType::Bool,    8,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void, QMetaType::QString,   10,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    8,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void DebugWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        DebugWindow *_t = static_cast<DebugWindow *>(_o);
        switch (_id) {
        case 0: _t->_nbFrameSavedChanged((*reinterpret_cast< quint64(*)>(_a[1]))); break;
        case 1: _t->_frameSizeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 2: _t->_FTDIBaudrateChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->_checkBoxEmulationModeStatusWasChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 4: _t->on_lineEditNbSavedFrame_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 5: _t->on_lineEditFrameSize_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 6: _t->on_lineEditBaudrate_textChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 7: _t->on_pushButtonFTDIInfo_released(); break;
        case 8: _t->on_pushButtonSendStart_released(); break;
        case 9: _t->on_pushButtonFTDIStopRead_released(); break;
        case 10: _t->on_checkBoxEmulationMode_toggled((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 11: _t->on_pushButtonSendChar_released(); break;
        case 12: _t->on_pushButtonFTDIStartReadData_released(); break;
        case 13: _t->on_pushButtonFTDIStopReadData_released(); break;
        case 14: _t->on_pushButtonCleanText_released(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (DebugWindow::*_t)(quint64 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DebugWindow::_nbFrameSavedChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (DebugWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DebugWindow::_frameSizeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (DebugWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DebugWindow::_FTDIBaudrateChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (DebugWindow::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&DebugWindow::_checkBoxEmulationModeStatusWasChanged)) {
                *result = 3;
            }
        }
    }
}

const QMetaObject DebugWindow::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_DebugWindow.data,
      qt_meta_data_DebugWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *DebugWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DebugWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_DebugWindow.stringdata))
        return static_cast<void*>(const_cast< DebugWindow*>(this));
    return QFrame::qt_metacast(_clname);
}

int DebugWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 15)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 15;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 15)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 15;
    }
    return _id;
}

// SIGNAL 0
void DebugWindow::_nbFrameSavedChanged(quint64 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void DebugWindow::_frameSizeChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void DebugWindow::_FTDIBaudrateChanged(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void DebugWindow::_checkBoxEmulationModeStatusWasChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_END_MOC_NAMESPACE
