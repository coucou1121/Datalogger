/********************************************************************************
** Form generated from reading UI file 'analogPlot.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ANALOGPLOT_H
#define UI_ANALOGPLOT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_AnalogPlot
{
public:
    QGridLayout *gridLayout;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QLabel *labelNameAI;
    QLabel *labelRangeAI;
    QCustomPlot *widget_AI;

    void setupUi(QWidget *AnalogPlot)
    {
        if (AnalogPlot->objectName().isEmpty())
            AnalogPlot->setObjectName(QStringLiteral("AnalogPlot"));
        AnalogPlot->resize(792, 90);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(AnalogPlot->sizePolicy().hasHeightForWidth());
        AnalogPlot->setSizePolicy(sizePolicy);
        gridLayout = new QGridLayout(AnalogPlot);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        frame = new QFrame(AnalogPlot);
        frame->setObjectName(QStringLiteral("frame"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(frame->sizePolicy().hasHeightForWidth());
        frame->setSizePolicy(sizePolicy1);
        frame->setMinimumSize(QSize(60, 0));
        frame->setMaximumSize(QSize(60, 16777215));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Plain);
        verticalLayout = new QVBoxLayout(frame);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        labelNameAI = new QLabel(frame);
        labelNameAI->setObjectName(QStringLiteral("labelNameAI"));
        sizePolicy.setHeightForWidth(labelNameAI->sizePolicy().hasHeightForWidth());
        labelNameAI->setSizePolicy(sizePolicy);
        labelNameAI->setMinimumSize(QSize(60, 20));
        labelNameAI->setMaximumSize(QSize(60, 100));
        QFont font;
        font.setPointSize(10);
        labelNameAI->setFont(font);
        labelNameAI->setFrameShape(QFrame::NoFrame);
        labelNameAI->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(labelNameAI);

        labelRangeAI = new QLabel(frame);
        labelRangeAI->setObjectName(QStringLiteral("labelRangeAI"));
        labelRangeAI->setMinimumSize(QSize(60, 20));
        labelRangeAI->setMaximumSize(QSize(60, 40));
        labelRangeAI->setFont(font);
        labelRangeAI->setAutoFillBackground(false);
        labelRangeAI->setScaledContents(true);
        labelRangeAI->setAlignment(Qt::AlignCenter);
        labelRangeAI->setIndent(-1);

        verticalLayout->addWidget(labelRangeAI);


        gridLayout->addWidget(frame, 0, 0, 1, 1);

        widget_AI = new QCustomPlot(AnalogPlot);
        widget_AI->setObjectName(QStringLiteral("widget_AI"));

        gridLayout->addWidget(widget_AI, 0, 1, 1, 1);


        retranslateUi(AnalogPlot);

        QMetaObject::connectSlotsByName(AnalogPlot);
    } // setupUi

    void retranslateUi(QWidget *AnalogPlot)
    {
        AnalogPlot->setWindowTitle(QApplication::translate("AnalogPlot", "Form", 0));
        labelNameAI->setText(QApplication::translate("AnalogPlot", "Title", 0));
        labelRangeAI->setText(QApplication::translate("AnalogPlot", "range", 0));
    } // retranslateUi

};

namespace Ui {
    class AnalogPlot: public Ui_AnalogPlot {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ANALOGPLOT_H
