/********************************************************************************
** Form generated from reading UI file 'rollWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ROLLWINDOW_H
#define UI_ROLLWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "analogPlot.h"
#include "digitalPlot.h"

QT_BEGIN_NAMESPACE

class Ui_RollWindow
{
public:
    QGridLayout *gridLayout;
    QVBoxLayout *verticalLayout;
    DigitalPlot *DI1;
    DigitalPlot *DI2;
    DigitalPlot *DI3;
    DigitalPlot *DI4;
    DigitalPlot *DI5;
    DigitalPlot *DI6;
    DigitalPlot *DI7;
    DigitalPlot *DI8;
    DigitalPlot *DI9;
    DigitalPlot *DI10;
    DigitalPlot *DI11;
    DigitalPlot *DI12;
    DigitalPlot *DI13;
    DigitalPlot *DI14;
    DigitalPlot *DI15;
    DigitalPlot *DI16;
    AnalogPlot *AI1;
    AnalogPlot *AI2;
    AnalogPlot *AI3;
    AnalogPlot *AI4;

    void setupUi(QWidget *RollWindow)
    {
        if (RollWindow->objectName().isEmpty())
            RollWindow->setObjectName(QStringLiteral("RollWindow"));
        RollWindow->resize(880, 431);
        gridLayout = new QGridLayout(RollWindow);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        DI1 = new DigitalPlot(RollWindow);
        DI1->setObjectName(QStringLiteral("DI1"));

        verticalLayout->addWidget(DI1);

        DI2 = new DigitalPlot(RollWindow);
        DI2->setObjectName(QStringLiteral("DI2"));

        verticalLayout->addWidget(DI2);

        DI3 = new DigitalPlot(RollWindow);
        DI3->setObjectName(QStringLiteral("DI3"));

        verticalLayout->addWidget(DI3);

        DI4 = new DigitalPlot(RollWindow);
        DI4->setObjectName(QStringLiteral("DI4"));

        verticalLayout->addWidget(DI4);

        DI5 = new DigitalPlot(RollWindow);
        DI5->setObjectName(QStringLiteral("DI5"));

        verticalLayout->addWidget(DI5);

        DI6 = new DigitalPlot(RollWindow);
        DI6->setObjectName(QStringLiteral("DI6"));

        verticalLayout->addWidget(DI6);

        DI7 = new DigitalPlot(RollWindow);
        DI7->setObjectName(QStringLiteral("DI7"));

        verticalLayout->addWidget(DI7);

        DI8 = new DigitalPlot(RollWindow);
        DI8->setObjectName(QStringLiteral("DI8"));

        verticalLayout->addWidget(DI8);

        DI9 = new DigitalPlot(RollWindow);
        DI9->setObjectName(QStringLiteral("DI9"));

        verticalLayout->addWidget(DI9);

        DI10 = new DigitalPlot(RollWindow);
        DI10->setObjectName(QStringLiteral("DI10"));

        verticalLayout->addWidget(DI10);

        DI11 = new DigitalPlot(RollWindow);
        DI11->setObjectName(QStringLiteral("DI11"));

        verticalLayout->addWidget(DI11);

        DI12 = new DigitalPlot(RollWindow);
        DI12->setObjectName(QStringLiteral("DI12"));

        verticalLayout->addWidget(DI12);

        DI13 = new DigitalPlot(RollWindow);
        DI13->setObjectName(QStringLiteral("DI13"));

        verticalLayout->addWidget(DI13);

        DI14 = new DigitalPlot(RollWindow);
        DI14->setObjectName(QStringLiteral("DI14"));

        verticalLayout->addWidget(DI14);

        DI15 = new DigitalPlot(RollWindow);
        DI15->setObjectName(QStringLiteral("DI15"));

        verticalLayout->addWidget(DI15);

        DI16 = new DigitalPlot(RollWindow);
        DI16->setObjectName(QStringLiteral("DI16"));

        verticalLayout->addWidget(DI16);

        AI1 = new AnalogPlot(RollWindow);
        AI1->setObjectName(QStringLiteral("AI1"));

        verticalLayout->addWidget(AI1);

        AI2 = new AnalogPlot(RollWindow);
        AI2->setObjectName(QStringLiteral("AI2"));

        verticalLayout->addWidget(AI2);

        AI3 = new AnalogPlot(RollWindow);
        AI3->setObjectName(QStringLiteral("AI3"));

        verticalLayout->addWidget(AI3);

        AI4 = new AnalogPlot(RollWindow);
        AI4->setObjectName(QStringLiteral("AI4"));

        verticalLayout->addWidget(AI4);


        gridLayout->addLayout(verticalLayout, 0, 1, 1, 1);


        retranslateUi(RollWindow);

        QMetaObject::connectSlotsByName(RollWindow);
    } // setupUi

    void retranslateUi(QWidget *RollWindow)
    {
        RollWindow->setWindowTitle(QApplication::translate("RollWindow", "Form", 0));
    } // retranslateUi

};

namespace Ui {
    class RollWindow: public Ui_RollWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ROLLWINDOW_H
