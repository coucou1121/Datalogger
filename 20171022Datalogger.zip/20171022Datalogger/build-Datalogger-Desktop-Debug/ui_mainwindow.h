/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QWidget>
#include "errorMessage.h"
#include "logoDateTime.h"
#include "plotSetting.h"
#include "stateFrame.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QGridLayout *gridLayout_3;
    QGridLayout *gridLayout;
    QWidget *widget;
    QGridLayout *gridLayout_2;
    QPushButton *pushButton_StartStop;
    StateFrame *widgetState;
    QSpacerItem *verticalSpacer;
    ErrorMessage *widgetError;
    LogoDateTime *widgetLogo;
    PlotSetting *widgetPlotSetting;
    PlotSetting *widgetSpeedReading;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1280, 720);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        MainWindow->setMinimumSize(QSize(1280, 720));
        QFont font;
        font.setPointSize(12);
        MainWindow->setFont(font);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        sizePolicy.setHeightForWidth(centralWidget->sizePolicy().hasHeightForWidth());
        centralWidget->setSizePolicy(sizePolicy);
        gridLayout_3 = new QGridLayout(centralWidget);
        gridLayout_3->setSpacing(5);
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(5, 10, 5, 0);
        gridLayout = new QGridLayout();
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 0, 5, 0);
        widget = new QWidget(centralWidget);
        widget->setObjectName(QStringLiteral("widget"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy1);
        widget->setMinimumSize(QSize(170, 150));
        widget->setMaximumSize(QSize(170, 150));
        gridLayout_2 = new QGridLayout(widget);
        gridLayout_2->setSpacing(5);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(5, 5, 5, 5);
        pushButton_StartStop = new QPushButton(widget);
        pushButton_StartStop->setObjectName(QStringLiteral("pushButton_StartStop"));
        pushButton_StartStop->setEnabled(true);
        sizePolicy1.setHeightForWidth(pushButton_StartStop->sizePolicy().hasHeightForWidth());
        pushButton_StartStop->setSizePolicy(sizePolicy1);
        pushButton_StartStop->setMinimumSize(QSize(150, 130));
        pushButton_StartStop->setMaximumSize(QSize(150, 130));
        QFont font1;
        font1.setPointSize(22);
        font1.setBold(true);
        font1.setWeight(75);
        pushButton_StartStop->setFont(font1);
        pushButton_StartStop->setCheckable(false);
        pushButton_StartStop->setFlat(false);

        gridLayout_2->addWidget(pushButton_StartStop, 0, 0, 1, 1);


        gridLayout->addWidget(widget, 3, 0, 1, 1);

        widgetState = new StateFrame(centralWidget);
        widgetState->setObjectName(QStringLiteral("widgetState"));
        widgetState->setEnabled(true);
        sizePolicy1.setHeightForWidth(widgetState->sizePolicy().hasHeightForWidth());
        widgetState->setSizePolicy(sizePolicy1);
        widgetState->setMinimumSize(QSize(170, 88));
        widgetState->setMaximumSize(QSize(170, 88));

        gridLayout->addWidget(widgetState, 2, 0, 1, 1);

        verticalSpacer = new QSpacerItem(20, 20, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout->addItem(verticalSpacer, 4, 0, 1, 1);

        widgetError = new ErrorMessage(centralWidget);
        widgetError->setObjectName(QStringLiteral("widgetError"));
        sizePolicy1.setHeightForWidth(widgetError->sizePolicy().hasHeightForWidth());
        widgetError->setSizePolicy(sizePolicy1);
        widgetError->setMinimumSize(QSize(170, 130));
        widgetError->setMaximumSize(QSize(170, 130));

        gridLayout->addWidget(widgetError, 1, 0, 1, 1);

        widgetLogo = new LogoDateTime(centralWidget);
        widgetLogo->setObjectName(QStringLiteral("widgetLogo"));
        sizePolicy1.setHeightForWidth(widgetLogo->sizePolicy().hasHeightForWidth());
        widgetLogo->setSizePolicy(sizePolicy1);
        widgetLogo->setMinimumSize(QSize(170, 88));
        widgetLogo->setMaximumSize(QSize(170, 88));

        gridLayout->addWidget(widgetLogo, 0, 0, 1, 1);

        widgetPlotSetting = new PlotSetting(centralWidget);
        widgetPlotSetting->setObjectName(QStringLiteral("widgetPlotSetting"));
        sizePolicy1.setHeightForWidth(widgetPlotSetting->sizePolicy().hasHeightForWidth());
        widgetPlotSetting->setSizePolicy(sizePolicy1);
        widgetPlotSetting->setMinimumSize(QSize(170, 100));
        widgetPlotSetting->setMaximumSize(QSize(170, 100));

        gridLayout->addWidget(widgetPlotSetting, 6, 0, 1, 1);

        widgetSpeedReading = new PlotSetting(centralWidget);
        widgetSpeedReading->setObjectName(QStringLiteral("widgetSpeedReading"));
        sizePolicy1.setHeightForWidth(widgetSpeedReading->sizePolicy().hasHeightForWidth());
        widgetSpeedReading->setSizePolicy(sizePolicy1);
        widgetSpeedReading->setMinimumSize(QSize(170, 100));
        widgetSpeedReading->setMaximumSize(QSize(170, 100));

        gridLayout->addWidget(widgetSpeedReading, 5, 0, 1, 1);


        gridLayout_3->addLayout(gridLayout, 0, 0, 1, 1);

        MainWindow->setCentralWidget(centralWidget);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        statusBar->setFont(font);
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", 0));
        pushButton_StartStop->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
