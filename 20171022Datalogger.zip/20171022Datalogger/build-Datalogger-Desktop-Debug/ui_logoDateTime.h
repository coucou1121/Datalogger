/********************************************************************************
** Form generated from reading UI file 'logoDateTime.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LOGODATETIME_H
#define UI_LOGODATETIME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_LogoDateTime
{
public:
    QGridLayout *gridLayout;
    QFrame *mainFrame;
    QVBoxLayout *verticalLayout;
    QLabel *labelLeftTop;
    QLabel *labelDate;
    QLabel *labelTime;

    void setupUi(QWidget *LogoDateTime)
    {
        if (LogoDateTime->objectName().isEmpty())
            LogoDateTime->setObjectName(QStringLiteral("LogoDateTime"));
        LogoDateTime->resize(164, 100);
        gridLayout = new QGridLayout(LogoDateTime);
        gridLayout->setSpacing(2);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        mainFrame = new QFrame(LogoDateTime);
        mainFrame->setObjectName(QStringLiteral("mainFrame"));
        mainFrame->setFrameShape(QFrame::Panel);
        verticalLayout = new QVBoxLayout(mainFrame);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(7, 11, 7, -1);
        labelLeftTop = new QLabel(mainFrame);
        labelLeftTop->setObjectName(QStringLiteral("labelLeftTop"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(labelLeftTop->sizePolicy().hasHeightForWidth());
        labelLeftTop->setSizePolicy(sizePolicy);
        labelLeftTop->setMinimumSize(QSize(140, 20));
        labelLeftTop->setMaximumSize(QSize(140, 20));
        labelLeftTop->setAutoFillBackground(true);
        labelLeftTop->setPixmap(QPixmap(QString::fromUtf8(":/images/BOBST_Logo.png")));
        labelLeftTop->setScaledContents(true);
        labelLeftTop->setAlignment(Qt::AlignHCenter|Qt::AlignTop);

        verticalLayout->addWidget(labelLeftTop);

        labelDate = new QLabel(mainFrame);
        labelDate->setObjectName(QStringLiteral("labelDate"));
        QFont font;
        font.setPointSize(10);
        font.setBold(false);
        font.setWeight(50);
        font.setKerning(false);
        labelDate->setFont(font);
        labelDate->setLineWidth(0);
        labelDate->setScaledContents(true);
        labelDate->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(labelDate);

        labelTime = new QLabel(mainFrame);
        labelTime->setObjectName(QStringLiteral("labelTime"));
        sizePolicy.setHeightForWidth(labelTime->sizePolicy().hasHeightForWidth());
        labelTime->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(10);
        labelTime->setFont(font1);
        labelTime->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(labelTime);


        gridLayout->addWidget(mainFrame, 0, 0, 1, 1);


        retranslateUi(LogoDateTime);

        QMetaObject::connectSlotsByName(LogoDateTime);
    } // setupUi

    void retranslateUi(QWidget *LogoDateTime)
    {
        LogoDateTime->setWindowTitle(QApplication::translate("LogoDateTime", "Form", 0));
        labelLeftTop->setText(QString());
        labelDate->setText(QApplication::translate("LogoDateTime", "unknow", 0));
        labelTime->setText(QApplication::translate("LogoDateTime", "unknow", 0));
    } // retranslateUi

};

namespace Ui {
    class LogoDateTime: public Ui_LogoDateTime {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LOGODATETIME_H
