/********************************************************************************
** Form generated from reading UI file 'debugWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DEBUGWINDOW_H
#define UI_DEBUGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QTextEdit>
#include "ledManager.h"

QT_BEGIN_NAMESPACE

class Ui_DebugWindow
{
public:
    QGridLayout *gridLayout_3;
    QFrame *frameSaveFrame;
    QGridLayout *gridLayout;
    QLineEdit *lineEditFrameSize;
    QLineEdit *lineEditNbSavedFrame;
    QLabel *labelFrameSize;
    QLabel *labelNbSavedFrame;
    QLabel *labelTitleSaveConf;
    QLabel *labelFrameUnit;
    QFrame *frameFTDIConfig;
    QGridLayout *gridLayout_2;
    QPushButton *pushButtonSendChar;
    QDoubleSpinBox *doubleSpinBoxFTDICharToSend;
    QLineEdit *lineEditBaudrate;
    QLabel *labelBaudrateUnit;
    QLabel *labelBaudrate;
    QLabel *labelTitleSaveConf_2;
    QPushButton *pushButtonFTDIInfo;
    QPushButton *pushButtonFTDIStartReadData;
    QPushButton *pushButtonFTDIStopReadData;
    QPushButton *pushButtonCleanText;
    QCheckBox *checkBoxEmulationMode;
    QSpacerItem *verticalSpacer;
    QTextEdit *textEditDebug;
    QFrame *frame;
    ledManager *widget;

    void setupUi(QFrame *DebugWindow)
    {
        if (DebugWindow->objectName().isEmpty())
            DebugWindow->setObjectName(QStringLiteral("DebugWindow"));
        DebugWindow->resize(882, 383);
        DebugWindow->setFrameShape(QFrame::StyledPanel);
        DebugWindow->setFrameShadow(QFrame::Raised);
        gridLayout_3 = new QGridLayout(DebugWindow);
        gridLayout_3->setSpacing(5);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        gridLayout_3->setContentsMargins(11, 11, 11, 11);
        frameSaveFrame = new QFrame(DebugWindow);
        frameSaveFrame->setObjectName(QStringLiteral("frameSaveFrame"));
        frameSaveFrame->setFrameShape(QFrame::Box);
        frameSaveFrame->setFrameShadow(QFrame::Plain);
        gridLayout = new QGridLayout(frameSaveFrame);
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        lineEditFrameSize = new QLineEdit(frameSaveFrame);
        lineEditFrameSize->setObjectName(QStringLiteral("lineEditFrameSize"));
        lineEditFrameSize->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lineEditFrameSize, 2, 1, 1, 1);

        lineEditNbSavedFrame = new QLineEdit(frameSaveFrame);
        lineEditNbSavedFrame->setObjectName(QStringLiteral("lineEditNbSavedFrame"));
        lineEditNbSavedFrame->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(lineEditNbSavedFrame, 1, 1, 1, 1);

        labelFrameSize = new QLabel(frameSaveFrame);
        labelFrameSize->setObjectName(QStringLiteral("labelFrameSize"));

        gridLayout->addWidget(labelFrameSize, 2, 0, 1, 1);

        labelNbSavedFrame = new QLabel(frameSaveFrame);
        labelNbSavedFrame->setObjectName(QStringLiteral("labelNbSavedFrame"));

        gridLayout->addWidget(labelNbSavedFrame, 1, 0, 1, 1);

        labelTitleSaveConf = new QLabel(frameSaveFrame);
        labelTitleSaveConf->setObjectName(QStringLiteral("labelTitleSaveConf"));
        labelTitleSaveConf->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelTitleSaveConf, 0, 0, 1, 3);

        labelFrameUnit = new QLabel(frameSaveFrame);
        labelFrameUnit->setObjectName(QStringLiteral("labelFrameUnit"));

        gridLayout->addWidget(labelFrameUnit, 2, 2, 1, 1);


        gridLayout_3->addWidget(frameSaveFrame, 0, 1, 1, 1);

        frameFTDIConfig = new QFrame(DebugWindow);
        frameFTDIConfig->setObjectName(QStringLiteral("frameFTDIConfig"));
        frameFTDIConfig->setFrameShape(QFrame::Box);
        frameFTDIConfig->setFrameShadow(QFrame::Plain);
        gridLayout_2 = new QGridLayout(frameFTDIConfig);
        gridLayout_2->setSpacing(5);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(5, 5, 5, 5);
        pushButtonSendChar = new QPushButton(frameFTDIConfig);
        pushButtonSendChar->setObjectName(QStringLiteral("pushButtonSendChar"));

        gridLayout_2->addWidget(pushButtonSendChar, 3, 1, 1, 1);

        doubleSpinBoxFTDICharToSend = new QDoubleSpinBox(frameFTDIConfig);
        doubleSpinBoxFTDICharToSend->setObjectName(QStringLiteral("doubleSpinBoxFTDICharToSend"));
        doubleSpinBoxFTDICharToSend->setDecimals(0);
        doubleSpinBoxFTDICharToSend->setMaximum(255);
        doubleSpinBoxFTDICharToSend->setSingleStep(1);
        doubleSpinBoxFTDICharToSend->setValue(0);

        gridLayout_2->addWidget(doubleSpinBoxFTDICharToSend, 3, 0, 1, 1);

        lineEditBaudrate = new QLineEdit(frameFTDIConfig);
        lineEditBaudrate->setObjectName(QStringLiteral("lineEditBaudrate"));
        lineEditBaudrate->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout_2->addWidget(lineEditBaudrate, 1, 1, 1, 1);

        labelBaudrateUnit = new QLabel(frameFTDIConfig);
        labelBaudrateUnit->setObjectName(QStringLiteral("labelBaudrateUnit"));

        gridLayout_2->addWidget(labelBaudrateUnit, 1, 2, 1, 1);

        labelBaudrate = new QLabel(frameFTDIConfig);
        labelBaudrate->setObjectName(QStringLiteral("labelBaudrate"));

        gridLayout_2->addWidget(labelBaudrate, 1, 0, 1, 1);

        labelTitleSaveConf_2 = new QLabel(frameFTDIConfig);
        labelTitleSaveConf_2->setObjectName(QStringLiteral("labelTitleSaveConf_2"));
        labelTitleSaveConf_2->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(labelTitleSaveConf_2, 0, 0, 1, 3);

        pushButtonFTDIInfo = new QPushButton(frameFTDIConfig);
        pushButtonFTDIInfo->setObjectName(QStringLiteral("pushButtonFTDIInfo"));

        gridLayout_2->addWidget(pushButtonFTDIInfo, 4, 0, 1, 1);

        pushButtonFTDIStartReadData = new QPushButton(frameFTDIConfig);
        pushButtonFTDIStartReadData->setObjectName(QStringLiteral("pushButtonFTDIStartReadData"));

        gridLayout_2->addWidget(pushButtonFTDIStartReadData, 4, 1, 1, 1);

        pushButtonFTDIStopReadData = new QPushButton(frameFTDIConfig);
        pushButtonFTDIStopReadData->setObjectName(QStringLiteral("pushButtonFTDIStopReadData"));

        gridLayout_2->addWidget(pushButtonFTDIStopReadData, 4, 2, 1, 1);

        pushButtonCleanText = new QPushButton(frameFTDIConfig);
        pushButtonCleanText->setObjectName(QStringLiteral("pushButtonCleanText"));

        gridLayout_2->addWidget(pushButtonCleanText, 3, 2, 1, 1);


        gridLayout_3->addWidget(frameFTDIConfig, 0, 2, 1, 1);

        checkBoxEmulationMode = new QCheckBox(DebugWindow);
        checkBoxEmulationMode->setObjectName(QStringLiteral("checkBoxEmulationMode"));
        checkBoxEmulationMode->setMinimumSize(QSize(0, 40));
        QFont font;
        font.setPointSize(11);
        checkBoxEmulationMode->setFont(font);
        checkBoxEmulationMode->setStyleSheet(QStringLiteral("background-color: rgb(255, 195, 164);"));
        checkBoxEmulationMode->setChecked(false);

        gridLayout_3->addWidget(checkBoxEmulationMode, 1, 1, 1, 1);

        verticalSpacer = new QSpacerItem(20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding);

        gridLayout_3->addItem(verticalSpacer, 3, 1, 1, 1);

        textEditDebug = new QTextEdit(DebugWindow);
        textEditDebug->setObjectName(QStringLiteral("textEditDebug"));

        gridLayout_3->addWidget(textEditDebug, 0, 0, 4, 1);

        frame = new QFrame(DebugWindow);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::Panel);
        frame->setFrameShadow(QFrame::Plain);

        gridLayout_3->addWidget(frame, 1, 2, 1, 1);

        widget = new ledManager(DebugWindow);
        widget->setObjectName(QStringLiteral("widget"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widget->sizePolicy().hasHeightForWidth());
        widget->setSizePolicy(sizePolicy);
        widget->setMinimumSize(QSize(0, 80));
        widget->setMaximumSize(QSize(16777215, 80));

        gridLayout_3->addWidget(widget, 2, 1, 1, 1);


        retranslateUi(DebugWindow);

        QMetaObject::connectSlotsByName(DebugWindow);
    } // setupUi

    void retranslateUi(QFrame *DebugWindow)
    {
        DebugWindow->setWindowTitle(QApplication::translate("DebugWindow", "Frame", 0));
        lineEditFrameSize->setText(QApplication::translate("DebugWindow", "0", 0));
        lineEditNbSavedFrame->setText(QApplication::translate("DebugWindow", "0", 0));
        labelFrameSize->setText(QApplication::translate("DebugWindow", "Taille d'une trame", 0));
        labelNbSavedFrame->setText(QApplication::translate("DebugWindow", "Nb trames sauv\303\251es", 0));
        labelTitleSaveConf->setText(QApplication::translate("DebugWindow", "Configuration du sauvertage", 0));
        labelFrameUnit->setText(QApplication::translate("DebugWindow", "[Byte]", 0));
        pushButtonSendChar->setText(QApplication::translate("DebugWindow", "send char", 0));
        lineEditBaudrate->setText(QApplication::translate("DebugWindow", "0", 0));
        labelBaudrateUnit->setText(QApplication::translate("DebugWindow", "[bit/seconde]", 0));
        labelBaudrate->setText(QApplication::translate("DebugWindow", "Baudrate", 0));
        labelTitleSaveConf_2->setText(QApplication::translate("DebugWindow", "FTDI configuration", 0));
        pushButtonFTDIInfo->setText(QApplication::translate("DebugWindow", "Info Device", 0));
        pushButtonFTDIStartReadData->setText(QApplication::translate("DebugWindow", "start read data", 0));
        pushButtonFTDIStopReadData->setText(QApplication::translate("DebugWindow", "stop read data", 0));
        pushButtonCleanText->setText(QApplication::translate("DebugWindow", "clean text", 0));
        checkBoxEmulationMode->setText(QApplication::translate("DebugWindow", "In Emulation mode", 0));
    } // retranslateUi

};

namespace Ui {
    class DebugWindow: public Ui_DebugWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DEBUGWINDOW_H
