/****************************************************************************
** Meta object code from reading C++ file 'qcustomplot.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Datalogger/qcustomplot.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#include <QtCore/QSharedPointer>
#include <QtCore/QVector>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'qcustomplot.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_QCP_t {
    QByteArrayData data[62];
    char stringdata[713];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCP_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCP_t qt_meta_stringdata_QCP = {
    {
QT_MOC_LITERAL(0, 0, 3),
QT_MOC_LITERAL(1, 4, 14),
QT_MOC_LITERAL(2, 19, 14),
QT_MOC_LITERAL(3, 34, 19),
QT_MOC_LITERAL(4, 54, 13),
QT_MOC_LITERAL(5, 68, 9),
QT_MOC_LITERAL(6, 78, 12),
QT_MOC_LITERAL(7, 91, 15),
QT_MOC_LITERAL(8, 107, 10),
QT_MOC_LITERAL(9, 118, 10),
QT_MOC_LITERAL(10, 129, 6),
QT_MOC_LITERAL(11, 136, 10),
QT_MOC_LITERAL(12, 147, 10),
QT_MOC_LITERAL(13, 158, 6),
QT_MOC_LITERAL(14, 165, 7),
QT_MOC_LITERAL(15, 173, 5),
QT_MOC_LITERAL(16, 179, 8),
QT_MOC_LITERAL(17, 188, 5),
QT_MOC_LITERAL(18, 194, 6),
QT_MOC_LITERAL(19, 201, 11),
QT_MOC_LITERAL(20, 213, 18),
QT_MOC_LITERAL(21, 232, 6),
QT_MOC_LITERAL(22, 239, 6),
QT_MOC_LITERAL(23, 246, 9),
QT_MOC_LITERAL(24, 256, 8),
QT_MOC_LITERAL(25, 265, 13),
QT_MOC_LITERAL(26, 279, 12),
QT_MOC_LITERAL(27, 292, 7),
QT_MOC_LITERAL(28, 300, 10),
QT_MOC_LITERAL(29, 311, 7),
QT_MOC_LITERAL(30, 319, 10),
QT_MOC_LITERAL(31, 330, 7),
QT_MOC_LITERAL(32, 338, 5),
QT_MOC_LITERAL(33, 344, 6),
QT_MOC_LITERAL(34, 351, 19),
QT_MOC_LITERAL(35, 371, 12),
QT_MOC_LITERAL(36, 384, 6),
QT_MOC_LITERAL(37, 391, 15),
QT_MOC_LITERAL(38, 407, 18),
QT_MOC_LITERAL(39, 426, 13),
QT_MOC_LITERAL(40, 440, 13),
QT_MOC_LITERAL(41, 454, 11),
QT_MOC_LITERAL(42, 466, 10),
QT_MOC_LITERAL(43, 477, 10),
QT_MOC_LITERAL(44, 488, 12),
QT_MOC_LITERAL(45, 501, 17),
QT_MOC_LITERAL(46, 519, 11),
QT_MOC_LITERAL(47, 531, 13),
QT_MOC_LITERAL(48, 545, 12),
QT_MOC_LITERAL(49, 558, 12),
QT_MOC_LITERAL(50, 571, 12),
QT_MOC_LITERAL(51, 584, 17),
QT_MOC_LITERAL(52, 602, 7),
QT_MOC_LITERAL(53, 610, 7),
QT_MOC_LITERAL(54, 618, 9),
QT_MOC_LITERAL(55, 628, 9),
QT_MOC_LITERAL(56, 638, 13),
QT_MOC_LITERAL(57, 652, 6),
QT_MOC_LITERAL(58, 659, 7),
QT_MOC_LITERAL(59, 667, 12),
QT_MOC_LITERAL(60, 680, 11),
QT_MOC_LITERAL(61, 692, 20)
    },
    "QCP\0ResolutionUnit\0ruDotsPerMeter\0"
    "ruDotsPerCentimeter\0ruDotsPerInch\0"
    "ExportPen\0epNoCosmetic\0epAllowCosmetic\0"
    "SignDomain\0sdNegative\0sdBoth\0sdPositive\0"
    "MarginSide\0msLeft\0msRight\0msTop\0"
    "msBottom\0msAll\0msNone\0MarginSides\0"
    "AntialiasedElement\0aeAxes\0aeGrid\0"
    "aeSubGrid\0aeLegend\0aeLegendItems\0"
    "aePlottables\0aeItems\0aeScatters\0aeFills\0"
    "aeZeroLine\0aeOther\0aeAll\0aeNone\0"
    "AntialiasedElements\0PlottingHint\0"
    "phNone\0phFastPolylines\0phImmediateRefresh\0"
    "phCacheLabels\0PlottingHints\0Interaction\0"
    "iRangeDrag\0iRangeZoom\0iMultiSelect\0"
    "iSelectPlottables\0iSelectAxes\0"
    "iSelectLegend\0iSelectItems\0iSelectOther\0"
    "Interactions\0SelectionRectMode\0srmNone\0"
    "srmZoom\0srmSelect\0srmCustom\0SelectionType\0"
    "stNone\0stWhole\0stSingleData\0stDataRange\0"
    "stMultipleDataRanges"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCP[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
      13,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    3,   66,
       5, 0x0,    2,   72,
       8, 0x0,    3,   76,
      12, 0x0,    6,   82,
      19, 0x1,    6,   94,
      20, 0x0,   13,  106,
      34, 0x1,   13,  132,
      35, 0x0,    4,  158,
      40, 0x1,    4,  166,
      41, 0x0,    8,  174,
      50, 0x1,    8,  190,
      51, 0x0,    4,  206,
      56, 0x0,    5,  214,

 // enum data: key, value
       2, uint(QCP::ruDotsPerMeter),
       3, uint(QCP::ruDotsPerCentimeter),
       4, uint(QCP::ruDotsPerInch),
       6, uint(QCP::epNoCosmetic),
       7, uint(QCP::epAllowCosmetic),
       9, uint(QCP::sdNegative),
      10, uint(QCP::sdBoth),
      11, uint(QCP::sdPositive),
      13, uint(QCP::msLeft),
      14, uint(QCP::msRight),
      15, uint(QCP::msTop),
      16, uint(QCP::msBottom),
      17, uint(QCP::msAll),
      18, uint(QCP::msNone),
      13, uint(QCP::msLeft),
      14, uint(QCP::msRight),
      15, uint(QCP::msTop),
      16, uint(QCP::msBottom),
      17, uint(QCP::msAll),
      18, uint(QCP::msNone),
      21, uint(QCP::aeAxes),
      22, uint(QCP::aeGrid),
      23, uint(QCP::aeSubGrid),
      24, uint(QCP::aeLegend),
      25, uint(QCP::aeLegendItems),
      26, uint(QCP::aePlottables),
      27, uint(QCP::aeItems),
      28, uint(QCP::aeScatters),
      29, uint(QCP::aeFills),
      30, uint(QCP::aeZeroLine),
      31, uint(QCP::aeOther),
      32, uint(QCP::aeAll),
      33, uint(QCP::aeNone),
      21, uint(QCP::aeAxes),
      22, uint(QCP::aeGrid),
      23, uint(QCP::aeSubGrid),
      24, uint(QCP::aeLegend),
      25, uint(QCP::aeLegendItems),
      26, uint(QCP::aePlottables),
      27, uint(QCP::aeItems),
      28, uint(QCP::aeScatters),
      29, uint(QCP::aeFills),
      30, uint(QCP::aeZeroLine),
      31, uint(QCP::aeOther),
      32, uint(QCP::aeAll),
      33, uint(QCP::aeNone),
      36, uint(QCP::phNone),
      37, uint(QCP::phFastPolylines),
      38, uint(QCP::phImmediateRefresh),
      39, uint(QCP::phCacheLabels),
      36, uint(QCP::phNone),
      37, uint(QCP::phFastPolylines),
      38, uint(QCP::phImmediateRefresh),
      39, uint(QCP::phCacheLabels),
      42, uint(QCP::iRangeDrag),
      43, uint(QCP::iRangeZoom),
      44, uint(QCP::iMultiSelect),
      45, uint(QCP::iSelectPlottables),
      46, uint(QCP::iSelectAxes),
      47, uint(QCP::iSelectLegend),
      48, uint(QCP::iSelectItems),
      49, uint(QCP::iSelectOther),
      42, uint(QCP::iRangeDrag),
      43, uint(QCP::iRangeZoom),
      44, uint(QCP::iMultiSelect),
      45, uint(QCP::iSelectPlottables),
      46, uint(QCP::iSelectAxes),
      47, uint(QCP::iSelectLegend),
      48, uint(QCP::iSelectItems),
      49, uint(QCP::iSelectOther),
      52, uint(QCP::srmNone),
      53, uint(QCP::srmZoom),
      54, uint(QCP::srmSelect),
      55, uint(QCP::srmCustom),
      57, uint(QCP::stNone),
      58, uint(QCP::stWhole),
      59, uint(QCP::stSingleData),
      60, uint(QCP::stDataRange),
      61, uint(QCP::stMultipleDataRanges),

       0        // eod
};

const QMetaObject QCP::staticMetaObject = {
    { 0, qt_meta_stringdata_QCP.data,
      qt_meta_data_QCP,  0, 0, 0}
};

struct qt_meta_stringdata_QCPPainter_t {
    QByteArrayData data[7];
    char stringdata[85];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPPainter_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPPainter_t qt_meta_stringdata_QCPPainter = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 11),
QT_MOC_LITERAL(2, 23, 9),
QT_MOC_LITERAL(3, 33, 12),
QT_MOC_LITERAL(4, 46, 11),
QT_MOC_LITERAL(5, 58, 13),
QT_MOC_LITERAL(6, 72, 12)
    },
    "QCPPainter\0PainterMode\0pmDefault\0"
    "pmVectorized\0pmNoCaching\0pmNonCosmetic\0"
    "PainterModes"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPPainter[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    4,   22,
       6, 0x1,    4,   30,

 // enum data: key, value
       2, uint(QCPPainter::pmDefault),
       3, uint(QCPPainter::pmVectorized),
       4, uint(QCPPainter::pmNoCaching),
       5, uint(QCPPainter::pmNonCosmetic),
       2, uint(QCPPainter::pmDefault),
       3, uint(QCPPainter::pmVectorized),
       4, uint(QCPPainter::pmNoCaching),
       5, uint(QCPPainter::pmNonCosmetic),

       0        // eod
};

const QMetaObject QCPPainter::staticMetaObject = {
    { &QPainter::staticMetaObject, qt_meta_stringdata_QCPPainter.data,
      qt_meta_data_QCPPainter,  0, 0, 0}
};

struct qt_meta_stringdata_QCPLayer_t {
    QByteArrayData data[12];
    char stringdata[118];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayer_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayer_t qt_meta_stringdata_QCPLayer = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 10),
QT_MOC_LITERAL(2, 20, 12),
QT_MOC_LITERAL(3, 33, 4),
QT_MOC_LITERAL(4, 38, 5),
QT_MOC_LITERAL(5, 44, 8),
QT_MOC_LITERAL(6, 53, 20),
QT_MOC_LITERAL(7, 74, 7),
QT_MOC_LITERAL(8, 82, 4),
QT_MOC_LITERAL(9, 87, 9),
QT_MOC_LITERAL(10, 97, 9),
QT_MOC_LITERAL(11, 107, 10)
    },
    "QCPLayer\0parentPlot\0QCustomPlot*\0name\0"
    "index\0children\0QList<QCPLayerable*>\0"
    "visible\0mode\0LayerMode\0lmLogical\0"
    "lmBuffered"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       1,   32, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x00095009,
       3, QMetaType::QString, 0x00095001,
       4, QMetaType::Int, 0x00095001,
       5, 0x80000000 | 6, 0x00095009,
       7, QMetaType::Bool, 0x00095103,
       8, 0x80000000 | 9, 0x0009510b,

 // enums: name, flags, count, data
       9, 0x0,    2,   36,

 // enum data: key, value
      10, uint(QCPLayer::lmLogical),
      11, uint(QCPLayer::lmBuffered),

       0        // eod
};

void QCPLayer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCustomPlot* >(); break;
        case 3:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<QCPLayerable*> >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPLayer::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPLayer.data,
      qt_meta_data_QCPLayer,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLayer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayer.stringdata))
        return static_cast<void*>(const_cast< QCPLayer*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPLayer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCustomPlot**>(_v) = parentPlot(); break;
        case 1: *reinterpret_cast< QString*>(_v) = name(); break;
        case 2: *reinterpret_cast< int*>(_v) = index(); break;
        case 3: *reinterpret_cast< QList<QCPLayerable*>*>(_v) = children(); break;
        case 4: *reinterpret_cast< bool*>(_v) = visible(); break;
        case 5: *reinterpret_cast< LayerMode*>(_v) = mode(); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 4: setVisible(*reinterpret_cast< bool*>(_v)); break;
        case 5: setMode(*reinterpret_cast< LayerMode*>(_v)); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPLayerable_t {
    QByteArrayData data[13];
    char stringdata[135];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayerable_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayerable_t qt_meta_stringdata_QCPLayerable = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 12),
QT_MOC_LITERAL(2, 26, 0),
QT_MOC_LITERAL(3, 27, 9),
QT_MOC_LITERAL(4, 37, 8),
QT_MOC_LITERAL(5, 46, 8),
QT_MOC_LITERAL(6, 55, 5),
QT_MOC_LITERAL(7, 61, 7),
QT_MOC_LITERAL(8, 69, 10),
QT_MOC_LITERAL(9, 80, 12),
QT_MOC_LITERAL(10, 93, 15),
QT_MOC_LITERAL(11, 109, 13),
QT_MOC_LITERAL(12, 123, 11)
    },
    "QCPLayerable\0layerChanged\0\0QCPLayer*\0"
    "newLayer\0setLayer\0layer\0visible\0"
    "parentPlot\0QCustomPlot*\0parentLayerable\0"
    "QCPLayerable*\0antialiased"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayerable[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       5,   30, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   27,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Bool, 0x80000000 | 3,    6,

 // properties: name, type, flags
       7, QMetaType::Bool, 0x00095103,
       8, 0x80000000 | 9, 0x00095009,
      10, 0x80000000 | 11, 0x00095009,
       6, 0x80000000 | 3, 0x0049510b,
      12, QMetaType::Bool, 0x00095103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,

       0        // eod
};

void QCPLayerable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPLayerable *_t = static_cast<QCPLayerable *>(_o);
        switch (_id) {
        case 0: _t->layerChanged((*reinterpret_cast< QCPLayer*(*)>(_a[1]))); break;
        case 1: { bool _r = _t->setLayer((*reinterpret_cast< QCPLayer*(*)>(_a[1])));
            if (_a[0]) *reinterpret_cast< bool*>(_a[0]) = _r; }  break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayer* >(); break;
            }
            break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayer* >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPLayerable::*_t)(QCPLayer * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPLayerable::layerChanged)) {
                *result = 0;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayer* >(); break;
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayerable* >(); break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCustomPlot* >(); break;
        }
    }

}

const QMetaObject QCPLayerable::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPLayerable.data,
      qt_meta_data_QCPLayerable,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLayerable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayerable::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayerable.stringdata))
        return static_cast<void*>(const_cast< QCPLayerable*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPLayerable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = visible(); break;
        case 1: *reinterpret_cast< QCustomPlot**>(_v) = parentPlot(); break;
        case 2: *reinterpret_cast< QCPLayerable**>(_v) = parentLayerable(); break;
        case 3: *reinterpret_cast< QCPLayer**>(_v) = layer(); break;
        case 4: *reinterpret_cast< bool*>(_v) = antialiased(); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setVisible(*reinterpret_cast< bool*>(_v)); break;
        case 3: setLayer(*reinterpret_cast< QCPLayer**>(_v)); break;
        case 4: setAntialiased(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPLayerable::layerChanged(QCPLayer * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
struct qt_meta_stringdata_QCPSelectionRect_t {
    QByteArrayData data[11];
    char stringdata[96];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPSelectionRect_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPSelectionRect_t qt_meta_stringdata_QCPSelectionRect = {
    {
QT_MOC_LITERAL(0, 0, 16),
QT_MOC_LITERAL(1, 17, 7),
QT_MOC_LITERAL(2, 25, 0),
QT_MOC_LITERAL(3, 26, 12),
QT_MOC_LITERAL(4, 39, 5),
QT_MOC_LITERAL(5, 45, 7),
QT_MOC_LITERAL(6, 53, 4),
QT_MOC_LITERAL(7, 58, 8),
QT_MOC_LITERAL(8, 67, 12),
QT_MOC_LITERAL(9, 80, 8),
QT_MOC_LITERAL(10, 89, 6)
    },
    "QCPSelectionRect\0started\0\0QMouseEvent*\0"
    "event\0changed\0rect\0canceled\0QInputEvent*\0"
    "accepted\0cancel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPSelectionRect[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x06 /* Public */,
       5,    2,   42,    2, 0x06 /* Public */,
       7,    2,   47,    2, 0x06 /* Public */,
       9,    2,   52,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    0,   57,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QRect, 0x80000000 | 3,    6,    4,
    QMetaType::Void, QMetaType::QRect, 0x80000000 | 8,    6,    4,
    QMetaType::Void, QMetaType::QRect, 0x80000000 | 3,    6,    4,

 // slots: parameters
    QMetaType::Void,

       0        // eod
};

void QCPSelectionRect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPSelectionRect *_t = static_cast<QCPSelectionRect *>(_o);
        switch (_id) {
        case 0: _t->started((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 1: _t->changed((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 2: _t->canceled((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< QInputEvent*(*)>(_a[2]))); break;
        case 3: _t->accepted((*reinterpret_cast< const QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 4: _t->cancel(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPSelectionRect::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPSelectionRect::started)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPSelectionRect::*_t)(const QRect & , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPSelectionRect::changed)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPSelectionRect::*_t)(const QRect & , QInputEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPSelectionRect::canceled)) {
                *result = 2;
            }
        }
        {
            typedef void (QCPSelectionRect::*_t)(const QRect & , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPSelectionRect::accepted)) {
                *result = 3;
            }
        }
    }
}

const QMetaObject QCPSelectionRect::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPSelectionRect.data,
      qt_meta_data_QCPSelectionRect,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPSelectionRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPSelectionRect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPSelectionRect.stringdata))
        return static_cast<void*>(const_cast< QCPSelectionRect*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPSelectionRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
    return _id;
}

// SIGNAL 0
void QCPSelectionRect::started(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPSelectionRect::changed(const QRect & _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPSelectionRect::canceled(const QRect & _t1, QInputEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPSelectionRect::accepted(const QRect & _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
struct qt_meta_stringdata_QCPMarginGroup_t {
    QByteArrayData data[1];
    char stringdata[15];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPMarginGroup_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPMarginGroup_t qt_meta_stringdata_QCPMarginGroup = {
    {
QT_MOC_LITERAL(0, 0, 14)
    },
    "QCPMarginGroup"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPMarginGroup[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPMarginGroup::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPMarginGroup::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPMarginGroup.data,
      qt_meta_data_QCPMarginGroup,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPMarginGroup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPMarginGroup::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPMarginGroup.stringdata))
        return static_cast<void*>(const_cast< QCPMarginGroup*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPMarginGroup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLayoutElement_t {
    QByteArrayData data[14];
    char stringdata[151];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayoutElement_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayoutElement_t qt_meta_stringdata_QCPLayoutElement = {
    {
QT_MOC_LITERAL(0, 0, 16),
QT_MOC_LITERAL(1, 17, 6),
QT_MOC_LITERAL(2, 24, 10),
QT_MOC_LITERAL(3, 35, 4),
QT_MOC_LITERAL(4, 40, 9),
QT_MOC_LITERAL(5, 50, 7),
QT_MOC_LITERAL(6, 58, 8),
QT_MOC_LITERAL(7, 67, 14),
QT_MOC_LITERAL(8, 82, 11),
QT_MOC_LITERAL(9, 94, 11),
QT_MOC_LITERAL(10, 106, 11),
QT_MOC_LITERAL(11, 118, 13),
QT_MOC_LITERAL(12, 132, 9),
QT_MOC_LITERAL(13, 142, 8)
    },
    "QCPLayoutElement\0layout\0QCPLayout*\0"
    "rect\0outerRect\0margins\0QMargins\0"
    "minimumMargins\0minimumSize\0maximumSize\0"
    "UpdatePhase\0upPreparation\0upMargins\0"
    "upLayout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayoutElement[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       7,   14, // properties
       1,   35, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x00095009,
       3, QMetaType::QRect, 0x00095001,
       4, QMetaType::QRect, 0x00095103,
       5, 0x80000000 | 6, 0x0009510b,
       7, 0x80000000 | 6, 0x0009510b,
       8, QMetaType::QSize, 0x00095103,
       9, QMetaType::QSize, 0x00095103,

 // enums: name, flags, count, data
      10, 0x0,    3,   39,

 // enum data: key, value
      11, uint(QCPLayoutElement::upPreparation),
      12, uint(QCPLayoutElement::upMargins),
      13, uint(QCPLayoutElement::upLayout),

       0        // eod
};

void QCPLayoutElement::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayout* >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPLayoutElement::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPLayoutElement.data,
      qt_meta_data_QCPLayoutElement,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLayoutElement::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayoutElement::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutElement.stringdata))
        return static_cast<void*>(const_cast< QCPLayoutElement*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPLayoutElement::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPLayout**>(_v) = layout(); break;
        case 1: *reinterpret_cast< QRect*>(_v) = rect(); break;
        case 2: *reinterpret_cast< QRect*>(_v) = outerRect(); break;
        case 3: *reinterpret_cast< QMargins*>(_v) = margins(); break;
        case 4: *reinterpret_cast< QMargins*>(_v) = minimumMargins(); break;
        case 5: *reinterpret_cast< QSize*>(_v) = minimumSize(); break;
        case 6: *reinterpret_cast< QSize*>(_v) = maximumSize(); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setOuterRect(*reinterpret_cast< QRect*>(_v)); break;
        case 3: setMargins(*reinterpret_cast< QMargins*>(_v)); break;
        case 4: setMinimumMargins(*reinterpret_cast< QMargins*>(_v)); break;
        case 5: setMinimumSize(*reinterpret_cast< QSize*>(_v)); break;
        case 6: setMaximumSize(*reinterpret_cast< QSize*>(_v)); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPLayout_t {
    QByteArrayData data[1];
    char stringdata[10];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayout_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayout_t qt_meta_stringdata_QCPLayout = {
    {
QT_MOC_LITERAL(0, 0, 9)
    },
    "QCPLayout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayout[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPLayout::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPLayout::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPLayout.data,
      qt_meta_data_QCPLayout,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLayout::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayout::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayout.stringdata))
        return static_cast<void*>(const_cast< QCPLayout*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPLayout::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLayoutGrid_t {
    QByteArrayData data[13];
    char stringdata[165];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayoutGrid_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayoutGrid_t qt_meta_stringdata_QCPLayoutGrid = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 8),
QT_MOC_LITERAL(2, 23, 11),
QT_MOC_LITERAL(3, 35, 20),
QT_MOC_LITERAL(4, 56, 13),
QT_MOC_LITERAL(5, 70, 17),
QT_MOC_LITERAL(6, 88, 13),
QT_MOC_LITERAL(7, 102, 10),
QT_MOC_LITERAL(8, 113, 9),
QT_MOC_LITERAL(9, 123, 9),
QT_MOC_LITERAL(10, 133, 4),
QT_MOC_LITERAL(11, 138, 11),
QT_MOC_LITERAL(12, 150, 14)
    },
    "QCPLayoutGrid\0rowCount\0columnCount\0"
    "columnStretchFactors\0QList<double>\0"
    "rowStretchFactors\0columnSpacing\0"
    "rowSpacing\0fillOrder\0FillOrder\0wrap\0"
    "foRowsFirst\0foColumnsFirst"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayoutGrid[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       8,   14, // properties
       1,   38, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Int, 0x00095001,
       2, QMetaType::Int, 0x00095001,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 4, 0x0009510b,
       6, QMetaType::Int, 0x00095103,
       7, QMetaType::Int, 0x00095103,
       8, 0x80000000 | 9, 0x0009510b,
      10, QMetaType::Int, 0x00095103,

 // enums: name, flags, count, data
       9, 0x0,    2,   42,

 // enum data: key, value
      11, uint(QCPLayoutGrid::foRowsFirst),
      12, uint(QCPLayoutGrid::foColumnsFirst),

       0        // eod
};

void QCPLayoutGrid::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QList<double> >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPLayoutGrid::staticMetaObject = {
    { &QCPLayout::staticMetaObject, qt_meta_stringdata_QCPLayoutGrid.data,
      qt_meta_data_QCPLayoutGrid,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLayoutGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayoutGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutGrid.stringdata))
        return static_cast<void*>(const_cast< QCPLayoutGrid*>(this));
    return QCPLayout::qt_metacast(_clname);
}

int QCPLayoutGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayout::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< int*>(_v) = rowCount(); break;
        case 1: *reinterpret_cast< int*>(_v) = columnCount(); break;
        case 2: *reinterpret_cast< QList<double>*>(_v) = columnStretchFactors(); break;
        case 3: *reinterpret_cast< QList<double>*>(_v) = rowStretchFactors(); break;
        case 4: *reinterpret_cast< int*>(_v) = columnSpacing(); break;
        case 5: *reinterpret_cast< int*>(_v) = rowSpacing(); break;
        case 6: *reinterpret_cast< FillOrder*>(_v) = fillOrder(); break;
        case 7: *reinterpret_cast< int*>(_v) = wrap(); break;
        default: break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setColumnStretchFactors(*reinterpret_cast< QList<double>*>(_v)); break;
        case 3: setRowStretchFactors(*reinterpret_cast< QList<double>*>(_v)); break;
        case 4: setColumnSpacing(*reinterpret_cast< int*>(_v)); break;
        case 5: setRowSpacing(*reinterpret_cast< int*>(_v)); break;
        case 6: setFillOrder(*reinterpret_cast< FillOrder*>(_v)); break;
        case 7: setWrap(*reinterpret_cast< int*>(_v)); break;
        default: break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPLayoutInset_t {
    QByteArrayData data[4];
    char stringdata[53];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLayoutInset_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLayoutInset_t qt_meta_stringdata_QCPLayoutInset = {
    {
QT_MOC_LITERAL(0, 0, 14),
QT_MOC_LITERAL(1, 15, 14),
QT_MOC_LITERAL(2, 30, 6),
QT_MOC_LITERAL(3, 37, 15)
    },
    "QCPLayoutInset\0InsetPlacement\0ipFree\0"
    "ipBorderAligned"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLayoutInset[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    2,   18,

 // enum data: key, value
       2, uint(QCPLayoutInset::ipFree),
       3, uint(QCPLayoutInset::ipBorderAligned),

       0        // eod
};

void QCPLayoutInset::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPLayoutInset::staticMetaObject = {
    { &QCPLayout::staticMetaObject, qt_meta_stringdata_QCPLayoutInset.data,
      qt_meta_data_QCPLayoutInset,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLayoutInset::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLayoutInset::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLayoutInset.stringdata))
        return static_cast<void*>(const_cast< QCPLayoutInset*>(this));
    return QCPLayout::qt_metacast(_clname);
}

int QCPLayoutInset::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayout::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLineEnding_t {
    QByteArrayData data[12];
    char stringdata[124];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLineEnding_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLineEnding_t qt_meta_stringdata_QCPLineEnding = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 11),
QT_MOC_LITERAL(2, 26, 6),
QT_MOC_LITERAL(3, 33, 11),
QT_MOC_LITERAL(4, 45, 12),
QT_MOC_LITERAL(5, 58, 11),
QT_MOC_LITERAL(6, 70, 6),
QT_MOC_LITERAL(7, 77, 8),
QT_MOC_LITERAL(8, 86, 9),
QT_MOC_LITERAL(9, 96, 5),
QT_MOC_LITERAL(10, 102, 9),
QT_MOC_LITERAL(11, 112, 11)
    },
    "QCPLineEnding\0EndingStyle\0esNone\0"
    "esFlatArrow\0esSpikeArrow\0esLineArrow\0"
    "esDisc\0esSquare\0esDiamond\0esBar\0"
    "esHalfBar\0esSkewedBar"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLineEnding[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,   10,   18,

 // enum data: key, value
       2, uint(QCPLineEnding::esNone),
       3, uint(QCPLineEnding::esFlatArrow),
       4, uint(QCPLineEnding::esSpikeArrow),
       5, uint(QCPLineEnding::esLineArrow),
       6, uint(QCPLineEnding::esDisc),
       7, uint(QCPLineEnding::esSquare),
       8, uint(QCPLineEnding::esDiamond),
       9, uint(QCPLineEnding::esBar),
      10, uint(QCPLineEnding::esHalfBar),
      11, uint(QCPLineEnding::esSkewedBar),

       0        // eod
};

const QMetaObject QCPLineEnding::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPLineEnding.data,
      qt_meta_data_QCPLineEnding,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAxisTicker_t {
    QByteArrayData data[4];
    char stringdata[63];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxisTicker_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxisTicker_t qt_meta_stringdata_QCPAxisTicker = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 16),
QT_MOC_LITERAL(2, 31, 14),
QT_MOC_LITERAL(3, 46, 16)
    },
    "QCPAxisTicker\0TickStepStrategy\0"
    "tssReadability\0tssMeetTickCount"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxisTicker[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    2,   18,

 // enum data: key, value
       2, uint(QCPAxisTicker::tssReadability),
       3, uint(QCPAxisTicker::tssMeetTickCount),

       0        // eod
};

const QMetaObject QCPAxisTicker::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPAxisTicker.data,
      qt_meta_data_QCPAxisTicker,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAxisTickerTime_t {
    QByteArrayData data[7];
    char stringdata[77];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxisTickerTime_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxisTickerTime_t qt_meta_stringdata_QCPAxisTickerTime = {
    {
QT_MOC_LITERAL(0, 0, 17),
QT_MOC_LITERAL(1, 18, 8),
QT_MOC_LITERAL(2, 27, 14),
QT_MOC_LITERAL(3, 42, 9),
QT_MOC_LITERAL(4, 52, 9),
QT_MOC_LITERAL(5, 62, 7),
QT_MOC_LITERAL(6, 70, 6)
    },
    "QCPAxisTickerTime\0TimeUnit\0tuMilliseconds\0"
    "tuSeconds\0tuMinutes\0tuHours\0tuDays"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxisTickerTime[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    5,   18,

 // enum data: key, value
       2, uint(QCPAxisTickerTime::tuMilliseconds),
       3, uint(QCPAxisTickerTime::tuSeconds),
       4, uint(QCPAxisTickerTime::tuMinutes),
       5, uint(QCPAxisTickerTime::tuHours),
       6, uint(QCPAxisTickerTime::tuDays),

       0        // eod
};

const QMetaObject QCPAxisTickerTime::staticMetaObject = {
    { &QCPAxisTicker::staticMetaObject, qt_meta_stringdata_QCPAxisTickerTime.data,
      qt_meta_data_QCPAxisTickerTime,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAxisTickerFixed_t {
    QByteArrayData data[5];
    char stringdata[61];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxisTickerFixed_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxisTickerFixed_t qt_meta_stringdata_QCPAxisTickerFixed = {
    {
QT_MOC_LITERAL(0, 0, 18),
QT_MOC_LITERAL(1, 19, 13),
QT_MOC_LITERAL(2, 33, 6),
QT_MOC_LITERAL(3, 40, 11),
QT_MOC_LITERAL(4, 52, 8)
    },
    "QCPAxisTickerFixed\0ScaleStrategy\0"
    "ssNone\0ssMultiples\0ssPowers"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxisTickerFixed[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    3,   18,

 // enum data: key, value
       2, uint(QCPAxisTickerFixed::ssNone),
       3, uint(QCPAxisTickerFixed::ssMultiples),
       4, uint(QCPAxisTickerFixed::ssPowers),

       0        // eod
};

const QMetaObject QCPAxisTickerFixed::staticMetaObject = {
    { &QCPAxisTicker::staticMetaObject, qt_meta_stringdata_QCPAxisTickerFixed.data,
      qt_meta_data_QCPAxisTickerFixed,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAxisTickerPi_t {
    QByteArrayData data[5];
    char stringdata[82];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxisTickerPi_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxisTickerPi_t qt_meta_stringdata_QCPAxisTickerPi = {
    {
QT_MOC_LITERAL(0, 0, 15),
QT_MOC_LITERAL(1, 16, 13),
QT_MOC_LITERAL(2, 30, 15),
QT_MOC_LITERAL(3, 46, 16),
QT_MOC_LITERAL(4, 63, 18)
    },
    "QCPAxisTickerPi\0FractionStyle\0"
    "fsFloatingPoint\0fsAsciiFractions\0"
    "fsUnicodeFractions"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxisTickerPi[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    3,   18,

 // enum data: key, value
       2, uint(QCPAxisTickerPi::fsFloatingPoint),
       3, uint(QCPAxisTickerPi::fsAsciiFractions),
       4, uint(QCPAxisTickerPi::fsUnicodeFractions),

       0        // eod
};

const QMetaObject QCPAxisTickerPi::staticMetaObject = {
    { &QCPAxisTicker::staticMetaObject, qt_meta_stringdata_QCPAxisTickerPi.data,
      qt_meta_data_QCPAxisTickerPi,  0, 0, 0}
};

struct qt_meta_stringdata_QCPGrid_t {
    QByteArrayData data[7];
    char stringdata[89];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPGrid_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPGrid_t qt_meta_stringdata_QCPGrid = {
    {
QT_MOC_LITERAL(0, 0, 7),
QT_MOC_LITERAL(1, 8, 14),
QT_MOC_LITERAL(2, 23, 18),
QT_MOC_LITERAL(3, 42, 19),
QT_MOC_LITERAL(4, 62, 3),
QT_MOC_LITERAL(5, 66, 10),
QT_MOC_LITERAL(6, 77, 11)
    },
    "QCPGrid\0subGridVisible\0antialiasedSubGrid\0"
    "antialiasedZeroLine\0pen\0subGridPen\0"
    "zeroLinePen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPGrid[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Bool, 0x00095103,
       2, QMetaType::Bool, 0x00095103,
       3, QMetaType::Bool, 0x00095103,
       4, QMetaType::QPen, 0x00095103,
       5, QMetaType::QPen, 0x00095103,
       6, QMetaType::QPen, 0x00095103,

       0        // eod
};

void QCPGrid::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPGrid::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPGrid.data,
      qt_meta_data_QCPGrid,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPGrid::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPGrid::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPGrid.stringdata))
        return static_cast<void*>(const_cast< QCPGrid*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPGrid::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = subGridVisible(); break;
        case 1: *reinterpret_cast< bool*>(_v) = antialiasedSubGrid(); break;
        case 2: *reinterpret_cast< bool*>(_v) = antialiasedZeroLine(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = subGridPen(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = zeroLinePen(); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setSubGridVisible(*reinterpret_cast< bool*>(_v)); break;
        case 1: setAntialiasedSubGrid(*reinterpret_cast< bool*>(_v)); break;
        case 2: setAntialiasedZeroLine(*reinterpret_cast< bool*>(_v)); break;
        case 3: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setSubGridPen(*reinterpret_cast< QPen*>(_v)); break;
        case 5: setZeroLinePen(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPAxis_t {
    QByteArrayData data[84];
    char stringdata[1044];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxis_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxis_t qt_meta_stringdata_QCPAxis = {
    {
QT_MOC_LITERAL(0, 0, 7),
QT_MOC_LITERAL(1, 8, 12),
QT_MOC_LITERAL(2, 21, 0),
QT_MOC_LITERAL(3, 22, 8),
QT_MOC_LITERAL(4, 31, 8),
QT_MOC_LITERAL(5, 40, 8),
QT_MOC_LITERAL(6, 49, 16),
QT_MOC_LITERAL(7, 66, 18),
QT_MOC_LITERAL(8, 85, 9),
QT_MOC_LITERAL(9, 95, 16),
QT_MOC_LITERAL(10, 112, 24),
QT_MOC_LITERAL(11, 137, 5),
QT_MOC_LITERAL(12, 143, 17),
QT_MOC_LITERAL(13, 161, 12),
QT_MOC_LITERAL(14, 174, 4),
QT_MOC_LITERAL(15, 179, 8),
QT_MOC_LITERAL(16, 188, 5),
QT_MOC_LITERAL(17, 194, 18),
QT_MOC_LITERAL(18, 213, 15),
QT_MOC_LITERAL(19, 229, 16),
QT_MOC_LITERAL(20, 246, 13),
QT_MOC_LITERAL(21, 260, 8),
QT_MOC_LITERAL(22, 269, 8),
QT_MOC_LITERAL(23, 278, 8),
QT_MOC_LITERAL(24, 287, 12),
QT_MOC_LITERAL(25, 300, 9),
QT_MOC_LITERAL(26, 310, 13),
QT_MOC_LITERAL(27, 324, 6),
QT_MOC_LITERAL(28, 331, 29),
QT_MOC_LITERAL(29, 361, 5),
QT_MOC_LITERAL(30, 367, 10),
QT_MOC_LITERAL(31, 378, 16),
QT_MOC_LITERAL(32, 395, 13),
QT_MOC_LITERAL(33, 409, 14),
QT_MOC_LITERAL(34, 424, 17),
QT_MOC_LITERAL(35, 442, 13),
QT_MOC_LITERAL(36, 456, 9),
QT_MOC_LITERAL(37, 466, 12),
QT_MOC_LITERAL(38, 479, 15),
QT_MOC_LITERAL(39, 495, 10),
QT_MOC_LITERAL(40, 506, 15),
QT_MOC_LITERAL(41, 522, 16),
QT_MOC_LITERAL(42, 539, 16),
QT_MOC_LITERAL(43, 556, 12),
QT_MOC_LITERAL(44, 569, 13),
QT_MOC_LITERAL(45, 583, 8),
QT_MOC_LITERAL(46, 592, 15),
QT_MOC_LITERAL(47, 608, 16),
QT_MOC_LITERAL(48, 625, 7),
QT_MOC_LITERAL(49, 633, 7),
QT_MOC_LITERAL(50, 641, 10),
QT_MOC_LITERAL(51, 652, 9),
QT_MOC_LITERAL(52, 662, 10),
QT_MOC_LITERAL(53, 673, 5),
QT_MOC_LITERAL(54, 679, 12),
QT_MOC_LITERAL(55, 692, 7),
QT_MOC_LITERAL(56, 700, 6),
QT_MOC_LITERAL(57, 707, 15),
QT_MOC_LITERAL(58, 723, 21),
QT_MOC_LITERAL(59, 745, 17),
QT_MOC_LITERAL(60, 763, 22),
QT_MOC_LITERAL(61, 786, 18),
QT_MOC_LITERAL(62, 805, 15),
QT_MOC_LITERAL(63, 821, 15),
QT_MOC_LITERAL(64, 837, 18),
QT_MOC_LITERAL(65, 856, 11),
QT_MOC_LITERAL(66, 868, 13),
QT_MOC_LITERAL(67, 882, 11),
QT_MOC_LITERAL(68, 894, 4),
QT_MOC_LITERAL(69, 899, 8),
QT_MOC_LITERAL(70, 908, 6),
QT_MOC_LITERAL(71, 915, 7),
QT_MOC_LITERAL(72, 923, 5),
QT_MOC_LITERAL(73, 929, 8),
QT_MOC_LITERAL(74, 938, 9),
QT_MOC_LITERAL(75, 948, 8),
QT_MOC_LITERAL(76, 957, 9),
QT_MOC_LITERAL(77, 967, 8),
QT_MOC_LITERAL(78, 976, 13),
QT_MOC_LITERAL(79, 990, 14),
QT_MOC_LITERAL(80, 1005, 6),
QT_MOC_LITERAL(81, 1012, 6),
QT_MOC_LITERAL(82, 1019, 12),
QT_MOC_LITERAL(83, 1032, 11)
    },
    "QCPAxis\0rangeChanged\0\0QCPRange\0newRange\0"
    "oldRange\0scaleTypeChanged\0QCPAxis::ScaleType\0"
    "scaleType\0selectionChanged\0"
    "QCPAxis::SelectableParts\0parts\0"
    "selectableChanged\0setScaleType\0type\0"
    "setRange\0range\0setSelectableParts\0"
    "selectableParts\0setSelectedParts\0"
    "selectedParts\0axisType\0AxisType\0"
    "axisRect\0QCPAxisRect*\0ScaleType\0"
    "rangeReversed\0ticker\0QSharedPointer<QCPAxisTicker>\0"
    "ticks\0tickLabels\0tickLabelPadding\0"
    "tickLabelFont\0tickLabelColor\0"
    "tickLabelRotation\0tickLabelSide\0"
    "LabelSide\0numberFormat\0numberPrecision\0"
    "tickVector\0QVector<double>\0tickVectorLabels\0"
    "QVector<QString>\0tickLengthIn\0"
    "tickLengthOut\0subTicks\0subTickLengthIn\0"
    "subTickLengthOut\0basePen\0tickPen\0"
    "subTickPen\0labelFont\0labelColor\0label\0"
    "labelPadding\0padding\0offset\0SelectableParts\0"
    "selectedTickLabelFont\0selectedLabelFont\0"
    "selectedTickLabelColor\0selectedLabelColor\0"
    "selectedBasePen\0selectedTickPen\0"
    "selectedSubTickPen\0lowerEnding\0"
    "QCPLineEnding\0upperEnding\0grid\0QCPGrid*\0"
    "atLeft\0atRight\0atTop\0atBottom\0AxisTypes\0"
    "lsInside\0lsOutside\0stLinear\0stLogarithmic\0"
    "SelectablePart\0spNone\0spAxis\0spTickLabels\0"
    "spAxisLabel"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxis[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
      43,   88, // properties
       6,  260, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       1,    2,   62,    2, 0x06 /* Public */,
       6,    1,   67,    2, 0x06 /* Public */,
       9,    1,   70,    2, 0x06 /* Public */,
      12,    1,   73,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    1,   76,    2, 0x0a /* Public */,
      15,    1,   79,    2, 0x0a /* Public */,
      17,    1,   82,    2, 0x0a /* Public */,
      19,    1,   85,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3, 0x80000000 | 3,    4,    5,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 10,   11,
    QMetaType::Void, 0x80000000 | 10,   11,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7,   14,
    QMetaType::Void, 0x80000000 | 3,   16,
    QMetaType::Void, 0x80000000 | 10,   18,
    QMetaType::Void, 0x80000000 | 10,   20,

 // properties: name, type, flags
      21, 0x80000000 | 22, 0x00095009,
      23, 0x80000000 | 24, 0x00095009,
       8, 0x80000000 | 25, 0x0049510b,
      16, 0x80000000 | 3, 0x0049510b,
      26, QMetaType::Bool, 0x00095103,
      27, 0x80000000 | 28, 0x0009510b,
      29, QMetaType::Bool, 0x00095103,
      30, QMetaType::Bool, 0x00095103,
      31, QMetaType::Int, 0x00095103,
      32, QMetaType::QFont, 0x00095103,
      33, QMetaType::QColor, 0x00095103,
      34, QMetaType::Double, 0x00095103,
      35, 0x80000000 | 36, 0x0009510b,
      37, QMetaType::QString, 0x00095103,
      38, QMetaType::Int, 0x00095103,
      39, 0x80000000 | 40, 0x00095009,
      41, 0x80000000 | 42, 0x00095009,
      43, QMetaType::Int, 0x00095103,
      44, QMetaType::Int, 0x00095103,
      45, QMetaType::Bool, 0x00095103,
      46, QMetaType::Int, 0x00095103,
      47, QMetaType::Int, 0x00095103,
      48, QMetaType::QPen, 0x00095103,
      49, QMetaType::QPen, 0x00095103,
      50, QMetaType::QPen, 0x00095103,
      51, QMetaType::QFont, 0x00095103,
      52, QMetaType::QColor, 0x00095103,
      53, QMetaType::QString, 0x00095103,
      54, QMetaType::Int, 0x00095103,
      55, QMetaType::Int, 0x00095103,
      56, QMetaType::Int, 0x00095103,
      20, 0x80000000 | 57, 0x0049510b,
      18, 0x80000000 | 57, 0x0049510b,
      58, QMetaType::QFont, 0x00095103,
      59, QMetaType::QFont, 0x00095103,
      60, QMetaType::QColor, 0x00095103,
      61, QMetaType::QColor, 0x00095103,
      62, QMetaType::QPen, 0x00095103,
      63, QMetaType::QPen, 0x00095103,
      64, QMetaType::QPen, 0x00095103,
      65, 0x80000000 | 66, 0x0009510b,
      67, 0x80000000 | 66, 0x0009510b,
      68, 0x80000000 | 69, 0x00095009,

 // properties: notify_signal_id
       0,
       0,
       2,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       3,
       4,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,

 // enums: name, flags, count, data
      22, 0x0,    4,  284,
      74, 0x1,    4,  292,
      36, 0x0,    2,  300,
      25, 0x0,    2,  304,
      79, 0x0,    4,  308,
      57, 0x1,    4,  316,

 // enum data: key, value
      70, uint(QCPAxis::atLeft),
      71, uint(QCPAxis::atRight),
      72, uint(QCPAxis::atTop),
      73, uint(QCPAxis::atBottom),
      70, uint(QCPAxis::atLeft),
      71, uint(QCPAxis::atRight),
      72, uint(QCPAxis::atTop),
      73, uint(QCPAxis::atBottom),
      75, uint(QCPAxis::lsInside),
      76, uint(QCPAxis::lsOutside),
      77, uint(QCPAxis::stLinear),
      78, uint(QCPAxis::stLogarithmic),
      80, uint(QCPAxis::spNone),
      81, uint(QCPAxis::spAxis),
      82, uint(QCPAxis::spTickLabels),
      83, uint(QCPAxis::spAxisLabel),
      80, uint(QCPAxis::spNone),
      81, uint(QCPAxis::spAxis),
      82, uint(QCPAxis::spTickLabels),
      83, uint(QCPAxis::spAxisLabel),

       0        // eod
};

void QCPAxis::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAxis *_t = static_cast<QCPAxis *>(_o);
        switch (_id) {
        case 0: _t->rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: _t->rangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1])),(*reinterpret_cast< const QCPRange(*)>(_a[2]))); break;
        case 2: _t->scaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 3: _t->selectionChanged((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 4: _t->selectableChanged((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 5: _t->setScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 6: _t->setRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 7: _t->setSelectableParts((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 8: _t->setSelectedParts((*reinterpret_cast< const QCPAxis::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
            }
            break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAxis::*_t)(const QCPRange & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::rangeChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPRange & , const QCPRange & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::rangeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPAxis::*_t)(QCPAxis::ScaleType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::scaleTypeChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPAxis::SelectableParts & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::selectionChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (QCPAxis::*_t)(const QCPAxis::SelectableParts & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAxis::selectableChanged)) {
                *result = 4;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxisRect* >(); break;
        case 42:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGrid* >(); break;
        case 5:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QSharedPointer<QCPAxisTicker> >(); break;
        case 16:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<QString> >(); break;
        case 15:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QVector<double> >(); break;
        }
    }

}

const QMetaObject QCPAxis::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAxis.data,
      qt_meta_data_QCPAxis,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPAxis::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAxis::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAxis.stringdata))
        return static_cast<void*>(const_cast< QCPAxis*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAxis::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< AxisType*>(_v) = axisType(); break;
        case 1: *reinterpret_cast< QCPAxisRect**>(_v) = axisRect(); break;
        case 2: *reinterpret_cast< ScaleType*>(_v) = scaleType(); break;
        case 3: *reinterpret_cast< QCPRange*>(_v) = range(); break;
        case 4: *reinterpret_cast< bool*>(_v) = rangeReversed(); break;
        case 5: *reinterpret_cast< QSharedPointer<QCPAxisTicker>*>(_v) = ticker(); break;
        case 6: *reinterpret_cast< bool*>(_v) = ticks(); break;
        case 7: *reinterpret_cast< bool*>(_v) = tickLabels(); break;
        case 8: *reinterpret_cast< int*>(_v) = tickLabelPadding(); break;
        case 9: *reinterpret_cast< QFont*>(_v) = tickLabelFont(); break;
        case 10: *reinterpret_cast< QColor*>(_v) = tickLabelColor(); break;
        case 11: *reinterpret_cast< double*>(_v) = tickLabelRotation(); break;
        case 12: *reinterpret_cast< LabelSide*>(_v) = tickLabelSide(); break;
        case 13: *reinterpret_cast< QString*>(_v) = numberFormat(); break;
        case 14: *reinterpret_cast< int*>(_v) = numberPrecision(); break;
        case 15: *reinterpret_cast< QVector<double>*>(_v) = tickVector(); break;
        case 16: *reinterpret_cast< QVector<QString>*>(_v) = tickVectorLabels(); break;
        case 17: *reinterpret_cast< int*>(_v) = tickLengthIn(); break;
        case 18: *reinterpret_cast< int*>(_v) = tickLengthOut(); break;
        case 19: *reinterpret_cast< bool*>(_v) = subTicks(); break;
        case 20: *reinterpret_cast< int*>(_v) = subTickLengthIn(); break;
        case 21: *reinterpret_cast< int*>(_v) = subTickLengthOut(); break;
        case 22: *reinterpret_cast< QPen*>(_v) = basePen(); break;
        case 23: *reinterpret_cast< QPen*>(_v) = tickPen(); break;
        case 24: *reinterpret_cast< QPen*>(_v) = subTickPen(); break;
        case 25: *reinterpret_cast< QFont*>(_v) = labelFont(); break;
        case 26: *reinterpret_cast< QColor*>(_v) = labelColor(); break;
        case 27: *reinterpret_cast< QString*>(_v) = label(); break;
        case 28: *reinterpret_cast< int*>(_v) = labelPadding(); break;
        case 29: *reinterpret_cast< int*>(_v) = padding(); break;
        case 30: *reinterpret_cast< int*>(_v) = offset(); break;
        case 31: *reinterpret_cast<int*>(_v) = QFlag(selectedParts()); break;
        case 32: *reinterpret_cast<int*>(_v) = QFlag(selectableParts()); break;
        case 33: *reinterpret_cast< QFont*>(_v) = selectedTickLabelFont(); break;
        case 34: *reinterpret_cast< QFont*>(_v) = selectedLabelFont(); break;
        case 35: *reinterpret_cast< QColor*>(_v) = selectedTickLabelColor(); break;
        case 36: *reinterpret_cast< QColor*>(_v) = selectedLabelColor(); break;
        case 37: *reinterpret_cast< QPen*>(_v) = selectedBasePen(); break;
        case 38: *reinterpret_cast< QPen*>(_v) = selectedTickPen(); break;
        case 39: *reinterpret_cast< QPen*>(_v) = selectedSubTickPen(); break;
        case 40: *reinterpret_cast< QCPLineEnding*>(_v) = lowerEnding(); break;
        case 41: *reinterpret_cast< QCPLineEnding*>(_v) = upperEnding(); break;
        case 42: *reinterpret_cast< QCPGrid**>(_v) = grid(); break;
        default: break;
        }
        _id -= 43;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 2: setScaleType(*reinterpret_cast< ScaleType*>(_v)); break;
        case 3: setRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 4: setRangeReversed(*reinterpret_cast< bool*>(_v)); break;
        case 5: setTicker(*reinterpret_cast< QSharedPointer<QCPAxisTicker>*>(_v)); break;
        case 6: setTicks(*reinterpret_cast< bool*>(_v)); break;
        case 7: setTickLabels(*reinterpret_cast< bool*>(_v)); break;
        case 8: setTickLabelPadding(*reinterpret_cast< int*>(_v)); break;
        case 9: setTickLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 10: setTickLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 11: setTickLabelRotation(*reinterpret_cast< double*>(_v)); break;
        case 12: setTickLabelSide(*reinterpret_cast< LabelSide*>(_v)); break;
        case 13: setNumberFormat(*reinterpret_cast< QString*>(_v)); break;
        case 14: setNumberPrecision(*reinterpret_cast< int*>(_v)); break;
        case 17: setTickLengthIn(*reinterpret_cast< int*>(_v)); break;
        case 18: setTickLengthOut(*reinterpret_cast< int*>(_v)); break;
        case 19: setSubTicks(*reinterpret_cast< bool*>(_v)); break;
        case 20: setSubTickLengthIn(*reinterpret_cast< int*>(_v)); break;
        case 21: setSubTickLengthOut(*reinterpret_cast< int*>(_v)); break;
        case 22: setBasePen(*reinterpret_cast< QPen*>(_v)); break;
        case 23: setTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 24: setSubTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 25: setLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 26: setLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 27: setLabel(*reinterpret_cast< QString*>(_v)); break;
        case 28: setLabelPadding(*reinterpret_cast< int*>(_v)); break;
        case 29: setPadding(*reinterpret_cast< int*>(_v)); break;
        case 30: setOffset(*reinterpret_cast< int*>(_v)); break;
        case 31: setSelectedParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 32: setSelectableParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 33: setSelectedTickLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 34: setSelectedLabelFont(*reinterpret_cast< QFont*>(_v)); break;
        case 35: setSelectedTickLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 36: setSelectedLabelColor(*reinterpret_cast< QColor*>(_v)); break;
        case 37: setSelectedBasePen(*reinterpret_cast< QPen*>(_v)); break;
        case 38: setSelectedTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 39: setSelectedSubTickPen(*reinterpret_cast< QPen*>(_v)); break;
        case 40: setLowerEnding(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 41: setUpperEnding(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        default: break;
        }
        _id -= 43;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 43;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 43;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 43)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 43;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAxis::rangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAxis::rangeChanged(const QCPRange & _t1, const QCPRange & _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPAxis::scaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPAxis::selectionChanged(const QCPAxis::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCPAxis::selectableChanged(const QCPAxis::SelectableParts & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
struct qt_meta_stringdata_QCPScatterStyle_t {
    QByteArrayData data[28];
    char stringdata[285];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPScatterStyle_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPScatterStyle_t qt_meta_stringdata_QCPScatterStyle = {
    {
QT_MOC_LITERAL(0, 0, 15),
QT_MOC_LITERAL(1, 16, 15),
QT_MOC_LITERAL(2, 32, 6),
QT_MOC_LITERAL(3, 39, 5),
QT_MOC_LITERAL(4, 45, 7),
QT_MOC_LITERAL(5, 53, 6),
QT_MOC_LITERAL(6, 60, 7),
QT_MOC_LITERAL(7, 68, 5),
QT_MOC_LITERAL(8, 74, 17),
QT_MOC_LITERAL(9, 92, 12),
QT_MOC_LITERAL(10, 105, 6),
QT_MOC_LITERAL(11, 112, 5),
QT_MOC_LITERAL(12, 118, 7),
QT_MOC_LITERAL(13, 126, 6),
QT_MOC_LITERAL(14, 133, 8),
QT_MOC_LITERAL(15, 142, 6),
QT_MOC_LITERAL(16, 149, 8),
QT_MOC_LITERAL(17, 158, 9),
QT_MOC_LITERAL(18, 168, 6),
QT_MOC_LITERAL(19, 175, 10),
QT_MOC_LITERAL(20, 186, 18),
QT_MOC_LITERAL(21, 205, 13),
QT_MOC_LITERAL(22, 219, 12),
QT_MOC_LITERAL(23, 232, 13),
QT_MOC_LITERAL(24, 246, 12),
QT_MOC_LITERAL(25, 259, 7),
QT_MOC_LITERAL(26, 267, 8),
QT_MOC_LITERAL(27, 276, 8)
    },
    "QCPScatterStyle\0ScatterProperty\0spNone\0"
    "spPen\0spBrush\0spSize\0spShape\0spAll\0"
    "ScatterProperties\0ScatterShape\0ssNone\0"
    "ssDot\0ssCross\0ssPlus\0ssCircle\0ssDisc\0"
    "ssSquare\0ssDiamond\0ssStar\0ssTriangle\0"
    "ssTriangleInverted\0ssCrossSquare\0"
    "ssPlusSquare\0ssCrossCircle\0ssPlusCircle\0"
    "ssPeace\0ssPixmap\0ssCustom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPScatterStyle[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       3,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    6,   26,
       8, 0x1,    6,   38,
       9, 0x0,   18,   50,

 // enum data: key, value
       2, uint(QCPScatterStyle::spNone),
       3, uint(QCPScatterStyle::spPen),
       4, uint(QCPScatterStyle::spBrush),
       5, uint(QCPScatterStyle::spSize),
       6, uint(QCPScatterStyle::spShape),
       7, uint(QCPScatterStyle::spAll),
       2, uint(QCPScatterStyle::spNone),
       3, uint(QCPScatterStyle::spPen),
       4, uint(QCPScatterStyle::spBrush),
       5, uint(QCPScatterStyle::spSize),
       6, uint(QCPScatterStyle::spShape),
       7, uint(QCPScatterStyle::spAll),
      10, uint(QCPScatterStyle::ssNone),
      11, uint(QCPScatterStyle::ssDot),
      12, uint(QCPScatterStyle::ssCross),
      13, uint(QCPScatterStyle::ssPlus),
      14, uint(QCPScatterStyle::ssCircle),
      15, uint(QCPScatterStyle::ssDisc),
      16, uint(QCPScatterStyle::ssSquare),
      17, uint(QCPScatterStyle::ssDiamond),
      18, uint(QCPScatterStyle::ssStar),
      19, uint(QCPScatterStyle::ssTriangle),
      20, uint(QCPScatterStyle::ssTriangleInverted),
      21, uint(QCPScatterStyle::ssCrossSquare),
      22, uint(QCPScatterStyle::ssPlusSquare),
      23, uint(QCPScatterStyle::ssCrossCircle),
      24, uint(QCPScatterStyle::ssPlusCircle),
      25, uint(QCPScatterStyle::ssPeace),
      26, uint(QCPScatterStyle::ssPixmap),
      27, uint(QCPScatterStyle::ssCustom),

       0        // eod
};

const QMetaObject QCPScatterStyle::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPScatterStyle.data,
      qt_meta_data_QCPScatterStyle,  0, 0, 0}
};

struct qt_meta_stringdata_QCPSelectionDecorator_t {
    QByteArrayData data[1];
    char stringdata[22];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPSelectionDecorator_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPSelectionDecorator_t qt_meta_stringdata_QCPSelectionDecorator = {
    {
QT_MOC_LITERAL(0, 0, 21)
    },
    "QCPSelectionDecorator"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPSelectionDecorator[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

const QMetaObject QCPSelectionDecorator::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPSelectionDecorator.data,
      qt_meta_data_QCPSelectionDecorator,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAbstractPlottable_t {
    QByteArrayData data[21];
    char stringdata[270];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAbstractPlottable_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAbstractPlottable_t qt_meta_stringdata_QCPAbstractPlottable = {
    {
QT_MOC_LITERAL(0, 0, 20),
QT_MOC_LITERAL(1, 21, 16),
QT_MOC_LITERAL(2, 38, 0),
QT_MOC_LITERAL(3, 39, 8),
QT_MOC_LITERAL(4, 48, 16),
QT_MOC_LITERAL(5, 65, 9),
QT_MOC_LITERAL(6, 75, 17),
QT_MOC_LITERAL(7, 93, 18),
QT_MOC_LITERAL(8, 112, 10),
QT_MOC_LITERAL(9, 123, 13),
QT_MOC_LITERAL(10, 137, 12),
QT_MOC_LITERAL(11, 150, 4),
QT_MOC_LITERAL(12, 155, 15),
QT_MOC_LITERAL(13, 171, 19),
QT_MOC_LITERAL(14, 191, 3),
QT_MOC_LITERAL(15, 195, 5),
QT_MOC_LITERAL(16, 201, 7),
QT_MOC_LITERAL(17, 209, 8),
QT_MOC_LITERAL(18, 218, 9),
QT_MOC_LITERAL(19, 228, 18),
QT_MOC_LITERAL(20, 247, 22)
    },
    "QCPAbstractPlottable\0selectionChanged\0"
    "\0selected\0QCPDataSelection\0selection\0"
    "selectableChanged\0QCP::SelectionType\0"
    "selectable\0setSelectable\0setSelection\0"
    "name\0antialiasedFill\0antialiasedScatters\0"
    "pen\0brush\0keyAxis\0QCPAxis*\0valueAxis\0"
    "selectionDecorator\0QCPSelectionDecorator*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAbstractPlottable[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       5,   14, // methods
      10,   54, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   39,    2, 0x06 /* Public */,
       1,    1,   42,    2, 0x06 /* Public */,
       6,    1,   45,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       9,    1,   48,    2, 0x0a /* Public */,
      10,    1,   51,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, 0x80000000 | 4,    5,
    QMetaType::Void, 0x80000000 | 7,    8,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 4,    5,

 // properties: name, type, flags
      11, QMetaType::QString, 0x00095103,
      12, QMetaType::Bool, 0x00095103,
      13, QMetaType::Bool, 0x00095103,
      14, QMetaType::QPen, 0x00095103,
      15, QMetaType::QBrush, 0x00095103,
      16, 0x80000000 | 17, 0x0009510b,
      18, 0x80000000 | 17, 0x0009510b,
       8, 0x80000000 | 7, 0x0049510b,
       5, 0x80000000 | 4, 0x0049510b,
      19, 0x80000000 | 20, 0x0009510b,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       2,
       0,
       0,

       0        // eod
};

void QCPAbstractPlottable::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAbstractPlottable *_t = static_cast<QCPAbstractPlottable *>(_o);
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectionChanged((*reinterpret_cast< const QCPDataSelection(*)>(_a[1]))); break;
        case 2: _t->selectableChanged((*reinterpret_cast< QCP::SelectionType(*)>(_a[1]))); break;
        case 3: _t->setSelectable((*reinterpret_cast< QCP::SelectionType(*)>(_a[1]))); break;
        case 4: _t->setSelection((*reinterpret_cast< QCPDataSelection(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPDataSelection >(); break;
            }
            break;
        case 2:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCP::SelectionType >(); break;
            }
            break;
        case 3:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCP::SelectionType >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPDataSelection >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAbstractPlottable::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractPlottable::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAbstractPlottable::*_t)(const QCPDataSelection & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractPlottable::selectionChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPAbstractPlottable::*_t)(QCP::SelectionType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractPlottable::selectableChanged)) {
                *result = 2;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 7:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCP::SelectionType >(); break;
        case 6:
        case 5:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
        case 8:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPDataSelection >(); break;
        case 9:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPSelectionDecorator* >(); break;
        }
    }

}

static const QMetaObject * const qt_meta_extradata_QCPAbstractPlottable[] = {
        &QCP::staticMetaObject,
    0
};

const QMetaObject QCPAbstractPlottable::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAbstractPlottable.data,
      qt_meta_data_QCPAbstractPlottable,  qt_static_metacall, qt_meta_extradata_QCPAbstractPlottable, 0}
};


const QMetaObject *QCPAbstractPlottable::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAbstractPlottable::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractPlottable.stringdata))
        return static_cast<void*>(const_cast< QCPAbstractPlottable*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAbstractPlottable::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = name(); break;
        case 1: *reinterpret_cast< bool*>(_v) = antialiasedFill(); break;
        case 2: *reinterpret_cast< bool*>(_v) = antialiasedScatters(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 5: *reinterpret_cast< QCPAxis**>(_v) = keyAxis(); break;
        case 6: *reinterpret_cast< QCPAxis**>(_v) = valueAxis(); break;
        case 7: *reinterpret_cast< QCP::SelectionType*>(_v) = selectable(); break;
        case 8: *reinterpret_cast< QCPDataSelection*>(_v) = selection(); break;
        case 9: *reinterpret_cast< QCPSelectionDecorator**>(_v) = selectionDecorator(); break;
        default: break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setName(*reinterpret_cast< QString*>(_v)); break;
        case 1: setAntialiasedFill(*reinterpret_cast< bool*>(_v)); break;
        case 2: setAntialiasedScatters(*reinterpret_cast< bool*>(_v)); break;
        case 3: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: setKeyAxis(*reinterpret_cast< QCPAxis**>(_v)); break;
        case 6: setValueAxis(*reinterpret_cast< QCPAxis**>(_v)); break;
        case 7: setSelectable(*reinterpret_cast< QCP::SelectionType*>(_v)); break;
        case 8: setSelection(*reinterpret_cast< QCPDataSelection*>(_v)); break;
        case 9: setSelectionDecorator(*reinterpret_cast< QCPSelectionDecorator**>(_v)); break;
        default: break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 10;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractPlottable::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractPlottable::selectionChanged(const QCPDataSelection & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPAbstractPlottable::selectableChanged(QCP::SelectionType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
struct qt_meta_stringdata_QCPItemAnchor_t {
    QByteArrayData data[1];
    char stringdata[14];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemAnchor_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemAnchor_t qt_meta_stringdata_QCPItemAnchor = {
    {
QT_MOC_LITERAL(0, 0, 13)
    },
    "QCPItemAnchor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemAnchor[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

const QMetaObject QCPItemAnchor::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPItemAnchor.data,
      qt_meta_data_QCPItemAnchor,  0, 0, 0}
};

struct qt_meta_stringdata_QCPItemPosition_t {
    QByteArrayData data[6];
    char stringdata[85];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemPosition_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemPosition_t qt_meta_stringdata_QCPItemPosition = {
    {
QT_MOC_LITERAL(0, 0, 15),
QT_MOC_LITERAL(1, 16, 12),
QT_MOC_LITERAL(2, 29, 10),
QT_MOC_LITERAL(3, 40, 15),
QT_MOC_LITERAL(4, 56, 15),
QT_MOC_LITERAL(5, 72, 12)
    },
    "QCPItemPosition\0PositionType\0ptAbsolute\0"
    "ptViewportRatio\0ptAxisRectRatio\0"
    "ptPlotCoords"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemPosition[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    4,   18,

 // enum data: key, value
       2, uint(QCPItemPosition::ptAbsolute),
       3, uint(QCPItemPosition::ptViewportRatio),
       4, uint(QCPItemPosition::ptAxisRectRatio),
       5, uint(QCPItemPosition::ptPlotCoords),

       0        // eod
};

const QMetaObject QCPItemPosition::staticMetaObject = {
    { &QCPItemAnchor::staticMetaObject, qt_meta_stringdata_QCPItemPosition.data,
      qt_meta_data_QCPItemPosition,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAbstractItem_t {
    QByteArrayData data[11];
    char stringdata[139];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAbstractItem_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAbstractItem_t qt_meta_stringdata_QCPAbstractItem = {
    {
QT_MOC_LITERAL(0, 0, 15),
QT_MOC_LITERAL(1, 16, 16),
QT_MOC_LITERAL(2, 33, 0),
QT_MOC_LITERAL(3, 34, 8),
QT_MOC_LITERAL(4, 43, 17),
QT_MOC_LITERAL(5, 61, 10),
QT_MOC_LITERAL(6, 72, 13),
QT_MOC_LITERAL(7, 86, 11),
QT_MOC_LITERAL(8, 98, 14),
QT_MOC_LITERAL(9, 113, 12),
QT_MOC_LITERAL(10, 126, 12)
    },
    "QCPAbstractItem\0selectionChanged\0\0"
    "selected\0selectableChanged\0selectable\0"
    "setSelectable\0setSelected\0clipToAxisRect\0"
    "clipAxisRect\0QCPAxisRect*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAbstractItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       4,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       7,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
       8, QMetaType::Bool, 0x00095103,
       9, 0x80000000 | 10, 0x0009510b,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       1,
       0,

       0        // eod
};

void QCPAbstractItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAbstractItem *_t = static_cast<QCPAbstractItem *>(_o);
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAbstractItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractItem::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAbstractItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractItem::selectableChanged)) {
                *result = 1;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxisRect* >(); break;
        }
    }

}

const QMetaObject QCPAbstractItem::staticMetaObject = {
    { &QCPLayerable::staticMetaObject, qt_meta_stringdata_QCPAbstractItem.data,
      qt_meta_data_QCPAbstractItem,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPAbstractItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAbstractItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractItem.stringdata))
        return static_cast<void*>(const_cast< QCPAbstractItem*>(this));
    return QCPLayerable::qt_metacast(_clname);
}

int QCPAbstractItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayerable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< bool*>(_v) = clipToAxisRect(); break;
        case 1: *reinterpret_cast< QCPAxisRect**>(_v) = clipAxisRect(); break;
        case 2: *reinterpret_cast< bool*>(_v) = selectable(); break;
        case 3: *reinterpret_cast< bool*>(_v) = selected(); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setClipToAxisRect(*reinterpret_cast< bool*>(_v)); break;
        case 1: setClipAxisRect(*reinterpret_cast< QCPAxisRect**>(_v)); break;
        case 2: setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 3: setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractItem::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractItem::selectableChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCustomPlot_t {
    QByteArrayData data[65];
    char stringdata[919];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCustomPlot_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCustomPlot_t qt_meta_stringdata_QCustomPlot = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 16),
QT_MOC_LITERAL(2, 29, 0),
QT_MOC_LITERAL(3, 30, 12),
QT_MOC_LITERAL(4, 43, 5),
QT_MOC_LITERAL(5, 49, 10),
QT_MOC_LITERAL(6, 60, 9),
QT_MOC_LITERAL(7, 70, 12),
QT_MOC_LITERAL(8, 83, 10),
QT_MOC_LITERAL(9, 94, 12),
QT_MOC_LITERAL(10, 107, 14),
QT_MOC_LITERAL(11, 122, 21),
QT_MOC_LITERAL(12, 144, 9),
QT_MOC_LITERAL(13, 154, 9),
QT_MOC_LITERAL(14, 164, 20),
QT_MOC_LITERAL(15, 185, 9),
QT_MOC_LITERAL(16, 195, 16),
QT_MOC_LITERAL(17, 212, 4),
QT_MOC_LITERAL(18, 217, 15),
QT_MOC_LITERAL(19, 233, 9),
QT_MOC_LITERAL(20, 243, 8),
QT_MOC_LITERAL(21, 252, 4),
QT_MOC_LITERAL(22, 257, 23),
QT_MOC_LITERAL(23, 281, 4),
QT_MOC_LITERAL(24, 286, 15),
QT_MOC_LITERAL(25, 302, 11),
QT_MOC_LITERAL(26, 314, 10),
QT_MOC_LITERAL(27, 325, 6),
QT_MOC_LITERAL(28, 332, 22),
QT_MOC_LITERAL(29, 355, 17),
QT_MOC_LITERAL(30, 373, 22),
QT_MOC_LITERAL(31, 396, 12),
QT_MOC_LITERAL(32, 409, 11),
QT_MOC_LITERAL(33, 421, 11),
QT_MOC_LITERAL(34, 433, 21),
QT_MOC_LITERAL(35, 455, 11),
QT_MOC_LITERAL(36, 467, 6),
QT_MOC_LITERAL(37, 474, 28),
QT_MOC_LITERAL(38, 503, 15),
QT_MOC_LITERAL(39, 519, 4),
QT_MOC_LITERAL(40, 524, 20),
QT_MOC_LITERAL(41, 545, 4),
QT_MOC_LITERAL(42, 550, 15),
QT_MOC_LITERAL(43, 566, 21),
QT_MOC_LITERAL(44, 588, 8),
QT_MOC_LITERAL(45, 597, 10),
QT_MOC_LITERAL(46, 608, 16),
QT_MOC_LITERAL(47, 625, 20),
QT_MOC_LITERAL(48, 646, 19),
QT_MOC_LITERAL(49, 666, 10),
QT_MOC_LITERAL(50, 677, 14),
QT_MOC_LITERAL(51, 692, 24),
QT_MOC_LITERAL(52, 717, 18),
QT_MOC_LITERAL(53, 736, 20),
QT_MOC_LITERAL(54, 757, 19),
QT_MOC_LITERAL(55, 777, 20),
QT_MOC_LITERAL(56, 798, 6),
QT_MOC_LITERAL(57, 805, 15),
QT_MOC_LITERAL(58, 821, 8),
QT_MOC_LITERAL(59, 830, 8),
QT_MOC_LITERAL(60, 839, 15),
QT_MOC_LITERAL(61, 855, 18),
QT_MOC_LITERAL(62, 874, 15),
QT_MOC_LITERAL(63, 890, 13),
QT_MOC_LITERAL(64, 904, 14)
    },
    "QCustomPlot\0mouseDoubleClick\0\0"
    "QMouseEvent*\0event\0mousePress\0mouseMove\0"
    "mouseRelease\0mouseWheel\0QWheelEvent*\0"
    "plottableClick\0QCPAbstractPlottable*\0"
    "plottable\0dataIndex\0plottableDoubleClick\0"
    "itemClick\0QCPAbstractItem*\0item\0"
    "itemDoubleClick\0axisClick\0QCPAxis*\0"
    "axis\0QCPAxis::SelectablePart\0part\0"
    "axisDoubleClick\0legendClick\0QCPLegend*\0"
    "legend\0QCPAbstractLegendItem*\0"
    "legendDoubleClick\0selectionChangedByUser\0"
    "beforeReplot\0afterReplot\0rescaleAxes\0"
    "onlyVisiblePlottables\0deselectAll\0"
    "replot\0QCustomPlot::RefreshPriority\0"
    "refreshPriority\0step\0processRectSelection\0"
    "rect\0processRectZoom\0processPointSelection\0"
    "viewport\0background\0backgroundScaled\0"
    "backgroundScaledMode\0Qt::AspectRatioMode\0"
    "plotLayout\0QCPLayoutGrid*\0"
    "autoAddPlottableToLegend\0selectionTolerance\0"
    "noAntialiasingOnDrag\0multiSelectModifier\0"
    "Qt::KeyboardModifier\0openGl\0LayerInsertMode\0"
    "limBelow\0limAbove\0RefreshPriority\0"
    "rpImmediateRefresh\0rpQueuedRefresh\0"
    "rpRefreshHint\0rpQueuedReplot"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCustomPlot[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
      10,  244, // properties
       2,  274, // enums/sets
       0,    0, // constructors
       0,       // flags
      16,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  144,    2, 0x06 /* Public */,
       5,    1,  147,    2, 0x06 /* Public */,
       6,    1,  150,    2, 0x06 /* Public */,
       7,    1,  153,    2, 0x06 /* Public */,
       8,    1,  156,    2, 0x06 /* Public */,
      10,    3,  159,    2, 0x06 /* Public */,
      14,    3,  166,    2, 0x06 /* Public */,
      15,    2,  173,    2, 0x06 /* Public */,
      18,    2,  178,    2, 0x06 /* Public */,
      19,    3,  183,    2, 0x06 /* Public */,
      24,    3,  190,    2, 0x06 /* Public */,
      25,    3,  197,    2, 0x06 /* Public */,
      29,    3,  204,    2, 0x06 /* Public */,
      30,    0,  211,    2, 0x06 /* Public */,
      31,    0,  212,    2, 0x06 /* Public */,
      32,    0,  213,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      33,    1,  214,    2, 0x0a /* Public */,
      33,    0,  217,    2, 0x2a /* Public | MethodCloned */,
      35,    0,  218,    2, 0x0a /* Public */,
      36,    1,  219,    2, 0x0a /* Public */,
      36,    0,  222,    2, 0x2a /* Public | MethodCloned */,
      36,    2,  223,    2, 0x0a /* Public */,
      36,    1,  228,    2, 0x2a /* Public | MethodCloned */,
      40,    2,  231,    2, 0x09 /* Protected */,
      42,    2,  236,    2, 0x09 /* Protected */,
      43,    1,  241,    2, 0x09 /* Protected */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 9,    4,
    QMetaType::Void, 0x80000000 | 11, QMetaType::Int, 0x80000000 | 3,   12,   13,    4,
    QMetaType::Void, 0x80000000 | 11, QMetaType::Int, 0x80000000 | 3,   12,   13,    4,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 3,   17,    4,
    QMetaType::Void, 0x80000000 | 16, 0x80000000 | 3,   17,    4,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 22, 0x80000000 | 3,   21,   23,    4,
    QMetaType::Void, 0x80000000 | 20, 0x80000000 | 22, 0x80000000 | 3,   21,   23,    4,
    QMetaType::Void, 0x80000000 | 26, 0x80000000 | 28, 0x80000000 | 3,   27,   17,    4,
    QMetaType::Void, 0x80000000 | 26, 0x80000000 | 28, 0x80000000 | 3,   27,   17,    4,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,   34,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 37,   38,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool, 0x80000000 | 37,   39,   38,
    QMetaType::Void, QMetaType::Bool,   39,
    QMetaType::Void, QMetaType::QRect, 0x80000000 | 3,   41,    4,
    QMetaType::Void, QMetaType::QRect, 0x80000000 | 3,   41,    4,
    QMetaType::Void, 0x80000000 | 3,    4,

 // properties: name, type, flags
      44, QMetaType::QRect, 0x00095103,
      45, QMetaType::QPixmap, 0x00095103,
      46, QMetaType::Bool, 0x00095103,
      47, 0x80000000 | 48, 0x0009510b,
      49, 0x80000000 | 50, 0x00095009,
      51, QMetaType::Bool, 0x00095103,
      52, QMetaType::Int, 0x00095103,
      53, QMetaType::Bool, 0x00095103,
      54, 0x80000000 | 55, 0x0009510b,
      56, QMetaType::Bool, 0x00095103,

 // enums: name, flags, count, data
      57, 0x0,    2,  282,
      60, 0x0,    4,  286,

 // enum data: key, value
      58, uint(QCustomPlot::limBelow),
      59, uint(QCustomPlot::limAbove),
      61, uint(QCustomPlot::rpImmediateRefresh),
      62, uint(QCustomPlot::rpQueuedRefresh),
      63, uint(QCustomPlot::rpRefreshHint),
      64, uint(QCustomPlot::rpQueuedReplot),

       0        // eod
};

void QCustomPlot::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCustomPlot *_t = static_cast<QCustomPlot *>(_o);
        switch (_id) {
        case 0: _t->mouseDoubleClick((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 1: _t->mousePress((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 2: _t->mouseMove((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 3: _t->mouseRelease((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->mouseWheel((*reinterpret_cast< QWheelEvent*(*)>(_a[1]))); break;
        case 5: _t->plottableClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 6: _t->plottableDoubleClick((*reinterpret_cast< QCPAbstractPlottable*(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 7: _t->itemClick((*reinterpret_cast< QCPAbstractItem*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 8: _t->itemDoubleClick((*reinterpret_cast< QCPAbstractItem*(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 9: _t->axisClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 10: _t->axisDoubleClick((*reinterpret_cast< QCPAxis*(*)>(_a[1])),(*reinterpret_cast< QCPAxis::SelectablePart(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 11: _t->legendClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 12: _t->legendDoubleClick((*reinterpret_cast< QCPLegend*(*)>(_a[1])),(*reinterpret_cast< QCPAbstractLegendItem*(*)>(_a[2])),(*reinterpret_cast< QMouseEvent*(*)>(_a[3]))); break;
        case 13: _t->selectionChangedByUser(); break;
        case 14: _t->beforeReplot(); break;
        case 15: _t->afterReplot(); break;
        case 16: _t->rescaleAxes((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 17: _t->rescaleAxes(); break;
        case 18: _t->deselectAll(); break;
        case 19: _t->replot((*reinterpret_cast< QCustomPlot::RefreshPriority(*)>(_a[1]))); break;
        case 20: _t->replot(); break;
        case 21: _t->replot((*reinterpret_cast< bool(*)>(_a[1])),(*reinterpret_cast< QCustomPlot::RefreshPriority(*)>(_a[2]))); break;
        case 22: _t->replot((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->processRectSelection((*reinterpret_cast< QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 24: _t->processRectZoom((*reinterpret_cast< QRect(*)>(_a[1])),(*reinterpret_cast< QMouseEvent*(*)>(_a[2]))); break;
        case 25: _t->processPointSelection((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 5:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 6:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
            }
            break;
        case 7:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractItem* >(); break;
            }
            break;
        case 8:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractItem* >(); break;
            }
            break;
        case 9:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::SelectablePart >(); break;
            }
            break;
        case 10:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis* >(); break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::SelectablePart >(); break;
            }
            break;
        case 11:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 12:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractLegendItem* >(); break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
            }
            break;
        case 19:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCustomPlot::RefreshPriority >(); break;
            }
            break;
        case 21:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 1:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCustomPlot::RefreshPriority >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseDoubleClick)) {
                *result = 0;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mousePress)) {
                *result = 1;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseMove)) {
                *result = 2;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseRelease)) {
                *result = 3;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QWheelEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::mouseWheel)) {
                *result = 4;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractPlottable * , int , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::plottableClick)) {
                *result = 5;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractPlottable * , int , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::plottableDoubleClick)) {
                *result = 6;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::itemClick)) {
                *result = 7;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAbstractItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::itemDoubleClick)) {
                *result = 8;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAxis * , QCPAxis::SelectablePart , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::axisClick)) {
                *result = 9;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPAxis * , QCPAxis::SelectablePart , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::axisDoubleClick)) {
                *result = 10;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPLegend * , QCPAbstractLegendItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::legendClick)) {
                *result = 11;
            }
        }
        {
            typedef void (QCustomPlot::*_t)(QCPLegend * , QCPAbstractLegendItem * , QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::legendDoubleClick)) {
                *result = 12;
            }
        }
        {
            typedef void (QCustomPlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::selectionChangedByUser)) {
                *result = 13;
            }
        }
        {
            typedef void (QCustomPlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::beforeReplot)) {
                *result = 14;
            }
        }
        {
            typedef void (QCustomPlot::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCustomPlot::afterReplot)) {
                *result = 15;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 4:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLayoutGrid* >(); break;
        }
    }

}

const QMetaObject QCustomPlot::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_QCustomPlot.data,
      qt_meta_data_QCustomPlot,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCustomPlot::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCustomPlot::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCustomPlot.stringdata))
        return static_cast<void*>(const_cast< QCustomPlot*>(this));
    return QWidget::qt_metacast(_clname);
}

int QCustomPlot::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QRect*>(_v) = viewport(); break;
        case 1: *reinterpret_cast< QPixmap*>(_v) = background(); break;
        case 2: *reinterpret_cast< bool*>(_v) = backgroundScaled(); break;
        case 3: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = backgroundScaledMode(); break;
        case 4: *reinterpret_cast< QCPLayoutGrid**>(_v) = plotLayout(); break;
        case 5: *reinterpret_cast< bool*>(_v) = autoAddPlottableToLegend(); break;
        case 6: *reinterpret_cast< int*>(_v) = selectionTolerance(); break;
        case 7: *reinterpret_cast< bool*>(_v) = noAntialiasingOnDrag(); break;
        case 8: *reinterpret_cast< Qt::KeyboardModifier*>(_v) = multiSelectModifier(); break;
        case 9: *reinterpret_cast< bool*>(_v) = openGl(); break;
        default: break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setViewport(*reinterpret_cast< QRect*>(_v)); break;
        case 1: setBackground(*reinterpret_cast< QPixmap*>(_v)); break;
        case 2: setBackgroundScaled(*reinterpret_cast< bool*>(_v)); break;
        case 3: setBackgroundScaledMode(*reinterpret_cast< Qt::AspectRatioMode*>(_v)); break;
        case 5: setAutoAddPlottableToLegend(*reinterpret_cast< bool*>(_v)); break;
        case 6: setSelectionTolerance(*reinterpret_cast< int*>(_v)); break;
        case 7: setNoAntialiasingOnDrag(*reinterpret_cast< bool*>(_v)); break;
        case 8: setMultiSelectModifier(*reinterpret_cast< Qt::KeyboardModifier*>(_v)); break;
        case 9: setOpenGl(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 10;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 10;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 10;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCustomPlot::mouseDoubleClick(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCustomPlot::mousePress(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCustomPlot::mouseMove(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCustomPlot::mouseRelease(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void QCustomPlot::mouseWheel(QWheelEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void QCustomPlot::plottableClick(QCPAbstractPlottable * _t1, int _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void QCustomPlot::plottableDoubleClick(QCPAbstractPlottable * _t1, int _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void QCustomPlot::itemClick(QCPAbstractItem * _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void QCustomPlot::itemDoubleClick(QCPAbstractItem * _t1, QMouseEvent * _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void QCustomPlot::axisClick(QCPAxis * _t1, QCPAxis::SelectablePart _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void QCustomPlot::axisDoubleClick(QCPAxis * _t1, QCPAxis::SelectablePart _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void QCustomPlot::legendClick(QCPLegend * _t1, QCPAbstractLegendItem * _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void QCustomPlot::legendDoubleClick(QCPLegend * _t1, QCPAbstractLegendItem * _t2, QMouseEvent * _t3)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)), const_cast<void*>(reinterpret_cast<const void*>(&_t3)) };
    QMetaObject::activate(this, &staticMetaObject, 12, _a);
}

// SIGNAL 13
void QCustomPlot::selectionChangedByUser()
{
    QMetaObject::activate(this, &staticMetaObject, 13, 0);
}

// SIGNAL 14
void QCustomPlot::beforeReplot()
{
    QMetaObject::activate(this, &staticMetaObject, 14, 0);
}

// SIGNAL 15
void QCustomPlot::afterReplot()
{
    QMetaObject::activate(this, &staticMetaObject, 15, 0);
}
struct qt_meta_stringdata_QCPColorGradient_t {
    QByteArrayData data[17];
    char stringdata[164];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorGradient_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorGradient_t qt_meta_stringdata_QCPColorGradient = {
    {
QT_MOC_LITERAL(0, 0, 16),
QT_MOC_LITERAL(1, 17, 18),
QT_MOC_LITERAL(2, 36, 5),
QT_MOC_LITERAL(3, 42, 5),
QT_MOC_LITERAL(4, 48, 14),
QT_MOC_LITERAL(5, 63, 11),
QT_MOC_LITERAL(6, 75, 5),
QT_MOC_LITERAL(7, 81, 6),
QT_MOC_LITERAL(8, 88, 7),
QT_MOC_LITERAL(9, 96, 7),
QT_MOC_LITERAL(10, 104, 11),
QT_MOC_LITERAL(11, 116, 5),
QT_MOC_LITERAL(12, 122, 9),
QT_MOC_LITERAL(13, 132, 7),
QT_MOC_LITERAL(14, 140, 10),
QT_MOC_LITERAL(15, 151, 5),
QT_MOC_LITERAL(16, 157, 6)
    },
    "QCPColorGradient\0ColorInterpolation\0"
    "ciRGB\0ciHSV\0GradientPreset\0gpGrayscale\0"
    "gpHot\0gpCold\0gpNight\0gpCandy\0gpGeography\0"
    "gpIon\0gpThermal\0gpPolar\0gpSpectrum\0"
    "gpJet\0gpHues"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorGradient[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       2,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    2,   22,
       4, 0x0,   12,   26,

 // enum data: key, value
       2, uint(QCPColorGradient::ciRGB),
       3, uint(QCPColorGradient::ciHSV),
       5, uint(QCPColorGradient::gpGrayscale),
       6, uint(QCPColorGradient::gpHot),
       7, uint(QCPColorGradient::gpCold),
       8, uint(QCPColorGradient::gpNight),
       9, uint(QCPColorGradient::gpCandy),
      10, uint(QCPColorGradient::gpGeography),
      11, uint(QCPColorGradient::gpIon),
      12, uint(QCPColorGradient::gpThermal),
      13, uint(QCPColorGradient::gpPolar),
      14, uint(QCPColorGradient::gpSpectrum),
      15, uint(QCPColorGradient::gpJet),
      16, uint(QCPColorGradient::gpHues),

       0        // eod
};

const QMetaObject QCPColorGradient::staticMetaObject = {
    { 0, qt_meta_stringdata_QCPColorGradient.data,
      qt_meta_data_QCPColorGradient,  0, 0, 0}
};

struct qt_meta_stringdata_QCPSelectionDecoratorBracket_t {
    QByteArrayData data[7];
    char stringdata[101];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPSelectionDecoratorBracket_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPSelectionDecoratorBracket_t qt_meta_stringdata_QCPSelectionDecoratorBracket = {
    {
QT_MOC_LITERAL(0, 0, 28),
QT_MOC_LITERAL(1, 29, 12),
QT_MOC_LITERAL(2, 42, 15),
QT_MOC_LITERAL(3, 58, 13),
QT_MOC_LITERAL(4, 72, 9),
QT_MOC_LITERAL(5, 82, 6),
QT_MOC_LITERAL(6, 89, 11)
    },
    "QCPSelectionDecoratorBracket\0BracketStyle\0"
    "bsSquareBracket\0bsHalfEllipse\0bsEllipse\0"
    "bsPlus\0bsUserStyle"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPSelectionDecoratorBracket[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       1,   14, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // enums: name, flags, count, data
       1, 0x0,    5,   18,

 // enum data: key, value
       2, uint(QCPSelectionDecoratorBracket::bsSquareBracket),
       3, uint(QCPSelectionDecoratorBracket::bsHalfEllipse),
       4, uint(QCPSelectionDecoratorBracket::bsEllipse),
       5, uint(QCPSelectionDecoratorBracket::bsPlus),
       6, uint(QCPSelectionDecoratorBracket::bsUserStyle),

       0        // eod
};

const QMetaObject QCPSelectionDecoratorBracket::staticMetaObject = {
    { &QCPSelectionDecorator::staticMetaObject, qt_meta_stringdata_QCPSelectionDecoratorBracket.data,
      qt_meta_data_QCPSelectionDecoratorBracket,  0, 0, 0}
};

struct qt_meta_stringdata_QCPAxisRect_t {
    QByteArrayData data[8];
    char stringdata[118];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAxisRect_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAxisRect_t qt_meta_stringdata_QCPAxisRect = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 10),
QT_MOC_LITERAL(2, 23, 16),
QT_MOC_LITERAL(3, 40, 20),
QT_MOC_LITERAL(4, 61, 19),
QT_MOC_LITERAL(5, 81, 9),
QT_MOC_LITERAL(6, 91, 16),
QT_MOC_LITERAL(7, 108, 9)
    },
    "QCPAxisRect\0background\0backgroundScaled\0"
    "backgroundScaledMode\0Qt::AspectRatioMode\0"
    "rangeDrag\0Qt::Orientations\0rangeZoom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAxisRect[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPixmap, 0x00095103,
       2, QMetaType::Bool, 0x00095103,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 6, 0x0009510b,
       7, 0x80000000 | 6, 0x0009510b,

       0        // eod
};

void QCPAxisRect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPAxisRect::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPAxisRect.data,
      qt_meta_data_QCPAxisRect,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPAxisRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAxisRect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAxisRect.stringdata))
        return static_cast<void*>(const_cast< QCPAxisRect*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPAxisRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPixmap*>(_v) = background(); break;
        case 1: *reinterpret_cast< bool*>(_v) = backgroundScaled(); break;
        case 2: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = backgroundScaledMode(); break;
        case 3: *reinterpret_cast< Qt::Orientations*>(_v) = rangeDrag(); break;
        case 4: *reinterpret_cast< Qt::Orientations*>(_v) = rangeZoom(); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setBackground(*reinterpret_cast< QPixmap*>(_v)); break;
        case 1: setBackgroundScaled(*reinterpret_cast< bool*>(_v)); break;
        case 2: setBackgroundScaledMode(*reinterpret_cast< Qt::AspectRatioMode*>(_v)); break;
        case 3: setRangeDrag(*reinterpret_cast< Qt::Orientations*>(_v)); break;
        case 4: setRangeZoom(*reinterpret_cast< Qt::Orientations*>(_v)); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 5)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPAbstractLegendItem_t {
    QByteArrayData data[14];
    char stringdata[174];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPAbstractLegendItem_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPAbstractLegendItem_t qt_meta_stringdata_QCPAbstractLegendItem = {
    {
QT_MOC_LITERAL(0, 0, 21),
QT_MOC_LITERAL(1, 22, 16),
QT_MOC_LITERAL(2, 39, 0),
QT_MOC_LITERAL(3, 40, 8),
QT_MOC_LITERAL(4, 49, 17),
QT_MOC_LITERAL(5, 67, 10),
QT_MOC_LITERAL(6, 78, 13),
QT_MOC_LITERAL(7, 92, 11),
QT_MOC_LITERAL(8, 104, 12),
QT_MOC_LITERAL(9, 117, 10),
QT_MOC_LITERAL(10, 128, 4),
QT_MOC_LITERAL(11, 133, 9),
QT_MOC_LITERAL(12, 143, 12),
QT_MOC_LITERAL(13, 156, 17)
    },
    "QCPAbstractLegendItem\0selectionChanged\0"
    "\0selected\0selectableChanged\0selectable\0"
    "setSelectable\0setSelected\0parentLegend\0"
    "QCPLegend*\0font\0textColor\0selectedFont\0"
    "selectedTextColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPAbstractLegendItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
       7,   46, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       4,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       7,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
       8, 0x80000000 | 9, 0x00095009,
      10, QMetaType::QFont, 0x00095103,
      11, QMetaType::QColor, 0x00095103,
      12, QMetaType::QFont, 0x00095103,
      13, QMetaType::QColor, 0x00095103,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       1,

       0        // eod
};

void QCPAbstractLegendItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPAbstractLegendItem *_t = static_cast<QCPAbstractLegendItem *>(_o);
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 3: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPAbstractLegendItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractLegendItem::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPAbstractLegendItem::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPAbstractLegendItem::selectableChanged)) {
                *result = 1;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPLegend* >(); break;
        }
    }

}

const QMetaObject QCPAbstractLegendItem::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPAbstractLegendItem.data,
      qt_meta_data_QCPAbstractLegendItem,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPAbstractLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPAbstractLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPAbstractLegendItem.stringdata))
        return static_cast<void*>(const_cast< QCPAbstractLegendItem*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPAbstractLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPLegend**>(_v) = parentLegend(); break;
        case 1: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = textColor(); break;
        case 3: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = selectedTextColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = selectable(); break;
        case 6: *reinterpret_cast< bool*>(_v) = selected(); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 1: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 2: setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 4: setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 6: setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPAbstractLegendItem::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPAbstractLegendItem::selectableChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCPPlottableLegendItem_t {
    QByteArrayData data[1];
    char stringdata[23];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPPlottableLegendItem_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPPlottableLegendItem_t qt_meta_stringdata_QCPPlottableLegendItem = {
    {
QT_MOC_LITERAL(0, 0, 22)
    },
    "QCPPlottableLegendItem"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPPlottableLegendItem[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void QCPPlottableLegendItem::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPPlottableLegendItem::staticMetaObject = {
    { &QCPAbstractLegendItem::staticMetaObject, qt_meta_stringdata_QCPPlottableLegendItem.data,
      qt_meta_data_QCPPlottableLegendItem,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPPlottableLegendItem::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPPlottableLegendItem::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPPlottableLegendItem.stringdata))
        return static_cast<void*>(const_cast< QCPPlottableLegendItem*>(this));
    return QCPAbstractLegendItem::qt_metacast(_clname);
}

int QCPPlottableLegendItem::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractLegendItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    return _id;
}
struct qt_meta_stringdata_QCPLegend_t {
    QByteArrayData data[27];
    char stringdata[358];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPLegend_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPLegend_t qt_meta_stringdata_QCPLegend = {
    {
QT_MOC_LITERAL(0, 0, 9),
QT_MOC_LITERAL(1, 10, 16),
QT_MOC_LITERAL(2, 27, 0),
QT_MOC_LITERAL(3, 28, 26),
QT_MOC_LITERAL(4, 55, 5),
QT_MOC_LITERAL(5, 61, 17),
QT_MOC_LITERAL(6, 79, 18),
QT_MOC_LITERAL(7, 98, 15),
QT_MOC_LITERAL(8, 114, 15),
QT_MOC_LITERAL(9, 130, 16),
QT_MOC_LITERAL(10, 147, 13),
QT_MOC_LITERAL(11, 161, 9),
QT_MOC_LITERAL(12, 171, 5),
QT_MOC_LITERAL(13, 177, 4),
QT_MOC_LITERAL(14, 182, 9),
QT_MOC_LITERAL(15, 192, 8),
QT_MOC_LITERAL(16, 201, 15),
QT_MOC_LITERAL(17, 217, 13),
QT_MOC_LITERAL(18, 231, 17),
QT_MOC_LITERAL(19, 249, 21),
QT_MOC_LITERAL(20, 271, 13),
QT_MOC_LITERAL(21, 285, 12),
QT_MOC_LITERAL(22, 298, 17),
QT_MOC_LITERAL(23, 316, 14),
QT_MOC_LITERAL(24, 331, 6),
QT_MOC_LITERAL(25, 338, 11),
QT_MOC_LITERAL(26, 350, 7)
    },
    "QCPLegend\0selectionChanged\0\0"
    "QCPLegend::SelectableParts\0parts\0"
    "selectableChanged\0setSelectableParts\0"
    "SelectableParts\0selectableParts\0"
    "setSelectedParts\0selectedParts\0borderPen\0"
    "brush\0font\0textColor\0iconSize\0"
    "iconTextPadding\0iconBorderPen\0"
    "selectedBorderPen\0selectedIconBorderPen\0"
    "selectedBrush\0selectedFont\0selectedTextColor\0"
    "SelectablePart\0spNone\0spLegendBox\0"
    "spItems"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPLegend[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       4,   14, // methods
      14,   46, // properties
       2,  102, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   34,    2, 0x06 /* Public */,
       5,    1,   37,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       6,    1,   40,    2, 0x0a /* Public */,
       9,    1,   43,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    4,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 7,   10,

 // properties: name, type, flags
      11, QMetaType::QPen, 0x00095103,
      12, QMetaType::QBrush, 0x00095103,
      13, QMetaType::QFont, 0x00095103,
      14, QMetaType::QColor, 0x00095103,
      15, QMetaType::QSize, 0x00095103,
      16, QMetaType::Int, 0x00095103,
      17, QMetaType::QPen, 0x00095103,
       8, 0x80000000 | 7, 0x0049510b,
      10, 0x80000000 | 7, 0x0049510b,
      18, QMetaType::QPen, 0x00095103,
      19, QMetaType::QPen, 0x00095103,
      20, QMetaType::QBrush, 0x00095103,
      21, QMetaType::QFont, 0x00095103,
      22, QMetaType::QColor, 0x00095103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       0,
       1,
       0,
       0,
       0,
       0,
       0,

 // enums: name, flags, count, data
      23, 0x0,    3,  110,
       7, 0x1,    3,  116,

 // enum data: key, value
      24, uint(QCPLegend::spNone),
      25, uint(QCPLegend::spLegendBox),
      26, uint(QCPLegend::spItems),
      24, uint(QCPLegend::spNone),
      25, uint(QCPLegend::spLegendBox),
      26, uint(QCPLegend::spItems),

       0        // eod
};

void QCPLegend::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPLegend *_t = static_cast<QCPLegend *>(_o);
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< QCPLegend::SelectableParts(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< QCPLegend::SelectableParts(*)>(_a[1]))); break;
        case 2: _t->setSelectableParts((*reinterpret_cast< const SelectableParts(*)>(_a[1]))); break;
        case 3: _t->setSelectedParts((*reinterpret_cast< const SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPLegend::*_t)(QCPLegend::SelectableParts );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPLegend::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPLegend::*_t)(QCPLegend::SelectableParts );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPLegend::selectableChanged)) {
                *result = 1;
            }
        }
    }
}

const QMetaObject QCPLegend::staticMetaObject = {
    { &QCPLayoutGrid::staticMetaObject, qt_meta_stringdata_QCPLegend.data,
      qt_meta_data_QCPLegend,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPLegend::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPLegend::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPLegend.stringdata))
        return static_cast<void*>(const_cast< QCPLegend*>(this));
    return QCPLayoutGrid::qt_metacast(_clname);
}

int QCPLegend::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutGrid::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 4)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 4;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = borderPen(); break;
        case 1: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 2: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 3: *reinterpret_cast< QColor*>(_v) = textColor(); break;
        case 4: *reinterpret_cast< QSize*>(_v) = iconSize(); break;
        case 5: *reinterpret_cast< int*>(_v) = iconTextPadding(); break;
        case 6: *reinterpret_cast< QPen*>(_v) = iconBorderPen(); break;
        case 7: *reinterpret_cast<int*>(_v) = QFlag(selectableParts()); break;
        case 8: *reinterpret_cast<int*>(_v) = QFlag(selectedParts()); break;
        case 9: *reinterpret_cast< QPen*>(_v) = selectedBorderPen(); break;
        case 10: *reinterpret_cast< QPen*>(_v) = selectedIconBorderPen(); break;
        case 11: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        case 12: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 13: *reinterpret_cast< QColor*>(_v) = selectedTextColor(); break;
        default: break;
        }
        _id -= 14;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 2: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 3: setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 4: setIconSize(*reinterpret_cast< QSize*>(_v)); break;
        case 5: setIconTextPadding(*reinterpret_cast< int*>(_v)); break;
        case 6: setIconBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 7: setSelectableParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 8: setSelectedParts(QFlag(*reinterpret_cast<int*>(_v))); break;
        case 9: setSelectedBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 10: setSelectedIconBorderPen(*reinterpret_cast< QPen*>(_v)); break;
        case 11: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 12: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 13: setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        default: break;
        }
        _id -= 14;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 14;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 14;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 14)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 14;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPLegend::selectionChanged(QCPLegend::SelectableParts _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPLegend::selectableChanged(QCPLegend::SelectableParts _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
struct qt_meta_stringdata_QCPTextElement_t {
    QByteArrayData data[17];
    char stringdata[189];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPTextElement_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPTextElement_t qt_meta_stringdata_QCPTextElement = {
    {
QT_MOC_LITERAL(0, 0, 14),
QT_MOC_LITERAL(1, 15, 16),
QT_MOC_LITERAL(2, 32, 0),
QT_MOC_LITERAL(3, 33, 8),
QT_MOC_LITERAL(4, 42, 17),
QT_MOC_LITERAL(5, 60, 10),
QT_MOC_LITERAL(6, 71, 7),
QT_MOC_LITERAL(7, 79, 12),
QT_MOC_LITERAL(8, 92, 5),
QT_MOC_LITERAL(9, 98, 13),
QT_MOC_LITERAL(10, 112, 13),
QT_MOC_LITERAL(11, 126, 11),
QT_MOC_LITERAL(12, 138, 4),
QT_MOC_LITERAL(13, 143, 4),
QT_MOC_LITERAL(14, 148, 9),
QT_MOC_LITERAL(15, 158, 12),
QT_MOC_LITERAL(16, 171, 17)
    },
    "QCPTextElement\0selectionChanged\0\0"
    "selected\0selectableChanged\0selectable\0"
    "clicked\0QMouseEvent*\0event\0doubleClicked\0"
    "setSelectable\0setSelected\0text\0font\0"
    "textColor\0selectedFont\0selectedTextColor"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPTextElement[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       7,   62, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   44,    2, 0x06 /* Public */,
       4,    1,   47,    2, 0x06 /* Public */,
       6,    1,   50,    2, 0x06 /* Public */,
       9,    1,   53,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      10,    1,   56,    2, 0x0a /* Public */,
      11,    1,   59,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, 0x80000000 | 7,    8,
    QMetaType::Void, 0x80000000 | 7,    8,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    5,
    QMetaType::Void, QMetaType::Bool,    3,

 // properties: name, type, flags
      12, QMetaType::QString, 0x00095103,
      13, QMetaType::QFont, 0x00095103,
      14, QMetaType::QColor, 0x00095103,
      15, QMetaType::QFont, 0x00095103,
      16, QMetaType::QColor, 0x00095103,
       5, QMetaType::Bool, 0x00495103,
       3, QMetaType::Bool, 0x00495103,

 // properties: notify_signal_id
       0,
       0,
       0,
       0,
       0,
       1,
       0,

       0        // eod
};

void QCPTextElement::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPTextElement *_t = static_cast<QCPTextElement *>(_o);
        switch (_id) {
        case 0: _t->selectionChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->selectableChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->clicked((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 3: _t->doubleClicked((*reinterpret_cast< QMouseEvent*(*)>(_a[1]))); break;
        case 4: _t->setSelectable((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 5: _t->setSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPTextElement::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTextElement::selectionChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPTextElement::*_t)(bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTextElement::selectableChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPTextElement::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTextElement::clicked)) {
                *result = 2;
            }
        }
        {
            typedef void (QCPTextElement::*_t)(QMouseEvent * );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPTextElement::doubleClicked)) {
                *result = 3;
            }
        }
    }
}

const QMetaObject QCPTextElement::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPTextElement.data,
      qt_meta_data_QCPTextElement,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPTextElement::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPTextElement::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPTextElement.stringdata))
        return static_cast<void*>(const_cast< QCPTextElement*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPTextElement::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QString*>(_v) = text(); break;
        case 1: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 2: *reinterpret_cast< QColor*>(_v) = textColor(); break;
        case 3: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 4: *reinterpret_cast< QColor*>(_v) = selectedTextColor(); break;
        case 5: *reinterpret_cast< bool*>(_v) = selectable(); break;
        case 6: *reinterpret_cast< bool*>(_v) = selected(); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setText(*reinterpret_cast< QString*>(_v)); break;
        case 1: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 2: setTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 3: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 4: setSelectedTextColor(*reinterpret_cast< QColor*>(_v)); break;
        case 5: setSelectable(*reinterpret_cast< bool*>(_v)); break;
        case 6: setSelected(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPTextElement::selectionChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPTextElement::selectableChanged(bool _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPTextElement::clicked(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void QCPTextElement::doubleClicked(QMouseEvent * _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
struct qt_meta_stringdata_QCPColorScaleAxisRectPrivate_t {
    QByteArrayData data[7];
    char stringdata[128];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorScaleAxisRectPrivate_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorScaleAxisRectPrivate_t qt_meta_stringdata_QCPColorScaleAxisRectPrivate = {
    {
QT_MOC_LITERAL(0, 0, 28),
QT_MOC_LITERAL(1, 29, 20),
QT_MOC_LITERAL(2, 50, 0),
QT_MOC_LITERAL(3, 51, 24),
QT_MOC_LITERAL(4, 76, 13),
QT_MOC_LITERAL(5, 90, 21),
QT_MOC_LITERAL(6, 112, 15)
    },
    "QCPColorScaleAxisRectPrivate\0"
    "axisSelectionChanged\0\0QCPAxis::SelectableParts\0"
    "selectedParts\0axisSelectableChanged\0"
    "selectableParts"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorScaleAxisRectPrivate[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       2,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   24,    2, 0x09 /* Protected */,
       5,    1,   27,    2, 0x09 /* Protected */,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 3,    6,

       0        // eod
};

void QCPColorScaleAxisRectPrivate::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPColorScaleAxisRectPrivate *_t = static_cast<QCPColorScaleAxisRectPrivate *>(_o);
        switch (_id) {
        case 0: _t->axisSelectionChanged((*reinterpret_cast< QCPAxis::SelectableParts(*)>(_a[1]))); break;
        case 1: _t->axisSelectableChanged((*reinterpret_cast< QCPAxis::SelectableParts(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject QCPColorScaleAxisRectPrivate::staticMetaObject = {
    { &QCPAxisRect::staticMetaObject, qt_meta_stringdata_QCPColorScaleAxisRectPrivate.data,
      qt_meta_data_QCPColorScaleAxisRectPrivate,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPColorScaleAxisRectPrivate::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPColorScaleAxisRectPrivate::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorScaleAxisRectPrivate.stringdata))
        return static_cast<void*>(const_cast< QCPColorScaleAxisRectPrivate*>(this));
    return QCPAxisRect::qt_metacast(_clname);
}

int QCPColorScaleAxisRectPrivate::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAxisRect::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 2)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
    return _id;
}
struct qt_meta_stringdata_QCPColorScale_t {
    QByteArrayData data[23];
    char stringdata[278];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorScale_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorScale_t qt_meta_stringdata_QCPColorScale = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 16),
QT_MOC_LITERAL(2, 31, 0),
QT_MOC_LITERAL(3, 32, 8),
QT_MOC_LITERAL(4, 41, 8),
QT_MOC_LITERAL(5, 50, 20),
QT_MOC_LITERAL(6, 71, 18),
QT_MOC_LITERAL(7, 90, 9),
QT_MOC_LITERAL(8, 100, 15),
QT_MOC_LITERAL(9, 116, 16),
QT_MOC_LITERAL(10, 133, 11),
QT_MOC_LITERAL(11, 145, 12),
QT_MOC_LITERAL(12, 158, 9),
QT_MOC_LITERAL(13, 168, 16),
QT_MOC_LITERAL(14, 185, 11),
QT_MOC_LITERAL(15, 197, 8),
QT_MOC_LITERAL(16, 206, 4),
QT_MOC_LITERAL(17, 211, 17),
QT_MOC_LITERAL(18, 229, 13),
QT_MOC_LITERAL(19, 243, 5),
QT_MOC_LITERAL(20, 249, 8),
QT_MOC_LITERAL(21, 258, 9),
QT_MOC_LITERAL(22, 268, 9)
    },
    "QCPColorScale\0dataRangeChanged\0\0"
    "QCPRange\0newRange\0dataScaleTypeChanged\0"
    "QCPAxis::ScaleType\0scaleType\0"
    "gradientChanged\0QCPColorGradient\0"
    "newGradient\0setDataRange\0dataRange\0"
    "setDataScaleType\0setGradient\0gradient\0"
    "type\0QCPAxis::AxisType\0dataScaleType\0"
    "label\0barWidth\0rangeDrag\0rangeZoom"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorScale[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       8,   62, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   44,    2, 0x06 /* Public */,
       5,    1,   47,    2, 0x06 /* Public */,
       8,    1,   50,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,   53,    2, 0x0a /* Public */,
      13,    1,   56,    2, 0x0a /* Public */,
      14,    1,   59,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   10,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,   12,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   15,

 // properties: name, type, flags
      16, 0x80000000 | 17, 0x0009510b,
      12, 0x80000000 | 3, 0x0049510b,
      18, 0x80000000 | 6, 0x0049510b,
      15, 0x80000000 | 9, 0x0049510b,
      19, QMetaType::QString, 0x00095103,
      20, QMetaType::Int, 0x00095103,
      21, QMetaType::Bool, 0x00095103,
      22, QMetaType::Bool, 0x00095103,

 // properties: notify_signal_id
       0,
       0,
       1,
       2,
       0,
       0,
       0,
       0,

       0        // eod
};

void QCPColorScale::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPColorScale *_t = static_cast<QCPColorScale *>(_o);
        switch (_id) {
        case 0: _t->dataRangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: _t->dataScaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 2: _t->gradientChanged((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 3: _t->setDataRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 4: _t->setDataScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 5: _t->setGradient((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPColorScale::*_t)(const QCPRange & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorScale::dataRangeChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPColorScale::*_t)(QCPAxis::ScaleType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorScale::dataScaleTypeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPColorScale::*_t)(const QCPColorGradient & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorScale::gradientChanged)) {
                *result = 2;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 0:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::AxisType >(); break;
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
        }
    }

}

static const QMetaObject * const qt_meta_extradata_QCPColorScale[] = {
        &QCPAxis::staticMetaObject,
    0
};

const QMetaObject QCPColorScale::staticMetaObject = {
    { &QCPLayoutElement::staticMetaObject, qt_meta_stringdata_QCPColorScale.data,
      qt_meta_data_QCPColorScale,  qt_static_metacall, qt_meta_extradata_QCPColorScale, 0}
};


const QMetaObject *QCPColorScale::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPColorScale::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorScale.stringdata))
        return static_cast<void*>(const_cast< QCPColorScale*>(this));
    return QCPLayoutElement::qt_metacast(_clname);
}

int QCPColorScale::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPLayoutElement::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPAxis::AxisType*>(_v) = type(); break;
        case 1: *reinterpret_cast< QCPRange*>(_v) = dataRange(); break;
        case 2: *reinterpret_cast< QCPAxis::ScaleType*>(_v) = dataScaleType(); break;
        case 3: *reinterpret_cast< QCPColorGradient*>(_v) = gradient(); break;
        case 4: *reinterpret_cast< QString*>(_v) = label(); break;
        case 5: *reinterpret_cast< int*>(_v) = barWidth(); break;
        case 6: *reinterpret_cast< bool*>(_v) = rangeDrag(); break;
        case 7: *reinterpret_cast< bool*>(_v) = rangeZoom(); break;
        default: break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setType(*reinterpret_cast< QCPAxis::AxisType*>(_v)); break;
        case 1: setDataRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 2: setDataScaleType(*reinterpret_cast< QCPAxis::ScaleType*>(_v)); break;
        case 3: setGradient(*reinterpret_cast< QCPColorGradient*>(_v)); break;
        case 4: setLabel(*reinterpret_cast< QString*>(_v)); break;
        case 5: setBarWidth(*reinterpret_cast< int*>(_v)); break;
        case 6: setRangeDrag(*reinterpret_cast< bool*>(_v)); break;
        case 7: setRangeZoom(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 8)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPColorScale::dataRangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPColorScale::dataScaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPColorScale::gradientChanged(const QCPColorGradient & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
struct qt_meta_stringdata_QCPGraph_t {
    QByteArrayData data[15];
    char stringdata[174];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPGraph_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPGraph_t qt_meta_stringdata_QCPGraph = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 9),
QT_MOC_LITERAL(2, 19, 9),
QT_MOC_LITERAL(3, 29, 12),
QT_MOC_LITERAL(4, 42, 15),
QT_MOC_LITERAL(5, 58, 11),
QT_MOC_LITERAL(6, 70, 16),
QT_MOC_LITERAL(7, 87, 9),
QT_MOC_LITERAL(8, 97, 16),
QT_MOC_LITERAL(9, 114, 6),
QT_MOC_LITERAL(10, 121, 6),
QT_MOC_LITERAL(11, 128, 10),
QT_MOC_LITERAL(12, 139, 11),
QT_MOC_LITERAL(13, 151, 12),
QT_MOC_LITERAL(14, 164, 9)
    },
    "QCPGraph\0lineStyle\0LineStyle\0scatterStyle\0"
    "QCPScatterStyle\0scatterSkip\0"
    "channelFillGraph\0QCPGraph*\0adaptiveSampling\0"
    "lsNone\0lsLine\0lsStepLeft\0lsStepRight\0"
    "lsStepCenter\0lsImpulse"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPGraph[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       1,   29, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, 0x80000000 | 4, 0x0009510b,
       5, QMetaType::Int, 0x00095103,
       6, 0x80000000 | 7, 0x0009510b,
       8, QMetaType::Bool, 0x00095103,

 // enums: name, flags, count, data
       2, 0x0,    6,   33,

 // enum data: key, value
       9, uint(QCPGraph::lsNone),
      10, uint(QCPGraph::lsLine),
      11, uint(QCPGraph::lsStepLeft),
      12, uint(QCPGraph::lsStepRight),
      13, uint(QCPGraph::lsStepCenter),
      14, uint(QCPGraph::lsImpulse),

       0        // eod
};

void QCPGraph::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 3:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPGraph::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPGraphData>::staticMetaObject, qt_meta_stringdata_QCPGraph.data,
      qt_meta_data_QCPGraph,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPGraph::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPGraph::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPGraph.stringdata))
        return static_cast<void*>(const_cast< QCPGraph*>(this));
    return QCPAbstractPlottable1D<QCPGraphData>::qt_metacast(_clname);
}

int QCPGraph::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPGraphData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< LineStyle*>(_v) = lineStyle(); break;
        case 1: *reinterpret_cast< QCPScatterStyle*>(_v) = scatterStyle(); break;
        case 2: *reinterpret_cast< int*>(_v) = scatterSkip(); break;
        case 3: *reinterpret_cast< QCPGraph**>(_v) = channelFillGraph(); break;
        case 4: *reinterpret_cast< bool*>(_v) = adaptiveSampling(); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setLineStyle(*reinterpret_cast< LineStyle*>(_v)); break;
        case 1: setScatterStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        case 2: setScatterSkip(*reinterpret_cast< int*>(_v)); break;
        case 3: setChannelFillGraph(*reinterpret_cast< QCPGraph**>(_v)); break;
        case 4: setAdaptiveSampling(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPCurve_t {
    QByteArrayData data[8];
    char stringdata[84];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPCurve_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPCurve_t qt_meta_stringdata_QCPCurve = {
    {
QT_MOC_LITERAL(0, 0, 8),
QT_MOC_LITERAL(1, 9, 12),
QT_MOC_LITERAL(2, 22, 15),
QT_MOC_LITERAL(3, 38, 11),
QT_MOC_LITERAL(4, 50, 9),
QT_MOC_LITERAL(5, 60, 9),
QT_MOC_LITERAL(6, 70, 6),
QT_MOC_LITERAL(7, 77, 6)
    },
    "QCPCurve\0scatterStyle\0QCPScatterStyle\0"
    "scatterSkip\0lineStyle\0LineStyle\0lsNone\0"
    "lsLine"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPCurve[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       3,   14, // properties
       1,   23, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, QMetaType::Int, 0x00095103,
       4, 0x80000000 | 5, 0x0009510b,

 // enums: name, flags, count, data
       5, 0x0,    2,   27,

 // enum data: key, value
       6, uint(QCPCurve::lsNone),
       7, uint(QCPCurve::lsLine),

       0        // eod
};

void QCPCurve::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPCurve::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPCurveData>::staticMetaObject, qt_meta_stringdata_QCPCurve.data,
      qt_meta_data_QCPCurve,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPCurve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPCurve::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPCurve.stringdata))
        return static_cast<void*>(const_cast< QCPCurve*>(this));
    return QCPAbstractPlottable1D<QCPCurveData>::qt_metacast(_clname);
}

int QCPCurve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPCurveData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPScatterStyle*>(_v) = scatterStyle(); break;
        case 1: *reinterpret_cast< int*>(_v) = scatterSkip(); break;
        case 2: *reinterpret_cast< LineStyle*>(_v) = lineStyle(); break;
        default: break;
        }
        _id -= 3;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setScatterStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        case 1: setScatterSkip(*reinterpret_cast< int*>(_v)); break;
        case 2: setLineStyle(*reinterpret_cast< LineStyle*>(_v)); break;
        default: break;
        }
        _id -= 3;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 3;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 3;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 3)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 3;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPBarsGroup_t {
    QByteArrayData data[7];
    char stringdata[85];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPBarsGroup_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPBarsGroup_t qt_meta_stringdata_QCPBarsGroup = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 11),
QT_MOC_LITERAL(2, 25, 11),
QT_MOC_LITERAL(3, 37, 7),
QT_MOC_LITERAL(4, 45, 10),
QT_MOC_LITERAL(5, 56, 15),
QT_MOC_LITERAL(6, 72, 12)
    },
    "QCPBarsGroup\0spacingType\0SpacingType\0"
    "spacing\0stAbsolute\0stAxisRectRatio\0"
    "stPlotCoords"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPBarsGroup[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       1,   20, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, QMetaType::Double, 0x00095103,

 // enums: name, flags, count, data
       2, 0x0,    3,   24,

 // enum data: key, value
       4, uint(QCPBarsGroup::stAbsolute),
       5, uint(QCPBarsGroup::stAxisRectRatio),
       6, uint(QCPBarsGroup::stPlotCoords),

       0        // eod
};

void QCPBarsGroup::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPBarsGroup::staticMetaObject = {
    { &QObject::staticMetaObject, qt_meta_stringdata_QCPBarsGroup.data,
      qt_meta_data_QCPBarsGroup,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPBarsGroup::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPBarsGroup::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPBarsGroup.stringdata))
        return static_cast<void*>(const_cast< QCPBarsGroup*>(this));
    return QObject::qt_metacast(_clname);
}

int QCPBarsGroup::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< SpacingType*>(_v) = spacingType(); break;
        case 1: *reinterpret_cast< double*>(_v) = spacing(); break;
        default: break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setSpacingType(*reinterpret_cast< SpacingType*>(_v)); break;
        case 1: setSpacing(*reinterpret_cast< double*>(_v)); break;
        default: break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPBars_t {
    QByteArrayData data[14];
    char stringdata[147];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPBars_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPBars_t qt_meta_stringdata_QCPBars = {
    {
QT_MOC_LITERAL(0, 0, 7),
QT_MOC_LITERAL(1, 8, 5),
QT_MOC_LITERAL(2, 14, 9),
QT_MOC_LITERAL(3, 24, 9),
QT_MOC_LITERAL(4, 34, 9),
QT_MOC_LITERAL(5, 44, 13),
QT_MOC_LITERAL(6, 58, 9),
QT_MOC_LITERAL(7, 68, 11),
QT_MOC_LITERAL(8, 80, 8),
QT_MOC_LITERAL(9, 89, 8),
QT_MOC_LITERAL(10, 98, 8),
QT_MOC_LITERAL(11, 107, 10),
QT_MOC_LITERAL(12, 118, 15),
QT_MOC_LITERAL(13, 134, 12)
    },
    "QCPBars\0width\0widthType\0WidthType\0"
    "barsGroup\0QCPBarsGroup*\0baseValue\0"
    "stackingGap\0barBelow\0QCPBars*\0barAbove\0"
    "wtAbsolute\0wtAxisRectRatio\0wtPlotCoords"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPBars[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       7,   14, // properties
       1,   35, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Double, 0x00095103,
       2, 0x80000000 | 3, 0x0009510b,
       4, 0x80000000 | 5, 0x0009510b,
       6, QMetaType::Double, 0x00095103,
       7, QMetaType::Double, 0x00095103,
       8, 0x80000000 | 9, 0x00095009,
      10, 0x80000000 | 9, 0x00095009,

 // enums: name, flags, count, data
       3, 0x0,    3,   39,

 // enum data: key, value
      11, uint(QCPBars::wtAbsolute),
      12, uint(QCPBars::wtAxisRectRatio),
      13, uint(QCPBars::wtPlotCoords),

       0        // eod
};

void QCPBars::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
        case 5:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPBars* >(); break;
        case 2:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPBarsGroup* >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPBars::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPBarsData>::staticMetaObject, qt_meta_stringdata_QCPBars.data,
      qt_meta_data_QCPBars,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPBars::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPBars::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPBars.stringdata))
        return static_cast<void*>(const_cast< QCPBars*>(this));
    return QCPAbstractPlottable1D<QCPBarsData>::qt_metacast(_clname);
}

int QCPBars::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPBarsData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = width(); break;
        case 1: *reinterpret_cast< WidthType*>(_v) = widthType(); break;
        case 2: *reinterpret_cast< QCPBarsGroup**>(_v) = barsGroup(); break;
        case 3: *reinterpret_cast< double*>(_v) = baseValue(); break;
        case 4: *reinterpret_cast< double*>(_v) = stackingGap(); break;
        case 5: *reinterpret_cast< QCPBars**>(_v) = barBelow(); break;
        case 6: *reinterpret_cast< QCPBars**>(_v) = barAbove(); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setWidth(*reinterpret_cast< double*>(_v)); break;
        case 1: setWidthType(*reinterpret_cast< WidthType*>(_v)); break;
        case 2: setBarsGroup(*reinterpret_cast< QCPBarsGroup**>(_v)); break;
        case 3: setBaseValue(*reinterpret_cast< double*>(_v)); break;
        case 4: setStackingGap(*reinterpret_cast< double*>(_v)); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPStatisticalBox_t {
    QByteArrayData data[9];
    char stringdata[120];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPStatisticalBox_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPStatisticalBox_t qt_meta_stringdata_QCPStatisticalBox = {
    {
QT_MOC_LITERAL(0, 0, 17),
QT_MOC_LITERAL(1, 18, 5),
QT_MOC_LITERAL(2, 24, 12),
QT_MOC_LITERAL(3, 37, 10),
QT_MOC_LITERAL(4, 48, 13),
QT_MOC_LITERAL(5, 62, 18),
QT_MOC_LITERAL(6, 81, 9),
QT_MOC_LITERAL(7, 91, 12),
QT_MOC_LITERAL(8, 104, 15)
    },
    "QCPStatisticalBox\0width\0whiskerWidth\0"
    "whiskerPen\0whiskerBarPen\0whiskerAntialiased\0"
    "medianPen\0outlierStyle\0QCPScatterStyle"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPStatisticalBox[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       7,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Double, 0x00095103,
       2, QMetaType::Double, 0x00095103,
       3, QMetaType::QPen, 0x00095103,
       4, QMetaType::QPen, 0x00095103,
       5, QMetaType::Bool, 0x00095103,
       6, QMetaType::QPen, 0x00095103,
       7, 0x80000000 | 8, 0x0009510b,

       0        // eod
};

void QCPStatisticalBox::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPStatisticalBox::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPStatisticalBoxData>::staticMetaObject, qt_meta_stringdata_QCPStatisticalBox.data,
      qt_meta_data_QCPStatisticalBox,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPStatisticalBox::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPStatisticalBox::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPStatisticalBox.stringdata))
        return static_cast<void*>(const_cast< QCPStatisticalBox*>(this));
    return QCPAbstractPlottable1D<QCPStatisticalBoxData>::qt_metacast(_clname);
}

int QCPStatisticalBox::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPStatisticalBoxData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< double*>(_v) = width(); break;
        case 1: *reinterpret_cast< double*>(_v) = whiskerWidth(); break;
        case 2: *reinterpret_cast< QPen*>(_v) = whiskerPen(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = whiskerBarPen(); break;
        case 4: *reinterpret_cast< bool*>(_v) = whiskerAntialiased(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = medianPen(); break;
        case 6: *reinterpret_cast< QCPScatterStyle*>(_v) = outlierStyle(); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setWidth(*reinterpret_cast< double*>(_v)); break;
        case 1: setWhiskerWidth(*reinterpret_cast< double*>(_v)); break;
        case 2: setWhiskerPen(*reinterpret_cast< QPen*>(_v)); break;
        case 3: setWhiskerBarPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setWhiskerAntialiased(*reinterpret_cast< bool*>(_v)); break;
        case 5: setMedianPen(*reinterpret_cast< QPen*>(_v)); break;
        case 6: setOutlierStyle(*reinterpret_cast< QCPScatterStyle*>(_v)); break;
        default: break;
        }
        _id -= 7;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 7;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 7;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPColorMap_t {
    QByteArrayData data[25];
    char stringdata[334];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPColorMap_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPColorMap_t qt_meta_stringdata_QCPColorMap = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 16),
QT_MOC_LITERAL(2, 29, 0),
QT_MOC_LITERAL(3, 30, 8),
QT_MOC_LITERAL(4, 39, 8),
QT_MOC_LITERAL(5, 48, 20),
QT_MOC_LITERAL(6, 69, 18),
QT_MOC_LITERAL(7, 88, 9),
QT_MOC_LITERAL(8, 98, 15),
QT_MOC_LITERAL(9, 114, 16),
QT_MOC_LITERAL(10, 131, 11),
QT_MOC_LITERAL(11, 143, 12),
QT_MOC_LITERAL(12, 156, 9),
QT_MOC_LITERAL(13, 166, 16),
QT_MOC_LITERAL(14, 183, 11),
QT_MOC_LITERAL(15, 195, 8),
QT_MOC_LITERAL(16, 204, 16),
QT_MOC_LITERAL(17, 221, 22),
QT_MOC_LITERAL(18, 244, 13),
QT_MOC_LITERAL(19, 258, 9),
QT_MOC_LITERAL(20, 268, 13),
QT_MOC_LITERAL(21, 282, 11),
QT_MOC_LITERAL(22, 294, 13),
QT_MOC_LITERAL(23, 308, 10),
QT_MOC_LITERAL(24, 319, 14)
    },
    "QCPColorMap\0dataRangeChanged\0\0QCPRange\0"
    "newRange\0dataScaleTypeChanged\0"
    "QCPAxis::ScaleType\0scaleType\0"
    "gradientChanged\0QCPColorGradient\0"
    "newGradient\0setDataRange\0dataRange\0"
    "setDataScaleType\0setGradient\0gradient\0"
    "updateLegendIcon\0Qt::TransformationMode\0"
    "transformMode\0thumbSize\0dataScaleType\0"
    "interpolate\0tightBoundary\0colorScale\0"
    "QCPColorScale*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPColorMap[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       6,   86, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       3,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       5,    1,   62,    2, 0x06 /* Public */,
       8,    1,   65,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      11,    1,   68,    2, 0x0a /* Public */,
      13,    1,   71,    2, 0x0a /* Public */,
      14,    1,   74,    2, 0x0a /* Public */,
      16,    2,   77,    2, 0x0a /* Public */,
      16,    1,   82,    2, 0x2a /* Public | MethodCloned */,
      16,    0,   85,    2, 0x2a /* Public | MethodCloned */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   10,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,   12,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, 0x80000000 | 9,   15,
    QMetaType::Void, 0x80000000 | 17, QMetaType::QSize,   18,   19,
    QMetaType::Void, 0x80000000 | 17,   18,
    QMetaType::Void,

 // properties: name, type, flags
      12, 0x80000000 | 3, 0x0049510b,
      20, 0x80000000 | 6, 0x0049510b,
      15, 0x80000000 | 9, 0x0049510b,
      21, QMetaType::Bool, 0x00095103,
      22, QMetaType::Bool, 0x00095103,
      23, 0x80000000 | 24, 0x0009510b,

 // properties: notify_signal_id
       0,
       1,
       2,
       0,
       0,
       0,

       0        // eod
};

void QCPColorMap::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        QCPColorMap *_t = static_cast<QCPColorMap *>(_o);
        switch (_id) {
        case 0: _t->dataRangeChanged((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 1: _t->dataScaleTypeChanged((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 2: _t->gradientChanged((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 3: _t->setDataRange((*reinterpret_cast< const QCPRange(*)>(_a[1]))); break;
        case 4: _t->setDataScaleType((*reinterpret_cast< QCPAxis::ScaleType(*)>(_a[1]))); break;
        case 5: _t->setGradient((*reinterpret_cast< const QCPColorGradient(*)>(_a[1]))); break;
        case 6: _t->updateLegendIcon((*reinterpret_cast< Qt::TransformationMode(*)>(_a[1])),(*reinterpret_cast< const QSize(*)>(_a[2]))); break;
        case 7: _t->updateLegendIcon((*reinterpret_cast< Qt::TransformationMode(*)>(_a[1]))); break;
        case 8: _t->updateLegendIcon(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
            }
            break;
        case 4:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
            }
            break;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (QCPColorMap::*_t)(const QCPRange & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorMap::dataRangeChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (QCPColorMap::*_t)(QCPAxis::ScaleType );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorMap::dataScaleTypeChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (QCPColorMap::*_t)(const QCPColorGradient & );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&QCPColorMap::gradientChanged)) {
                *result = 2;
            }
        }
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAxis::ScaleType >(); break;
        case 5:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPColorScale* >(); break;
        }
    }

}

static const QMetaObject * const qt_meta_extradata_QCPColorMap[] = {
        &QCPAxis::staticMetaObject,
    0
};

const QMetaObject QCPColorMap::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPColorMap.data,
      qt_meta_data_QCPColorMap,  qt_static_metacall, qt_meta_extradata_QCPColorMap, 0}
};


const QMetaObject *QCPColorMap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPColorMap::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPColorMap.stringdata))
        return static_cast<void*>(const_cast< QCPColorMap*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPColorMap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
#ifndef QT_NO_PROPERTIES
      else if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QCPRange*>(_v) = dataRange(); break;
        case 1: *reinterpret_cast< QCPAxis::ScaleType*>(_v) = dataScaleType(); break;
        case 2: *reinterpret_cast< QCPColorGradient*>(_v) = gradient(); break;
        case 3: *reinterpret_cast< bool*>(_v) = interpolate(); break;
        case 4: *reinterpret_cast< bool*>(_v) = tightBoundary(); break;
        case 5: *reinterpret_cast< QCPColorScale**>(_v) = colorScale(); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setDataRange(*reinterpret_cast< QCPRange*>(_v)); break;
        case 1: setDataScaleType(*reinterpret_cast< QCPAxis::ScaleType*>(_v)); break;
        case 2: setGradient(*reinterpret_cast< QCPColorGradient*>(_v)); break;
        case 3: setInterpolate(*reinterpret_cast< bool*>(_v)); break;
        case 4: setTightBoundary(*reinterpret_cast< bool*>(_v)); break;
        case 5: setColorScale(*reinterpret_cast< QCPColorScale**>(_v)); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void QCPColorMap::dataRangeChanged(const QCPRange & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void QCPColorMap::dataScaleTypeChanged(QCPAxis::ScaleType _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void QCPColorMap::gradientChanged(const QCPColorGradient & _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}
struct qt_meta_stringdata_QCPFinancial_t {
    QByteArrayData data[16];
    char stringdata[185];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPFinancial_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPFinancial_t qt_meta_stringdata_QCPFinancial = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 10),
QT_MOC_LITERAL(2, 24, 10),
QT_MOC_LITERAL(3, 35, 5),
QT_MOC_LITERAL(4, 41, 9),
QT_MOC_LITERAL(5, 51, 9),
QT_MOC_LITERAL(6, 61, 10),
QT_MOC_LITERAL(7, 72, 13),
QT_MOC_LITERAL(8, 86, 13),
QT_MOC_LITERAL(9, 100, 11),
QT_MOC_LITERAL(10, 112, 11),
QT_MOC_LITERAL(11, 124, 10),
QT_MOC_LITERAL(12, 135, 15),
QT_MOC_LITERAL(13, 151, 12),
QT_MOC_LITERAL(14, 164, 6),
QT_MOC_LITERAL(15, 171, 13)
    },
    "QCPFinancial\0chartStyle\0ChartStyle\0"
    "width\0widthType\0WidthType\0twoColored\0"
    "brushPositive\0brushNegative\0penPositive\0"
    "penNegative\0wtAbsolute\0wtAxisRectRatio\0"
    "wtPlotCoords\0csOhlc\0csCandlestick"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPFinancial[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       8,   14, // properties
       2,   38, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, QMetaType::Double, 0x00095103,
       4, 0x80000000 | 5, 0x0009510b,
       6, QMetaType::Bool, 0x00095103,
       7, QMetaType::QBrush, 0x00095103,
       8, QMetaType::QBrush, 0x00095103,
       9, QMetaType::QPen, 0x00095103,
      10, QMetaType::QPen, 0x00095103,

 // enums: name, flags, count, data
       5, 0x0,    3,   46,
       2, 0x0,    2,   52,

 // enum data: key, value
      11, uint(QCPFinancial::wtAbsolute),
      12, uint(QCPFinancial::wtAxisRectRatio),
      13, uint(QCPFinancial::wtPlotCoords),
      14, uint(QCPFinancial::csOhlc),
      15, uint(QCPFinancial::csCandlestick),

       0        // eod
};

void QCPFinancial::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPFinancial::staticMetaObject = {
    { &QCPAbstractPlottable1D<QCPFinancialData>::staticMetaObject, qt_meta_stringdata_QCPFinancial.data,
      qt_meta_data_QCPFinancial,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPFinancial::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPFinancial::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPFinancial.stringdata))
        return static_cast<void*>(const_cast< QCPFinancial*>(this));
    return QCPAbstractPlottable1D<QCPFinancialData>::qt_metacast(_clname);
}

int QCPFinancial::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable1D<QCPFinancialData>::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< ChartStyle*>(_v) = chartStyle(); break;
        case 1: *reinterpret_cast< double*>(_v) = width(); break;
        case 2: *reinterpret_cast< WidthType*>(_v) = widthType(); break;
        case 3: *reinterpret_cast< bool*>(_v) = twoColored(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = brushPositive(); break;
        case 5: *reinterpret_cast< QBrush*>(_v) = brushNegative(); break;
        case 6: *reinterpret_cast< QPen*>(_v) = penPositive(); break;
        case 7: *reinterpret_cast< QPen*>(_v) = penNegative(); break;
        default: break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setChartStyle(*reinterpret_cast< ChartStyle*>(_v)); break;
        case 1: setWidth(*reinterpret_cast< double*>(_v)); break;
        case 2: setWidthType(*reinterpret_cast< WidthType*>(_v)); break;
        case 3: setTwoColored(*reinterpret_cast< bool*>(_v)); break;
        case 4: setBrushPositive(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: setBrushNegative(*reinterpret_cast< QBrush*>(_v)); break;
        case 6: setPenPositive(*reinterpret_cast< QPen*>(_v)); break;
        case 7: setPenNegative(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
        _id -= 8;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 8;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 8;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 8)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 8;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPErrorBars_t {
    QByteArrayData data[11];
    char stringdata[163];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPErrorBars_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPErrorBars_t qt_meta_stringdata_QCPErrorBars = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 4),
QT_MOC_LITERAL(2, 18, 41),
QT_MOC_LITERAL(3, 60, 13),
QT_MOC_LITERAL(4, 74, 21),
QT_MOC_LITERAL(5, 96, 9),
QT_MOC_LITERAL(6, 106, 9),
QT_MOC_LITERAL(7, 116, 12),
QT_MOC_LITERAL(8, 129, 9),
QT_MOC_LITERAL(9, 139, 10),
QT_MOC_LITERAL(10, 150, 12)
    },
    "QCPErrorBars\0data\0"
    "QSharedPointer<QCPErrorBarsDataContainer>\0"
    "dataPlottable\0QCPAbstractPlottable*\0"
    "errorType\0ErrorType\0whiskerWidth\0"
    "symbolGap\0etKeyError\0etValueError"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPErrorBars[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       5,   14, // properties
       1,   29, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009510b,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 6, 0x0009510b,
       7, QMetaType::Double, 0x00095103,
       8, QMetaType::Double, 0x00095103,

 // enums: name, flags, count, data
       6, 0x0,    2,   33,

 // enum data: key, value
       9, uint(QCPErrorBars::etKeyError),
      10, uint(QCPErrorBars::etValueError),

       0        // eod
};

void QCPErrorBars::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 1:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPAbstractPlottable* >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPErrorBars::staticMetaObject = {
    { &QCPAbstractPlottable::staticMetaObject, qt_meta_stringdata_QCPErrorBars.data,
      qt_meta_data_QCPErrorBars,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPErrorBars::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPErrorBars::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPErrorBars.stringdata))
        return static_cast<void*>(const_cast< QCPErrorBars*>(this));
    if (!strcmp(_clname, "QCPPlottableInterface1D"))
        return static_cast< QCPPlottableInterface1D*>(const_cast< QCPErrorBars*>(this));
    return QCPAbstractPlottable::qt_metacast(_clname);
}

int QCPErrorBars::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractPlottable::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QSharedPointer<QCPErrorBarsDataContainer>*>(_v) = data(); break;
        case 1: *reinterpret_cast< QCPAbstractPlottable**>(_v) = dataPlottable(); break;
        case 2: *reinterpret_cast< ErrorType*>(_v) = errorType(); break;
        case 3: *reinterpret_cast< double*>(_v) = whiskerWidth(); break;
        case 4: *reinterpret_cast< double*>(_v) = symbolGap(); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setData(*reinterpret_cast< QSharedPointer<QCPErrorBarsDataContainer>*>(_v)); break;
        case 1: setDataPlottable(*reinterpret_cast< QCPAbstractPlottable**>(_v)); break;
        case 2: setErrorType(*reinterpret_cast< ErrorType*>(_v)); break;
        case 3: setWhiskerWidth(*reinterpret_cast< double*>(_v)); break;
        case 4: setSymbolGap(*reinterpret_cast< double*>(_v)); break;
        default: break;
        }
        _id -= 5;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 5;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 5;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 5)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 5;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemStraightLine_t {
    QByteArrayData data[3];
    char stringdata[36];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemStraightLine_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemStraightLine_t qt_meta_stringdata_QCPItemStraightLine = {
    {
QT_MOC_LITERAL(0, 0, 19),
QT_MOC_LITERAL(1, 20, 3),
QT_MOC_LITERAL(2, 24, 11)
    },
    "QCPItemStraightLine\0pen\0selectedPen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemStraightLine[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,

       0        // eod
};

void QCPItemStraightLine::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemStraightLine::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemStraightLine.data,
      qt_meta_data_QCPItemStraightLine,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemStraightLine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemStraightLine::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemStraightLine.stringdata))
        return static_cast<void*>(const_cast< QCPItemStraightLine*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemStraightLine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        default: break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
        _id -= 2;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 2)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemLine_t {
    QByteArrayData data[6];
    char stringdata[52];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemLine_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemLine_t qt_meta_stringdata_QCPItemLine = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 3),
QT_MOC_LITERAL(2, 16, 11),
QT_MOC_LITERAL(3, 28, 4),
QT_MOC_LITERAL(4, 33, 13),
QT_MOC_LITERAL(5, 47, 4)
    },
    "QCPItemLine\0pen\0selectedPen\0head\0"
    "QCPLineEnding\0tail"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemLine[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 4, 0x0009510b,

       0        // eod
};

void QCPItemLine::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemLine::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemLine.data,
      qt_meta_data_QCPItemLine,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemLine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemLine::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemLine.stringdata))
        return static_cast<void*>(const_cast< QCPItemLine*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemLine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QCPLineEnding*>(_v) = head(); break;
        case 3: *reinterpret_cast< QCPLineEnding*>(_v) = tail(); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setHead(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 3: setTail(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemCurve_t {
    QByteArrayData data[6];
    char stringdata[53];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemCurve_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemCurve_t qt_meta_stringdata_QCPItemCurve = {
    {
QT_MOC_LITERAL(0, 0, 12),
QT_MOC_LITERAL(1, 13, 3),
QT_MOC_LITERAL(2, 17, 11),
QT_MOC_LITERAL(3, 29, 4),
QT_MOC_LITERAL(4, 34, 13),
QT_MOC_LITERAL(5, 48, 4)
    },
    "QCPItemCurve\0pen\0selectedPen\0head\0"
    "QCPLineEnding\0tail"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemCurve[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, 0x80000000 | 4, 0x0009510b,
       5, 0x80000000 | 4, 0x0009510b,

       0        // eod
};

void QCPItemCurve::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemCurve::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemCurve.data,
      qt_meta_data_QCPItemCurve,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemCurve::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemCurve::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemCurve.stringdata))
        return static_cast<void*>(const_cast< QCPItemCurve*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemCurve::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QCPLineEnding*>(_v) = head(); break;
        case 3: *reinterpret_cast< QCPLineEnding*>(_v) = tail(); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setHead(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        case 3: setTail(*reinterpret_cast< QCPLineEnding*>(_v)); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemRect_t {
    QByteArrayData data[5];
    char stringdata[48];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemRect_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemRect_t qt_meta_stringdata_QCPItemRect = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 3),
QT_MOC_LITERAL(2, 16, 11),
QT_MOC_LITERAL(3, 28, 5),
QT_MOC_LITERAL(4, 34, 13)
    },
    "QCPItemRect\0pen\0selectedPen\0brush\0"
    "selectedBrush"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemRect[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::QBrush, 0x00095103,
       4, QMetaType::QBrush, 0x00095103,

       0        // eod
};

void QCPItemRect::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemRect::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemRect.data,
      qt_meta_data_QCPItemRect,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemRect::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemRect::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemRect.stringdata))
        return static_cast<void*>(const_cast< QCPItemRect*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemRect::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemText_t {
    QByteArrayData data[16];
    char stringdata[163];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemText_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemText_t qt_meta_stringdata_QCPItemText = {
    {
QT_MOC_LITERAL(0, 0, 11),
QT_MOC_LITERAL(1, 12, 5),
QT_MOC_LITERAL(2, 18, 13),
QT_MOC_LITERAL(3, 32, 3),
QT_MOC_LITERAL(4, 36, 11),
QT_MOC_LITERAL(5, 48, 5),
QT_MOC_LITERAL(6, 54, 13),
QT_MOC_LITERAL(7, 68, 4),
QT_MOC_LITERAL(8, 73, 12),
QT_MOC_LITERAL(9, 86, 4),
QT_MOC_LITERAL(10, 91, 17),
QT_MOC_LITERAL(11, 109, 13),
QT_MOC_LITERAL(12, 123, 13),
QT_MOC_LITERAL(13, 137, 8),
QT_MOC_LITERAL(14, 146, 7),
QT_MOC_LITERAL(15, 154, 8)
    },
    "QCPItemText\0color\0selectedColor\0pen\0"
    "selectedPen\0brush\0selectedBrush\0font\0"
    "selectedFont\0text\0positionAlignment\0"
    "Qt::Alignment\0textAlignment\0rotation\0"
    "padding\0QMargins"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemText[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
      13,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QColor, 0x00095103,
       2, QMetaType::QColor, 0x00095103,
       3, QMetaType::QPen, 0x00095103,
       4, QMetaType::QPen, 0x00095103,
       5, QMetaType::QBrush, 0x00095103,
       6, QMetaType::QBrush, 0x00095103,
       7, QMetaType::QFont, 0x00095103,
       8, QMetaType::QFont, 0x00095103,
       9, QMetaType::QString, 0x00095103,
      10, 0x80000000 | 11, 0x0009510b,
      12, 0x80000000 | 11, 0x0009510b,
      13, QMetaType::Double, 0x00095103,
      14, 0x80000000 | 15, 0x0009510b,

       0        // eod
};

void QCPItemText::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemText::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemText.data,
      qt_meta_data_QCPItemText,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemText::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemText::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemText.stringdata))
        return static_cast<void*>(const_cast< QCPItemText*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemText::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QColor*>(_v) = color(); break;
        case 1: *reinterpret_cast< QColor*>(_v) = selectedColor(); break;
        case 2: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 3: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 4: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 5: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        case 6: *reinterpret_cast< QFont*>(_v) = font(); break;
        case 7: *reinterpret_cast< QFont*>(_v) = selectedFont(); break;
        case 8: *reinterpret_cast< QString*>(_v) = text(); break;
        case 9: *reinterpret_cast< Qt::Alignment*>(_v) = positionAlignment(); break;
        case 10: *reinterpret_cast< Qt::Alignment*>(_v) = textAlignment(); break;
        case 11: *reinterpret_cast< double*>(_v) = rotation(); break;
        case 12: *reinterpret_cast< QMargins*>(_v) = padding(); break;
        default: break;
        }
        _id -= 13;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setColor(*reinterpret_cast< QColor*>(_v)); break;
        case 1: setSelectedColor(*reinterpret_cast< QColor*>(_v)); break;
        case 2: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 3: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 4: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 5: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 6: setFont(*reinterpret_cast< QFont*>(_v)); break;
        case 7: setSelectedFont(*reinterpret_cast< QFont*>(_v)); break;
        case 8: setText(*reinterpret_cast< QString*>(_v)); break;
        case 9: setPositionAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 10: setTextAlignment(*reinterpret_cast< Qt::Alignment*>(_v)); break;
        case 11: setRotation(*reinterpret_cast< double*>(_v)); break;
        case 12: setPadding(*reinterpret_cast< QMargins*>(_v)); break;
        default: break;
        }
        _id -= 13;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 13;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 13;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 13)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 13;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemEllipse_t {
    QByteArrayData data[5];
    char stringdata[51];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemEllipse_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemEllipse_t qt_meta_stringdata_QCPItemEllipse = {
    {
QT_MOC_LITERAL(0, 0, 14),
QT_MOC_LITERAL(1, 15, 3),
QT_MOC_LITERAL(2, 19, 11),
QT_MOC_LITERAL(3, 31, 5),
QT_MOC_LITERAL(4, 37, 13)
    },
    "QCPItemEllipse\0pen\0selectedPen\0brush\0"
    "selectedBrush"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemEllipse[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::QBrush, 0x00095103,
       4, QMetaType::QBrush, 0x00095103,

       0        // eod
};

void QCPItemEllipse::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemEllipse::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemEllipse.data,
      qt_meta_data_QCPItemEllipse,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemEllipse::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemEllipse::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemEllipse.stringdata))
        return static_cast<void*>(const_cast< QCPItemEllipse*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemEllipse::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemPixmap_t {
    QByteArrayData data[9];
    char stringdata[122];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemPixmap_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemPixmap_t qt_meta_stringdata_QCPItemPixmap = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 6),
QT_MOC_LITERAL(2, 21, 6),
QT_MOC_LITERAL(3, 28, 15),
QT_MOC_LITERAL(4, 44, 19),
QT_MOC_LITERAL(5, 64, 18),
QT_MOC_LITERAL(6, 83, 22),
QT_MOC_LITERAL(7, 106, 3),
QT_MOC_LITERAL(8, 110, 11)
    },
    "QCPItemPixmap\0pixmap\0scaled\0aspectRatioMode\0"
    "Qt::AspectRatioMode\0transformationMode\0"
    "Qt::TransformationMode\0pen\0selectedPen"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemPixmap[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPixmap, 0x00095103,
       2, QMetaType::Bool, 0x00095103,
       3, 0x80000000 | 4, 0x00095009,
       5, 0x80000000 | 6, 0x00095009,
       7, QMetaType::QPen, 0x00095103,
       8, QMetaType::QPen, 0x00095103,

       0        // eod
};

void QCPItemPixmap::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemPixmap::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemPixmap.data,
      qt_meta_data_QCPItemPixmap,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemPixmap::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemPixmap::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemPixmap.stringdata))
        return static_cast<void*>(const_cast< QCPItemPixmap*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemPixmap::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPixmap*>(_v) = pixmap(); break;
        case 1: *reinterpret_cast< bool*>(_v) = scaled(); break;
        case 2: *reinterpret_cast< Qt::AspectRatioMode*>(_v) = aspectRatioMode(); break;
        case 3: *reinterpret_cast< Qt::TransformationMode*>(_v) = transformationMode(); break;
        case 4: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 5: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPixmap(*reinterpret_cast< QPixmap*>(_v)); break;
        case 1: setScaled(*reinterpret_cast< bool*>(_v)); break;
        case 4: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 5: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        default: break;
        }
        _id -= 6;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 6;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 6;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemTracer_t {
    QByteArrayData data[17];
    char stringdata[156];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemTracer_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemTracer_t qt_meta_stringdata_QCPItemTracer = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 3),
QT_MOC_LITERAL(2, 18, 11),
QT_MOC_LITERAL(3, 30, 5),
QT_MOC_LITERAL(4, 36, 13),
QT_MOC_LITERAL(5, 50, 4),
QT_MOC_LITERAL(6, 55, 5),
QT_MOC_LITERAL(7, 61, 11),
QT_MOC_LITERAL(8, 73, 5),
QT_MOC_LITERAL(9, 79, 9),
QT_MOC_LITERAL(10, 89, 8),
QT_MOC_LITERAL(11, 98, 13),
QT_MOC_LITERAL(12, 112, 6),
QT_MOC_LITERAL(13, 119, 6),
QT_MOC_LITERAL(14, 126, 11),
QT_MOC_LITERAL(15, 138, 8),
QT_MOC_LITERAL(16, 147, 8)
    },
    "QCPItemTracer\0pen\0selectedPen\0brush\0"
    "selectedBrush\0size\0style\0TracerStyle\0"
    "graph\0QCPGraph*\0graphKey\0interpolating\0"
    "tsNone\0tsPlus\0tsCrosshair\0tsCircle\0"
    "tsSquare"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemTracer[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       9,   14, // properties
       1,   41, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::QBrush, 0x00095103,
       4, QMetaType::QBrush, 0x00095103,
       5, QMetaType::Double, 0x00095103,
       6, 0x80000000 | 7, 0x0009510b,
       8, 0x80000000 | 9, 0x0009510b,
      10, QMetaType::Double, 0x00095103,
      11, QMetaType::Bool, 0x00095103,

 // enums: name, flags, count, data
       7, 0x0,    5,   45,

 // enum data: key, value
      12, uint(QCPItemTracer::tsNone),
      13, uint(QCPItemTracer::tsPlus),
      14, uint(QCPItemTracer::tsCrosshair),
      15, uint(QCPItemTracer::tsCircle),
      16, uint(QCPItemTracer::tsSquare),

       0        // eod
};

void QCPItemTracer::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::RegisterPropertyMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 6:
            *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QCPGraph* >(); break;
        }
    }

    Q_UNUSED(_o);
}

const QMetaObject QCPItemTracer::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemTracer.data,
      qt_meta_data_QCPItemTracer,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemTracer::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemTracer::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemTracer.stringdata))
        return static_cast<void*>(const_cast< QCPItemTracer*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemTracer::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< QBrush*>(_v) = brush(); break;
        case 3: *reinterpret_cast< QBrush*>(_v) = selectedBrush(); break;
        case 4: *reinterpret_cast< double*>(_v) = size(); break;
        case 5: *reinterpret_cast< TracerStyle*>(_v) = style(); break;
        case 6: *reinterpret_cast< QCPGraph**>(_v) = graph(); break;
        case 7: *reinterpret_cast< double*>(_v) = graphKey(); break;
        case 8: *reinterpret_cast< bool*>(_v) = interpolating(); break;
        default: break;
        }
        _id -= 9;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 3: setSelectedBrush(*reinterpret_cast< QBrush*>(_v)); break;
        case 4: setSize(*reinterpret_cast< double*>(_v)); break;
        case 5: setStyle(*reinterpret_cast< TracerStyle*>(_v)); break;
        case 6: setGraph(*reinterpret_cast< QCPGraph**>(_v)); break;
        case 7: setGraphKey(*reinterpret_cast< double*>(_v)); break;
        case 8: setInterpolating(*reinterpret_cast< bool*>(_v)); break;
        default: break;
        }
        _id -= 9;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 9;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 9;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
struct qt_meta_stringdata_QCPItemBracket_t {
    QByteArrayData data[10];
    char stringdata[97];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_QCPItemBracket_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_QCPItemBracket_t qt_meta_stringdata_QCPItemBracket = {
    {
QT_MOC_LITERAL(0, 0, 14),
QT_MOC_LITERAL(1, 15, 3),
QT_MOC_LITERAL(2, 19, 11),
QT_MOC_LITERAL(3, 31, 6),
QT_MOC_LITERAL(4, 38, 5),
QT_MOC_LITERAL(5, 44, 12),
QT_MOC_LITERAL(6, 57, 8),
QT_MOC_LITERAL(7, 66, 7),
QT_MOC_LITERAL(8, 74, 7),
QT_MOC_LITERAL(9, 82, 14)
    },
    "QCPItemBracket\0pen\0selectedPen\0length\0"
    "style\0BracketStyle\0bsSquare\0bsRound\0"
    "bsCurly\0bsCalligraphic"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_QCPItemBracket[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       4,   14, // properties
       1,   26, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::QPen, 0x00095103,
       2, QMetaType::QPen, 0x00095103,
       3, QMetaType::Double, 0x00095103,
       4, 0x80000000 | 5, 0x0009510b,

 // enums: name, flags, count, data
       5, 0x0,    4,   30,

 // enum data: key, value
       6, uint(QCPItemBracket::bsSquare),
       7, uint(QCPItemBracket::bsRound),
       8, uint(QCPItemBracket::bsCurly),
       9, uint(QCPItemBracket::bsCalligraphic),

       0        // eod
};

void QCPItemBracket::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

const QMetaObject QCPItemBracket::staticMetaObject = {
    { &QCPAbstractItem::staticMetaObject, qt_meta_stringdata_QCPItemBracket.data,
      qt_meta_data_QCPItemBracket,  qt_static_metacall, 0, 0}
};


const QMetaObject *QCPItemBracket::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *QCPItemBracket::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_QCPItemBracket.stringdata))
        return static_cast<void*>(const_cast< QCPItemBracket*>(this));
    return QCPAbstractItem::qt_metacast(_clname);
}

int QCPItemBracket::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QCPAbstractItem::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    
#ifndef QT_NO_PROPERTIES
     if (_c == QMetaObject::ReadProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< QPen*>(_v) = pen(); break;
        case 1: *reinterpret_cast< QPen*>(_v) = selectedPen(); break;
        case 2: *reinterpret_cast< double*>(_v) = length(); break;
        case 3: *reinterpret_cast< BracketStyle*>(_v) = style(); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::WriteProperty) {
        void *_v = _a[0];
        switch (_id) {
        case 0: setPen(*reinterpret_cast< QPen*>(_v)); break;
        case 1: setSelectedPen(*reinterpret_cast< QPen*>(_v)); break;
        case 2: setLength(*reinterpret_cast< double*>(_v)); break;
        case 3: setStyle(*reinterpret_cast< BracketStyle*>(_v)); break;
        default: break;
        }
        _id -= 4;
    } else if (_c == QMetaObject::ResetProperty) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 4;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 4;
    } else if (_c == QMetaObject::RegisterPropertyMetaType) {
        if (_id < 4)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 4;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}
QT_END_MOC_NAMESPACE
