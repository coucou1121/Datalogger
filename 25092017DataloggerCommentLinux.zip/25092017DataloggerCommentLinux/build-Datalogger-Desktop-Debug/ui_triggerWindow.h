/********************************************************************************
** Form generated from reading UI file 'triggerWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TRIGGERWINDOW_H
#define UI_TRIGGERWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "analogPlot.h"
#include "digitalPlot.h"
#include "settingTriggerFunction.h"
#include "settingTriggerSetting.h"

QT_BEGIN_NAMESPACE

class Ui_TriggerWindow
{
public:
    QGridLayout *gridLayout;
    QWidget *widgetTriggerTraceT;
    QVBoxLayout *verticalLayout;
    DigitalPlot *widgetDI1;
    DigitalPlot *widgetDI2;
    DigitalPlot *widgetDI3;
    DigitalPlot *widgetDI4;
    AnalogPlot *widgetAI1;
    AnalogPlot *widgetAI2;
    DigitalPlot *widgetFunction;
    SettingTriggerSetting *widgetTriggerSettingT;
    SettingTriggerFunction *widgetTriggerFunctionT;

    void setupUi(QFrame *TriggerWindow)
    {
        if (TriggerWindow->objectName().isEmpty())
            TriggerWindow->setObjectName(QStringLiteral("TriggerWindow"));
        TriggerWindow->resize(919, 437);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(TriggerWindow->sizePolicy().hasHeightForWidth());
        TriggerWindow->setSizePolicy(sizePolicy);
        TriggerWindow->setFrameShape(QFrame::StyledPanel);
        TriggerWindow->setFrameShadow(QFrame::Raised);
        gridLayout = new QGridLayout(TriggerWindow);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 0, 0, 0);
        widgetTriggerTraceT = new QWidget(TriggerWindow);
        widgetTriggerTraceT->setObjectName(QStringLiteral("widgetTriggerTraceT"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widgetTriggerTraceT->sizePolicy().hasHeightForWidth());
        widgetTriggerTraceT->setSizePolicy(sizePolicy1);
        widgetTriggerTraceT->setMinimumSize(QSize(850, 0));
        verticalLayout = new QVBoxLayout(widgetTriggerTraceT);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        widgetDI1 = new DigitalPlot(widgetTriggerTraceT);
        widgetDI1->setObjectName(QStringLiteral("widgetDI1"));
        sizePolicy.setHeightForWidth(widgetDI1->sizePolicy().hasHeightForWidth());
        widgetDI1->setSizePolicy(sizePolicy);
        widgetDI1->setMinimumSize(QSize(0, 0));

        verticalLayout->addWidget(widgetDI1);

        widgetDI2 = new DigitalPlot(widgetTriggerTraceT);
        widgetDI2->setObjectName(QStringLiteral("widgetDI2"));
        sizePolicy.setHeightForWidth(widgetDI2->sizePolicy().hasHeightForWidth());
        widgetDI2->setSizePolicy(sizePolicy);
        widgetDI2->setMinimumSize(QSize(0, 0));

        verticalLayout->addWidget(widgetDI2);

        widgetDI3 = new DigitalPlot(widgetTriggerTraceT);
        widgetDI3->setObjectName(QStringLiteral("widgetDI3"));
        sizePolicy.setHeightForWidth(widgetDI3->sizePolicy().hasHeightForWidth());
        widgetDI3->setSizePolicy(sizePolicy);
        widgetDI3->setMinimumSize(QSize(0, 0));
        widgetDI3->setSizeIncrement(QSize(0, 0));

        verticalLayout->addWidget(widgetDI3);

        widgetDI4 = new DigitalPlot(widgetTriggerTraceT);
        widgetDI4->setObjectName(QStringLiteral("widgetDI4"));

        verticalLayout->addWidget(widgetDI4);

        widgetAI1 = new AnalogPlot(widgetTriggerTraceT);
        widgetAI1->setObjectName(QStringLiteral("widgetAI1"));

        verticalLayout->addWidget(widgetAI1);

        widgetAI2 = new AnalogPlot(widgetTriggerTraceT);
        widgetAI2->setObjectName(QStringLiteral("widgetAI2"));

        verticalLayout->addWidget(widgetAI2);

        widgetFunction = new DigitalPlot(widgetTriggerTraceT);
        widgetFunction->setObjectName(QStringLiteral("widgetFunction"));

        verticalLayout->addWidget(widgetFunction);


        gridLayout->addWidget(widgetTriggerTraceT, 0, 1, 2, 1);

        widgetTriggerSettingT = new SettingTriggerSetting(TriggerWindow);
        widgetTriggerSettingT->setObjectName(QStringLiteral("widgetTriggerSettingT"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(widgetTriggerSettingT->sizePolicy().hasHeightForWidth());
        widgetTriggerSettingT->setSizePolicy(sizePolicy2);
        widgetTriggerSettingT->setMinimumSize(QSize(50, 0));

        gridLayout->addWidget(widgetTriggerSettingT, 0, 0, 1, 1);

        widgetTriggerFunctionT = new SettingTriggerFunction(TriggerWindow);
        widgetTriggerFunctionT->setObjectName(QStringLiteral("widgetTriggerFunctionT"));

        gridLayout->addWidget(widgetTriggerFunctionT, 1, 0, 1, 1);


        retranslateUi(TriggerWindow);

        QMetaObject::connectSlotsByName(TriggerWindow);
    } // setupUi

    void retranslateUi(QFrame *TriggerWindow)
    {
        TriggerWindow->setWindowTitle(QApplication::translate("TriggerWindow", "Frame", 0));
    } // retranslateUi

};

namespace Ui {
    class TriggerWindow: public Ui_TriggerWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TRIGGERWINDOW_H
