/********************************************************************************
** Form generated from reading UI file 'plotSetting.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_PLOTSETTING_H
#define UI_PLOTSETTING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_PlotSetting
{
public:
    QGridLayout *gridLayout;
    QDoubleSpinBox *doubleSpinBox;
    QLabel *labelTitlePlotSetting;

    void setupUi(QFrame *PlotSetting)
    {
        if (PlotSetting->objectName().isEmpty())
            PlotSetting->setObjectName(QStringLiteral("PlotSetting"));
        PlotSetting->resize(164, 90);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(PlotSetting->sizePolicy().hasHeightForWidth());
        PlotSetting->setSizePolicy(sizePolicy);
        PlotSetting->setFrameShape(QFrame::Panel);
        PlotSetting->setFrameShadow(QFrame::Plain);
        gridLayout = new QGridLayout(PlotSetting);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        doubleSpinBox = new QDoubleSpinBox(PlotSetting);
        doubleSpinBox->setObjectName(QStringLiteral("doubleSpinBox"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(doubleSpinBox->sizePolicy().hasHeightForWidth());
        doubleSpinBox->setSizePolicy(sizePolicy1);
        doubleSpinBox->setMinimumSize(QSize(85, 40));
        QFont font;
        font.setPointSize(11);
        font.setBold(true);
        font.setWeight(75);
        doubleSpinBox->setFont(font);
        doubleSpinBox->setDecimals(0);
        doubleSpinBox->setMinimum(40);
        doubleSpinBox->setMaximum(795);
        doubleSpinBox->setSingleStep(40);

        gridLayout->addWidget(doubleSpinBox, 1, 0, 1, 1);

        labelTitlePlotSetting = new QLabel(PlotSetting);
        labelTitlePlotSetting->setObjectName(QStringLiteral("labelTitlePlotSetting"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(labelTitlePlotSetting->sizePolicy().hasHeightForWidth());
        labelTitlePlotSetting->setSizePolicy(sizePolicy2);
        labelTitlePlotSetting->setMinimumSize(QSize(0, 30));
        labelTitlePlotSetting->setMaximumSize(QSize(140, 20));
        QFont font1;
        font1.setPointSize(11);
        labelTitlePlotSetting->setFont(font1);
        labelTitlePlotSetting->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelTitlePlotSetting, 0, 0, 1, 1);


        retranslateUi(PlotSetting);

        QMetaObject::connectSlotsByName(PlotSetting);
    } // setupUi

    void retranslateUi(QFrame *PlotSetting)
    {
        PlotSetting->setWindowTitle(QApplication::translate("PlotSetting", "Frame", 0));
        labelTitlePlotSetting->setText(QApplication::translate("PlotSetting", "Size of plots", 0));
    } // retranslateUi

};

namespace Ui {
    class PlotSetting: public Ui_PlotSetting {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_PLOTSETTING_H
