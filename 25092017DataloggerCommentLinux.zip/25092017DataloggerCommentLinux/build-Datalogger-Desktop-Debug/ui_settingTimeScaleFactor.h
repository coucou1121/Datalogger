/********************************************************************************
** Form generated from reading UI file 'settingTimeScaleFactor.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGTIMESCALEFACTOR_H
#define UI_SETTINGTIMESCALEFACTOR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SettingTimeScaleFactor
{
public:
    QGridLayout *gridLayout_2;
    QLabel *labelTitleTimeScallFactor;
    QFrame *framePeriod;
    QGridLayout *gridLayoutPeriod;
    QLabel *labelPeriod;
    QComboBox *comboBoxPeriod;
    QFrame *frameMiddleTop;
    QGridLayout *gridLayout;
    QLabel *labelMiddleTot;
    QWidget *widgetSampleSecond;
    QGridLayout *gridLayoutSampleSecond;
    QLabel *labelFrequency;
    QLabel *labelFrequencyUnit;
    QLabel *labelTitleSamplingRate;
    QWidget *widgetDuration;
    QGridLayout *gridLayoutDuration;
    QLabel *labelTitleMin;
    QLabel *labelYear;
    QLabel *labelMonth;
    QLabel *labelTitleYear;
    QLabel *labelDay;
    QLabel *labelSec;
    QLabel *labelTitleSec;
    QLabel *labelHrs;
    QLabel *labelTitleMonth;
    QLabel *labelTitleHrs;
    QLabel *labelMin;
    QLabel *labelTitleDay;
    QLabel *labelTitleDuration;
    QWidget *widget_2;
    QFrame *frameLeftBottom;
    QGridLayout *gridLayout_3;
    QLabel *label;

    void setupUi(QFrame *SettingTimeScaleFactor)
    {
        if (SettingTimeScaleFactor->objectName().isEmpty())
            SettingTimeScaleFactor->setObjectName(QStringLiteral("SettingTimeScaleFactor"));
        SettingTimeScaleFactor->resize(700, 250);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingTimeScaleFactor->sizePolicy().hasHeightForWidth());
        SettingTimeScaleFactor->setSizePolicy(sizePolicy);
        SettingTimeScaleFactor->setMinimumSize(QSize(700, 250));
        SettingTimeScaleFactor->setMaximumSize(QSize(700, 300));
        QFont font;
        font.setPointSize(12);
        SettingTimeScaleFactor->setFont(font);
        SettingTimeScaleFactor->setFrameShape(QFrame::Box);
        gridLayout_2 = new QGridLayout(SettingTimeScaleFactor);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setHorizontalSpacing(0);
        gridLayout_2->setVerticalSpacing(7);
        gridLayout_2->setContentsMargins(7, 7, 7, 7);
        labelTitleTimeScallFactor = new QLabel(SettingTimeScaleFactor);
        labelTitleTimeScallFactor->setObjectName(QStringLiteral("labelTitleTimeScallFactor"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(labelTitleTimeScallFactor->sizePolicy().hasHeightForWidth());
        labelTitleTimeScallFactor->setSizePolicy(sizePolicy1);
        labelTitleTimeScallFactor->setMinimumSize(QSize(0, 30));
        labelTitleTimeScallFactor->setFont(font);
        labelTitleTimeScallFactor->setAlignment(Qt::AlignCenter);

        gridLayout_2->addWidget(labelTitleTimeScallFactor, 0, 0, 1, 3);

        framePeriod = new QFrame(SettingTimeScaleFactor);
        framePeriod->setObjectName(QStringLiteral("framePeriod"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(framePeriod->sizePolicy().hasHeightForWidth());
        framePeriod->setSizePolicy(sizePolicy2);
        framePeriod->setFrameShape(QFrame::StyledPanel);
        framePeriod->setFrameShadow(QFrame::Raised);
        gridLayoutPeriod = new QGridLayout(framePeriod);
        gridLayoutPeriod->setObjectName(QStringLiteral("gridLayoutPeriod"));
        labelPeriod = new QLabel(framePeriod);
        labelPeriod->setObjectName(QStringLiteral("labelPeriod"));
        labelPeriod->setAlignment(Qt::AlignCenter);

        gridLayoutPeriod->addWidget(labelPeriod, 0, 0, 1, 1);

        comboBoxPeriod = new QComboBox(framePeriod);
        comboBoxPeriod->setObjectName(QStringLiteral("comboBoxPeriod"));

        gridLayoutPeriod->addWidget(comboBoxPeriod, 1, 0, 1, 1);


        gridLayout_2->addWidget(framePeriod, 1, 0, 1, 1);

        frameMiddleTop = new QFrame(SettingTimeScaleFactor);
        frameMiddleTop->setObjectName(QStringLiteral("frameMiddleTop"));
        sizePolicy2.setHeightForWidth(frameMiddleTop->sizePolicy().hasHeightForWidth());
        frameMiddleTop->setSizePolicy(sizePolicy2);
        frameMiddleTop->setMinimumSize(QSize(60, 0));
        frameMiddleTop->setFrameShape(QFrame::StyledPanel);
        frameMiddleTop->setFrameShadow(QFrame::Raised);
        gridLayout = new QGridLayout(frameMiddleTop);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        labelMiddleTot = new QLabel(frameMiddleTop);
        labelMiddleTot->setObjectName(QStringLiteral("labelMiddleTot"));
        sizePolicy.setHeightForWidth(labelMiddleTot->sizePolicy().hasHeightForWidth());
        labelMiddleTot->setSizePolicy(sizePolicy);
        labelMiddleTot->setPixmap(QPixmap(QString::fromUtf8(":/images/RightFlow.png")));
        labelMiddleTot->setScaledContents(true);
        labelMiddleTot->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelMiddleTot, 0, 0, 1, 1);


        gridLayout_2->addWidget(frameMiddleTop, 1, 1, 1, 1);

        widgetSampleSecond = new QWidget(SettingTimeScaleFactor);
        widgetSampleSecond->setObjectName(QStringLiteral("widgetSampleSecond"));
        widgetSampleSecond->setStyleSheet(QStringLiteral(""));
        gridLayoutSampleSecond = new QGridLayout(widgetSampleSecond);
        gridLayoutSampleSecond->setObjectName(QStringLiteral("gridLayoutSampleSecond"));
        labelFrequency = new QLabel(widgetSampleSecond);
        labelFrequency->setObjectName(QStringLiteral("labelFrequency"));
        labelFrequency->setStyleSheet(QStringLiteral(""));
        labelFrequency->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayoutSampleSecond->addWidget(labelFrequency, 1, 0, 1, 1);

        labelFrequencyUnit = new QLabel(widgetSampleSecond);
        labelFrequencyUnit->setObjectName(QStringLiteral("labelFrequencyUnit"));
        labelFrequencyUnit->setAlignment(Qt::AlignCenter);

        gridLayoutSampleSecond->addWidget(labelFrequencyUnit, 1, 1, 1, 1);

        labelTitleSamplingRate = new QLabel(widgetSampleSecond);
        labelTitleSamplingRate->setObjectName(QStringLiteral("labelTitleSamplingRate"));
        sizePolicy2.setHeightForWidth(labelTitleSamplingRate->sizePolicy().hasHeightForWidth());
        labelTitleSamplingRate->setSizePolicy(sizePolicy2);
        labelTitleSamplingRate->setAlignment(Qt::AlignCenter);

        gridLayoutSampleSecond->addWidget(labelTitleSamplingRate, 0, 0, 1, 2);

        labelTitleSamplingRate->raise();
        labelFrequency->raise();
        labelFrequencyUnit->raise();

        gridLayout_2->addWidget(widgetSampleSecond, 1, 2, 1, 1);

        widgetDuration = new QWidget(SettingTimeScaleFactor);
        widgetDuration->setObjectName(QStringLiteral("widgetDuration"));
        sizePolicy2.setHeightForWidth(widgetDuration->sizePolicy().hasHeightForWidth());
        widgetDuration->setSizePolicy(sizePolicy2);
        gridLayoutDuration = new QGridLayout(widgetDuration);
        gridLayoutDuration->setSpacing(7);
        gridLayoutDuration->setObjectName(QStringLiteral("gridLayoutDuration"));
        gridLayoutDuration->setContentsMargins(2, 2, 2, 2);
        labelTitleMin = new QLabel(widgetDuration);
        labelTitleMin->setObjectName(QStringLiteral("labelTitleMin"));
        labelTitleMin->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleMin, 1, 4, 1, 1);

        labelYear = new QLabel(widgetDuration);
        labelYear->setObjectName(QStringLiteral("labelYear"));
        labelYear->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelYear, 2, 0, 1, 1);

        labelMonth = new QLabel(widgetDuration);
        labelMonth->setObjectName(QStringLiteral("labelMonth"));
        labelMonth->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelMonth, 2, 1, 1, 1);

        labelTitleYear = new QLabel(widgetDuration);
        labelTitleYear->setObjectName(QStringLiteral("labelTitleYear"));
        labelTitleYear->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleYear, 1, 0, 1, 1);

        labelDay = new QLabel(widgetDuration);
        labelDay->setObjectName(QStringLiteral("labelDay"));
        labelDay->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelDay, 2, 2, 1, 1);

        labelSec = new QLabel(widgetDuration);
        labelSec->setObjectName(QStringLiteral("labelSec"));
        labelSec->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelSec, 2, 5, 1, 1);

        labelTitleSec = new QLabel(widgetDuration);
        labelTitleSec->setObjectName(QStringLiteral("labelTitleSec"));
        labelTitleSec->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleSec, 1, 5, 1, 1);

        labelHrs = new QLabel(widgetDuration);
        labelHrs->setObjectName(QStringLiteral("labelHrs"));
        labelHrs->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelHrs, 2, 3, 1, 1);

        labelTitleMonth = new QLabel(widgetDuration);
        labelTitleMonth->setObjectName(QStringLiteral("labelTitleMonth"));
        labelTitleMonth->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleMonth, 1, 1, 1, 1);

        labelTitleHrs = new QLabel(widgetDuration);
        labelTitleHrs->setObjectName(QStringLiteral("labelTitleHrs"));
        labelTitleHrs->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleHrs, 1, 3, 1, 1);

        labelMin = new QLabel(widgetDuration);
        labelMin->setObjectName(QStringLiteral("labelMin"));
        labelMin->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelMin, 2, 4, 1, 1);

        labelTitleDay = new QLabel(widgetDuration);
        labelTitleDay->setObjectName(QStringLiteral("labelTitleDay"));
        labelTitleDay->setMidLineWidth(0);
        labelTitleDay->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleDay, 1, 2, 1, 1);

        labelTitleDuration = new QLabel(widgetDuration);
        labelTitleDuration->setObjectName(QStringLiteral("labelTitleDuration"));
        labelTitleDuration->setAlignment(Qt::AlignCenter);

        gridLayoutDuration->addWidget(labelTitleDuration, 0, 0, 1, 6);


        gridLayout_2->addWidget(widgetDuration, 3, 1, 1, 2);

        widget_2 = new QWidget(SettingTimeScaleFactor);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        sizePolicy1.setHeightForWidth(widget_2->sizePolicy().hasHeightForWidth());
        widget_2->setSizePolicy(sizePolicy1);
        widget_2->setMinimumSize(QSize(0, 20));

        gridLayout_2->addWidget(widget_2, 2, 1, 1, 2);

        frameLeftBottom = new QFrame(SettingTimeScaleFactor);
        frameLeftBottom->setObjectName(QStringLiteral("frameLeftBottom"));
        sizePolicy2.setHeightForWidth(frameLeftBottom->sizePolicy().hasHeightForWidth());
        frameLeftBottom->setSizePolicy(sizePolicy2);
        frameLeftBottom->setMinimumSize(QSize(150, 0));
        frameLeftBottom->setFrameShape(QFrame::StyledPanel);
        frameLeftBottom->setFrameShadow(QFrame::Raised);
        gridLayout_3 = new QGridLayout(frameLeftBottom);
        gridLayout_3->setObjectName(QStringLiteral("gridLayout_3"));
        label = new QLabel(frameLeftBottom);
        label->setObjectName(QStringLiteral("label"));
        sizePolicy.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy);
        label->setMinimumSize(QSize(60, 60));
        label->setPixmap(QPixmap(QString::fromUtf8(":/images/RightAngleFlow.png")));
        label->setScaledContents(true);
        label->setAlignment(Qt::AlignCenter);

        gridLayout_3->addWidget(label, 0, 0, 1, 1);


        gridLayout_2->addWidget(frameLeftBottom, 2, 0, 2, 1);

        widgetSampleSecond->raise();
        framePeriod->raise();
        frameMiddleTop->raise();
        labelTitleTimeScallFactor->raise();
        frameLeftBottom->raise();
        widgetDuration->raise();
        widget_2->raise();

        retranslateUi(SettingTimeScaleFactor);

        QMetaObject::connectSlotsByName(SettingTimeScaleFactor);
    } // setupUi

    void retranslateUi(QFrame *SettingTimeScaleFactor)
    {
        SettingTimeScaleFactor->setWindowTitle(QApplication::translate("SettingTimeScaleFactor", "Form", 0));
        labelTitleTimeScallFactor->setText(QApplication::translate("SettingTimeScaleFactor", "Time scale factor", 0));
        labelPeriod->setText(QApplication::translate("SettingTimeScaleFactor", "Period", 0));
        labelMiddleTot->setText(QString());
        labelFrequency->setText(QString());
        labelFrequencyUnit->setText(QApplication::translate("SettingTimeScaleFactor", "[Hz]", 0));
        labelTitleSamplingRate->setText(QApplication::translate("SettingTimeScaleFactor", "Sampling rate", 0));
        labelTitleMin->setText(QApplication::translate("SettingTimeScaleFactor", "min", 0));
        labelYear->setText(QString());
        labelMonth->setText(QString());
        labelTitleYear->setText(QApplication::translate("SettingTimeScaleFactor", "Year", 0));
        labelDay->setText(QString());
        labelSec->setText(QString());
        labelTitleSec->setText(QApplication::translate("SettingTimeScaleFactor", "sec", 0));
        labelHrs->setText(QString());
        labelTitleMonth->setText(QApplication::translate("SettingTimeScaleFactor", "Month", 0));
        labelTitleHrs->setText(QApplication::translate("SettingTimeScaleFactor", "hrs", 0));
        labelMin->setText(QString());
        labelTitleDay->setText(QApplication::translate("SettingTimeScaleFactor", "Day", 0));
        labelTitleDuration->setText(QApplication::translate("SettingTimeScaleFactor", "Duration", 0));
        label->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SettingTimeScaleFactor: public Ui_SettingTimeScaleFactor {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGTIMESCALEFACTOR_H
