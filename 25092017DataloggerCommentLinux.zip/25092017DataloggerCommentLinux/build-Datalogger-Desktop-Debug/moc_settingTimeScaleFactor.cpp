/****************************************************************************
** Meta object code from reading C++ file 'settingTimeScaleFactor.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../Datalogger/settingTimeScaleFactor.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settingTimeScaleFactor.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SettingTimeScaleFactor_t {
    QByteArrayData data[15];
    char stringdata[257];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SettingTimeScaleFactor_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SettingTimeScaleFactor_t qt_meta_stringdata_SettingTimeScaleFactor = {
    {
QT_MOC_LITERAL(0, 0, 22),
QT_MOC_LITERAL(1, 23, 20),
QT_MOC_LITERAL(2, 44, 0),
QT_MOC_LITERAL(3, 45, 11),
QT_MOC_LITERAL(4, 57, 6),
QT_MOC_LITERAL(5, 64, 36),
QT_MOC_LITERAL(6, 101, 4),
QT_MOC_LITERAL(7, 106, 37),
QT_MOC_LITERAL(8, 144, 5),
QT_MOC_LITERAL(9, 150, 23),
QT_MOC_LITERAL(10, 174, 14),
QT_MOC_LITERAL(11, 189, 20),
QT_MOC_LITERAL(12, 210, 9),
QT_MOC_LITERAL(13, 220, 23),
QT_MOC_LITERAL(14, 244, 12)
    },
    "SettingTimeScaleFactor\0_errorFrequencyToLow\0"
    "\0errorNumber\0active\0"
    "on_comboBoxPeriod_currentTextChanged\0"
    "arg1\0on_comboBoxPeriod_currentIndexChanged\0"
    "index\0_nbFrameSavedWasChanged\0"
    "nbFrameChanged\0_sizeFrameWasChanged\0"
    "frameSize\0_FTDIBaudrateWasChanged\0"
    "FTDIBaudrate"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SettingTimeScaleFactor[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       6,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,   44,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    1,   49,    2, 0x08 /* Private */,
       7,    1,   52,    2, 0x08 /* Private */,
       9,    1,   55,    2, 0x08 /* Private */,
      11,    1,   58,    2, 0x08 /* Private */,
      13,    1,   61,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,    3,    4,

 // slots: parameters
    QMetaType::Void, QMetaType::QString,    6,
    QMetaType::Void, QMetaType::Int,    8,
    QMetaType::Void, QMetaType::ULongLong,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::Int,   14,

       0        // eod
};

void SettingTimeScaleFactor::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SettingTimeScaleFactor *_t = static_cast<SettingTimeScaleFactor *>(_o);
        switch (_id) {
        case 0: _t->_errorFrequencyToLow((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 1: _t->on_comboBoxPeriod_currentTextChanged((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 2: _t->on_comboBoxPeriod_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->_nbFrameSavedWasChanged((*reinterpret_cast< quint64(*)>(_a[1]))); break;
        case 4: _t->_sizeFrameWasChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 5: _t->_FTDIBaudrateWasChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SettingTimeScaleFactor::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTimeScaleFactor::_errorFrequencyToLow)) {
                *result = 0;
            }
        }
    }
}

const QMetaObject SettingTimeScaleFactor::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_SettingTimeScaleFactor.data,
      qt_meta_data_SettingTimeScaleFactor,  qt_static_metacall, 0, 0}
};


const QMetaObject *SettingTimeScaleFactor::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SettingTimeScaleFactor::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SettingTimeScaleFactor.stringdata))
        return static_cast<void*>(const_cast< SettingTimeScaleFactor*>(this));
    return QFrame::qt_metacast(_clname);
}

int SettingTimeScaleFactor::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 6)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 6;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 6)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 6;
    }
    return _id;
}

// SIGNAL 0
void SettingTimeScaleFactor::_errorFrequencyToLow(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_END_MOC_NAMESPACE
