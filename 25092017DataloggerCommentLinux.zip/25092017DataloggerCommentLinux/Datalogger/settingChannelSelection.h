#ifndef SETTINGCHANNELSELECTION_H
#define SETTINGCHANNELSELECTION_H


/**
  * \file settingChannelSelection.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Frame in setting menu for the channels selection
  */

#include <QDebug>
#include <QFrame>
#include <QPushButton>
#include "commonStyle.h"
#include "globalEnumatedAndExtern.h"

namespace Ui {
class SettingChannelSelection;
}

class SettingChannelSelection : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn  explicit SettingChannelSelection(QWidget *parent = 0)
      * \brief constructor for SettingChannelSelection
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit SettingChannelSelection(QWidget *parent = 0);

    /**
      * \fn  ~SettingChannelSelection()
      * \brief destructor for SettingChannelSelection
      */
    ~SettingChannelSelection();

    //check if there is minimum one selected trace
    /**
      * \fn void checkIfAreSelectedTrace();
      * \brief check if there is minimum one selected trace
      * \return void : nothing
      */
    void checkIfAreSelectedTrace();

private:
    Ui::SettingChannelSelection *ui;

    //quantity of selected trace
    quint8 _sumOfSelectedTrace;

    //quantity of trigger selected trace
    quint8 _sumOfTriggerSelectedTrace;

    //set the color and shape of this windows
    /**
      * \fn  void setupStyle()
      * \brief use to set the style of this object
      * \return void : nothing
      */
    void _setupStyle();

    //set the background color of all push button on UI

    /**
      * \fn  void _setupUILayout()
      * \brief use to set the complet layout of the UI widget
      * \return void : nothing
      */
    void _setupUILayout();

    //set the label of all push button on UI

    /**
      * \fn  void _setupLabel();
      * \brief use to set the label text
      * \return void : nothing
      */
    void _setupLabel();

    //setup background color of the push button
    /**
      * \fn void _setupButtonBackGround(QPushButton *pushbutton,
      *           GlobalEnumatedAndExtern::eTracePossible trace , bool btSelected);
      * \brief use to set the backbroude color according with the selection status
      * \param[in] pushbutton is the buton to set.
      * \param[in] trace is the type of trace.
      * \param[in] btSelected is to know if they are selected or not
      * In case of analoge plot, the selected color is blue
      * In case of digital plot, the selected color is green
      * If not selected the color is grey
      * \return void : nothing
      */
    void _setupButtonBackGround(QPushButton *pushbutton, GlobalEnumatedAndExtern::eTracePossible trace , bool btSelected);

    //key value for pushbutton name
    QMap<int, QString> _triggerTracePossible;

    //generic emit signal for all button
    void emitBtSignal(int buttonNumber, bool btSelected);



private slots:
    void on_btDI1_released();
    void on_btDI2_released();
    void on_btDI3_released();
    void on_btDI4_released();
    void on_btDI5_released();
    void on_btDI6_released();
    void on_btDI7_released();
    void on_btDI8_released();
    void on_btDI9_released();
    void on_btDI10_released();
    void on_btDI11_released();
    void on_btDI12_released();
    void on_btDI13_released();
    void on_btDI14_released();
    void on_btDI15_released();
    void on_btDI16_released();
    void on_btAI1_released();
    void on_btAI2_released();
    void on_btAI3_released();
    void on_btAI4_released();

signals:

    //button pushed
    void _btSeleccted(quint8 buttonNumber, bool btSelected);

    //add button in all trigger function combobox
    void _btAddList(quint8 buttonNummer);

    //remove button in all trigger function combobox
    void _btRemoveList(quint8 buttonNummer);

    //add trace in trigger setting
    void _addTrace(quint8 enumTrace);

    //remove trace in trigger setting
    void _removeTrace(quint8 enumTrace);

    //error no selected trace
    void _errorNoSelectedTrace(quint8 errorNumber, bool noSelecetTrace);

    //error no selected trigger trace
    void _errorNoSelectedTriggerTrace(quint8 errorNumber, bool noSelectedTriggerTrace);
};

#endif // SETTINGCHANNELSELECTION_H
