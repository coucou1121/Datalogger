#ifndef ANALOGPLOT_H
#define ANALOGPLOT_H

//*

/**
  * \file analogPlot.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief Management of the analogue trace display
  */

#include <QWidget>
#include <QTimer>
#include "qcustomplot.h"
#include "commonStyle.h"

//gap of 0.2 beetween trace add display frame
/**
  * \def AI_Y_AXIS_MIN_VALUE
  * \brief preprocessor symbole for AI_Y_AXIS_MIN_VALUE
  *
  * This symbole is the minimum value for y axis
  */
#define AI_Y_AXIS_MIN_VALUE -0.2

/**
  * \def AI_Y_AXIS_MAX_VALUE
  * \brief preprocessor symbole for AI_Y_AXIS_MAX_VALUE
  *
  * This symbole is the maximum value for y axis of the analog trace
  */
#define AI_Y_AXIS_MAX_VALUE 255.2

//gap of 0.2 beetween trigger trace add display frame
/**
  * \def AI_TRIGGER_Y_AXIS_MIN_VALUE
  * \brief preprocessor symbole for AI_TRIGGER_Y_AXIS_MIN_VALUE
  *
  * This symbole is the minimum value for y axis of the trigger trace
  */
#define AI_TRIGGER_Y_AXIS_MIN_VALUE -0.2

/**
  * \def AI_TRIGGER_Y_AXIS_MAX_VALUE
  * \brief preprocessor symbole for AI_TRIGGER_Y_AXIS_MAX_VALUE
  *
  * This symbole is the maximum value for y axis of the trigger trace
  */
#define AI_TRIGGER_Y_AXIS_MAX_VALUE 1.2

namespace Ui {
class AnalogPlot;
}

class AnalogPlot : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn  explicit AnalogPlot(QWidget *parent = 0)
      * \brief constructor for AnalogPlot
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit AnalogPlot(QWidget *parent = 0);

    /**
      * \fn  ~AnalogPlot()
      * \brief destructor for AnalogPlot
      */
    ~AnalogPlot();

    /**
      * \fn quint64 CPT() const
      * \brief Getter for CPT attribute
      * \return CPT : quint64
      */
    quint64 CPT() const;

    /**
      * \fn void setCPT(const quint64 &CPT)
      * \brief Setter for setSettingTriggerValue attribute
      * \param[in] CPT is the counter value for the plot, use for the x value
      * \return void : nothing
      */
    void setCPT(const quint64 &CPT);

    /**
      * \fn quint8 yValue() const
      * \brief Getter for yValue attribute
      * \return yValue : quint64
      */
    quint8 yValue() const;

    /**
      * \fn void setYValue(quint8 yValue)
      * \brief Setter for setYValue attribute
      * \param[in] yValue is the y value for the plot
      * \return void : nothing
      */
    void setYValue(quint8 yValue);

    /**
      * \fn void setTitleName(QString name)
      * \brief Use to set the title name of the plot
      * \param[in] name is the name of plot in string
      * \return void : nothing
      */
    void setTitleName(QString name);

    /**
      * \fn void setRangeName(QString name)
      * \brief Use to set the range name of the plot
      * \param[in] name is the name of plot range in string
      * \return void : nothing
      */
    void setRangeName(QString name);

    /**
      * \fn void setDrawRightToLeft(bool drawRightToLeft)
      * \brief Use to set the direction of the plotting
      * \param[in] drawRightToLeft if is true , the direction is right to left "Roll on", false is reversed "Trig"
      * \return void : nothing
      */
    void setDrawRightToLeft(bool drawRightToLeft);

    /**
      * \fn void replot();
      * \brief Use to refresh the plot
      * \return void : nothing
      */
    void replot();

    /**
      * \fn void setNbPixels(const quint16 &nbPixels)
      * \brief Setter for setNbPixels attribute
      * \param[in] nbPixels is the wideness of the plot
      * \return void : nothing
      */
    void setNbPixels(const quint16 &nbPixels);

    /**
      * \fn setSettingTriggerValue(const quint8 &settingTriggerValue)
      * \brief Setter for setSettingTriggerValue attribute
      * \param[in] nbPixels is the wideness of the plot
      * \return void : nothing
      */
    void setSettingTriggerValue(const quint8 &settingTriggerValue);

    /**
      * \fn void updatePlot()
      * \brief Use to update the value in the plot
      * \return void : nothing
      */
    void updatePlot();

    /**
      * \fn void addYValue(quint8 valueGraph1, quint8 settingTriggerValue)
      * \brief Use to add the value in dedicated buffer
      * \param[in] valueGraph1 is the value of the 1st trace
      * \param[in] settingTriggerValue is the value of the 2st trace
      * \return void : nothing
      */
    void addYValue(quint8 valueGraph1, quint8 settingTriggerValue);

private:
    Ui::AnalogPlot *ui;

    QCustomPlot *_plot;

    QCPGraph *_graph1;

    QCPItemStraightLine *_line;

    quint16 _nbPixels;
    quint64 _CPT;
    quint64 _CPTMin;
    quint64 _CPTMax;
    quint8 _yValue;
    quint8 _settingTriggerValue;

    QColor _traceSettingColor;

    // Data buffers
    QVector<double> _YData;
    QVector<double> _minusYData;
    QVector<double> _XData;

    //set plot style
    /**
      * \fn void setupStyle(QCustomPlot *customPlot)
      * \brief setup the plot style
      * \param[in] customPlot is the widget to setup
      * \return void : nothing
      */
    void setupStyle(QCustomPlot *customPlot);

    //set curve style
    /**
      * \fn void setupTrace(QCPGraph *graph);
      * \brief setup the trace style in the graph
      * \param[in] graph is the widget to setup
      * \return void : nothing
      */
    void setupTrace(QCPGraph *graph);

    //plot array pointer
    QSharedPointer<QCPGraphDataContainer> _arrayPlotContainerPointer;
};

#endif // ANALOGPLOT_H
