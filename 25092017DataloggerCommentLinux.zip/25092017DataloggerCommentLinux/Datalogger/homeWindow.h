#ifndef HomeWindow_H
#define HomeWindow_H

//*

/**
  * \file homeWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Startup page when the application has finished the initialisation
  */

#include <QWidget>

namespace Ui {
class HomeWindow;
}

class HomeWindow : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn  explicit HomeWindow(QWidget *parent = 0)
      * \brief constructor for HomeWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit HomeWindow(QWidget *parent = 0);

    /**
      * \fn  ~HomeWindow()
      * \brief destructor for HomeWindow
      */
    ~HomeWindow();

    /**
      * \fn void setTitle(const QString &title)
      * \brief Use to set the name displaying on the home page
      * \param[in] name is the name of the device
      * \return void : nothing
      */
    void setTitle(const QString &title);

    /**
      * \fn void setVersion(const QString &version)
      * \brief Use to set the version displaying on the home page
      * \param[in] version is the version number of the device
      * \return void : nothing
      */
    void setVersion(const QString &version);

private:
    Ui::HomeWindow *ui;

    //title
    QString _title;

    //Version
    QString _version;
};

#endif // HomeWindow_H
