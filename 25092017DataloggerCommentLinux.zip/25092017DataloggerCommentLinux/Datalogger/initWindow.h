#ifndef INITWINDOW_H
#define INITWINDOW_H

//*

/**
  * \file initWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Start up window to display the connection status of FTDI device
  */

#include <QFrame>

namespace Ui {
class InitWindow;
}

class InitWindow : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn  explicit InitWindow(QWidget *parent = 0)
      * \brief constructor for InitWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit InitWindow(QWidget *parent = 0);

    /**
      * \fn  ~InitWindow()
      * \brief destructor for InitWindow
      */
    ~InitWindow();

    /**
      * \fn void clearTextLabel()
      * \brief clear all display text
      * \return void : nothing
      */
    void clearTextLabel();

    /**
      * \fn void addTextInLabel(QString text);
      * \brief Add texte in dedicated window frame
      * \param[in] text is the text to add
      * \return void : nothing
      */
    void addTextInLabel(QString text);

private:
    Ui::InitWindow *ui;
};

#endif // INITWINDOW_H
