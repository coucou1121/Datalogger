#include "pushbuttonWatchingThread.h"

PushButtonWatchingThread::PushButtonWatchingThread(bool isWorking, QString name, quint8 pinInButton, quint16 delay):
    _isWorking(isWorking),
    _delay(delay),
    _pinButton(pinInButton)
{
    this->setObjectName(name);
    pinMode(pinInButton, INPUT);

    //set libraries for GPIO
    wiringPiSetup();
    moveToThread(this);
}

void PushButtonWatchingThread::usleep(unsigned long usecs)
{
    //   qDebug() << "coucou";
    QThread::usleep(usecs);
}

void PushButtonWatchingThread::msleep(unsigned long msecs)
{
    QThread::msleep(msecs);
}

void PushButtonWatchingThread::sleep(unsigned long secs)
{
    QThread::sleep(secs);
}

void PushButtonWatchingThread::startWorking()
{
    qDebug() << objectName() << "received start Working";
    this->_isWorking = true;
}

void PushButtonWatchingThread::stopWorking()
{
    qDebug() << objectName() << "received stop Working";
    this->_isWorking = false;
}

// run() will be called when a thread starts
void PushButtonWatchingThread::run()
{
    unsigned long int cpt=0;
    bool etatPushButton = digitalRead(this->_pinButton);

    while(true)
    {
        etatPushButton = digitalRead(this->_pinButton);
        if(_isWorking)
        {
            cpt++;
            //    _frame.displayValue();
            if(!etatPushButton)
            {
                emit pushButtonWasPressed();
                this->msleep(_delay);
            }
        }

    }

}
