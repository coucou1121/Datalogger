#ifndef DATAFRAME_H
#define DATAFRAME_H

//*

/**
  * \file dataFrame.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief Structure of the data
  */

#include <QDebug>

class DataFrame
{
public:
    /**
      * \fn DataFrame();
      * \brief constructor for DataFrame
      */
    DataFrame();

    /**
      * \fn quint8 msbCPT() const
      * \brief Getter for msbCPT attribute
      * \return msbCPT : quint8
      */
    quint8 msbCPT() const;

    /**
      * \fn  void setMsbCPT(const quint8 &msbCPT)
      * \brief Setter for msbCPT attribute
      * \param[in] msbCPT is highest byte counter .
      * \return void : nothing
      */
    void setMsbCPT(const quint8 &msbCPT);

    /**
      * \fn quint8 lsbCPT() const
      * \brief Getter for lsbCPT attribute
      * \return lsbCPT : quint8
      */
    quint8 lsbCPT() const;

    /**
      * \fn  void setLsbCPT(const quint8 &lsbCPT)
      * \brief Setter for lsbCPT attribute
      * \param[in] lsbCPT is lowest byte counter .
      * \return void : nothing
      */
    void setLsbCPT(const quint8 &lsbCPT);

    /**
      * \fn quint8 DI1_8() const
      * \brief Getter for DI1_8 attribute
      * \return DI1_8 : quint8
      */
    quint8 DI1_8() const;

    /**
      * \fn  void setDI1_8(const quint8 &DI1_8)
      * \brief Setter for DI1_8 attribute
      * \param[in] DI1_8 is the byte for digital trace 1 to 8
      * \return void : nothing
      */
    void setDI1_8(const quint8 &DI1_8);

    /**
      * \fn quint8 DI9_16() const
      * \brief Getter for DI9_16 attribute
      * \return DI9_16 : quint8
      */
    quint8 DI9_16() const;

    /**
      * \fn  void setDI9_16(const quint8 &DI9_16)
      * \brief Setter for DI9_16 attribute
      * \param[in] DI9_16 is the byte for digital trace 9 to 16
      * \return void : nothing
      */
    void setDI9_16(const quint8 &DI9_16);

    /**
      * \fn quint8 AI1() const
      * \brief Getter for AI1 attribute
      * \return AI1 : quint8
      */
    quint8 AI1() const;

    /**
      * \fn  void setAI1(const quint8 &AI1)
      * \brief Setter for AI1 attribute
      * \param[in] AI1 is the byte for analog trace AI1
      * \return void : nothing
      */
    void setAI1(const quint8 &AI1);

    /**
      * \fn quint8 AI2() const
      * \brief Getter for AI2 attribute
      * \return AI2 : quint8
      */
    quint8 AI2() const;

    /**
      * \fn  void AI2(const quint8 &AI2)
      * \brief Setter for AI2 attribute
      * \param[in] AI2 is the byte for analog trace AI2
      * \return void : nothing
      */
    void setAI2(const quint8 &AI2);

    /**
      * \fn quint8 AI3() const
      * \brief Getter for AI3 attribute
      * \return AI3 : quint8
      */
    quint8 AI3() const;

    /**
      * \fn  void AI3(const quint8 &AI3)
      * \brief Setter for AI3 attribute
      * \param[in] AI3 is the byte for analog trace AI3
      * \return void : nothing
      */
    void setAI3(const quint8 &AI3);

    /**
      * \fn quint8 AI4() const
      * \brief Getter for AI4 attribute
      * \return AI4 : quint8
      */
    quint8 AI4() const;

    /**
      * \fn  void AI4(const quint8 &AI4)
      * \brief Setter for AI4 attribute
      * \param[in] AI4 is the byte for analog trace AI4
      * \return void : nothing
      */
    void setAI4(const quint8 &AI4);

    /**
      * \fn quint8 TR1() const
      * \brief Getter for TR1 attribute
      * \return TR1 : quint8
      */
    quint8 TR1() const;

    /**
      * \fn  void TR1(const quint8 &TR1)
      * \brief Setter for TR1 attribute
      * \param[in] TR1 is the byte for digital trace TR1
      * \return void : nothing
      */
    void setTR1(const quint8 &TR1);

    /**
      * \fn  void displayValue()
      * \brief display the value for debug
      * \return void : nothing
      */
    void displayValue();

    /**
      * \fn quint8 TR_AI1() const
      * \brief Getter for TR_AI1 attribute
      * \return TR_AI1 : quint8
      */
    quint8 TR_AI1() const;

    /**
      * \fn  void setTR_AI1(const quint8 &TR_AI1)
      * \brief Setter for TR_AI1 attribute
      * \param[in] TR_AI1 is the byte for digital trace TR_AI1
      * \return void : nothing
      */
    void setTR_AI1(const quint8 &TR_AI1);

    /**
      * \fn quint8 TR_AI2() const
      * \brief Getter for TR_AI2 attribute
      * \return TR_AI2 : quint8
      */
    quint8 TR_AI2() const;

    /**
      * \fn  void setTR_AI2(const quint8 &TR_AI2)
      * \brief Setter for TR_AI2 attribute
      * \param[in] TR_AI2 is the byte for digital trace TR_AI2
      * \return void : nothing
      */
    void setTR_AI2(const quint8 &TR_AI2);

private:

    //frame structure
    quint8 _msbCPT;
    quint8 _lsbCPT;
    quint8 _DI1_8;
    quint8 _DI9_16;
    quint8 _AI1;
    quint8 _AI2;
    quint8 _AI3;
    quint8 _AI4;
    quint8 _TR1;
    quint8 _TR_AI1;
    quint8 _TR_AI2;
};

#endif // DATAFRAME_H
