#ifndef DATAFRAMELIVEREADING_H
#define DATAFRAMELIVEREADING_H

//*

/**
  * \file dataFrameLiveReading.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief thread to create the tick to read the data from FTDI
  */

#include <QThread>
#include <QObject>
#include <QDebug>
#include <QTime>
#include "FTDIFunction.h"
#include "globalEnumatedAndExtern.h"

class DataFrameLiveReading : public QThread
{
    Q_OBJECT

public:
    /**
      * \fn explicit DataFrameLiveReading(QString name, quint32 nbFrameReadEveryCycle, quint16 delay, QObject *parent = 0)
      * \brief constructor for DataFrameLiveReading
      * \param[in] name is the name of the object
      * \param[in] nbFrameReadEveryCycle is the amont of reading data every cycle
      * \param[in] delay is the cycle time delay in miliseconds
      */
    explicit DataFrameLiveReading(QString name, quint32 nbFrameReadEveryCycle, quint16 delay);

    /**
      * \fn  static void msleep(unsigned long msecs)
      * \brief waiting delay
      * \param[in] msleep is the time in miliseconds
      * \return void : nothing
      */
    static void msleep(unsigned long msecs);

    /**
      * \fn  setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder)
      * \brief circilar buffer for data storage
      * \param[in] dataFrameVectorReccorder is the array for data storage fixe to 65536 values
      * \return void : nothing
      */
    void setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder);

    /**
      * \fn  setItProducer(const QVector<DataFrame>::iterator &itProducer)
      * \brief iterator for the circular buffer
      * \param[in] itProducer is the iterator on array for the saving data position
      * \return void : nothing
      */
    void setItProducer(const QVector<DataFrame>::iterator &itProducer);

    /**
      * \fn  setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress)
      * \brief iterator for the circular buffer, use to stop the entry of data from this thread
      * \param[in] itConsumerAdress is the iterator adresse for of the reading data position
      * \return void : nothing
      */
    void setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress);

    //start real time reading
    /**
      * \fn  startReading()
      * \brief start reading operation
      * \return void : nothing
     */
    void startReading();


    /**
      * \fn  setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress)
      * \brief stop reading operation
      * \return void : nothing
      */
    void stopReading();

    /**
      * \fn  FTDIFunction *FTDIdevice() const
      * \brief Getter of the FTDIdevice
      * \return FTDIdevice : FTDIFunction
      */
    FTDIFunction *FTDIdevice() const;

    /**
      * \fn void setFTDIdevice(FTDIFunction *FTDIdevice)
      * \brief Getter for FTDIdevice attribute
      * \return void : nothing
      */
    void setFTDIdevice(FTDIFunction *FTDIdevice);

protected:

    /**
      * \fn void run()
      * \brief called function when the thread start
      * \return void : nothing
      */
    void run();

private:

    quint16 _delay;
    bool _askForStartReading;
    bool _askForStopReading;



    //FTDI connection and functions
    FTDIFunction *_FTDIdevice;

    quint32 _baudRateSpeed2M;
    quint16 _baudRateSpeed9600;

    //actif wait delay
    void _waitDelay(int delayInSeconde);

    //circular buffer
    QVector<DataFrame> *_dataFrameVectorReccorder;
    QVector<DataFrame>::iterator _itProducer;
    QVector<DataFrame>::iterator _itConsumerAdress;

    //number of frame reading every cycle
    quint32 _nbFrameReadEveryCycle;

    //temporary buffer for new Datas
    QVector<DataFrame> _dataFrameTraceBuffer;
    QVector<DataFrame>::iterator _itdataFrameTrace;

public slots:

signals:
    void dataFrameWasSent(int itProducerAdress);
};

#endif // DATAFRAMELIVEREADING_H
