#ifndef COMMONSTYLE_H
#define COMMONSTYLE_H

//*

/**
  * \file commonStyle.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief All colors are set hier for the application
  */

#include <QColor>
#include <QPushButton>
#include <QLabel>
#include <QDoubleSpinBox>
#include <QSpinBox>
#include "qcustomplot.h"

//main windows
//size
/**
  * \def MINIMUM_WIDTH_SIZE
  * \brief preprocessor symbol for MINIMUM_WIDTH_SIZE
  *
  * This symbol is the minimum width
  */
#define MINIMUM_WIDTH_SIZE 1280

/**
  * \def MINIMUM_HEIGHT_SIZE
  * \brief preprocessor symbol for MINIMUM_HEIGHT_SIZE
  *
  * This symbol is the minimum heigh
  */
#define MINIMUM_HEIGHT_SIZE 720

//color RGB  R, G, B  alpha = 255
/**
  * \def BACKGROUD_COLOR
  * \brief preprocessor symbol for BACKGROUD_COLOR
  *
  * This symbol is the main background color
  */
#define BACKGROUD_COLOR 200,200,200                                //soft light Gray

/**
  * \def BACKGROUD_COLOR_PUSHBUTTON_LIGHT
  * \brief preprocessor symbol for BACKGROUD_COLOR_PUSHBUTTON_LIGHT
  *
  * This symbol is the light gray background color for the push button
  */
#define BACKGROUD_COLOR_PUSHBUTTON_LIGHT 220,220,220               //light Gray

/**
  * \def BACKGROUD_COLOR_PUSHBUTTON_DARK
  * \brief preprocessor symbol for BACKGROUD_COLOR_PUSHBUTTON_DARK
  *
  * This symbol is the dark gray background color for the push button
  */
#define BACKGROUD_COLOR_PUSHBUTTON_DARK 90,90,90                   //drak Grey

/**
  * \def BACKGROUD_COLOR_LABEL
  * \brief preprocessor symbol for BACKGROUD_COLOR_LABEL
  *
  * This symbol is the gray background color for  of the label
  */
#define BACKGROUD_COLOR_LABEL 125,125,125                          //Gray


/**
  * \def BACKGROUD_COLOR_PUSHBUTTON_DARK
  * \brief preprocessor symbol for BACKGROUD_COLOR_PUSHBUTTON_DARK
  *
  * This symbol is the gray background color for the frame
  */
#define BACKGROUD_COLOR_FRAME 119,119,119                          //Gray

/**
  * \def BACKGROUD_COLOR_ERROR_FRAME
  * \brief preprocessor symbol for BACKGROUD_COLOR_ERROR_FRAME
  *
  * This symbol is the soft red background color for the error frame
  */
#define BACKGROUD_COLOR_ERROR_FRAME 255,160,160                    //soft Red

//ERROR
/**
  * \def ERROR_LINE_COLOR_IN_TROUBLE
  * \brief preprocessor symbol for ERROR_LINE_COLOR_IN_TROUBLE
  *
  * This symbol is the red color o the line for the error message
  */
#define ERROR_LINE_COLOR_IN_TROUBLE 255, 0, 0                     //RGB, R=255,   G=0,  B=0   aplha = 255

//PLOT
//analog plot size
/**
  * \def ANALOG_PLOT_MINIMUM_WIDTH_SIZE
  * \brief preprocessor symbol for ANALOG_PLOT_MINIMUM_WIDTH_SIZE
  *
  * This symbol is the minimum width for analog plot
  */
#define ANALOG_PLOT_MINIMUM_WIDTH_SIZE 960

/**
  * \def ANALOG_PLOT_MINIMUM_HEIGHT_SIZE
  * \brief preprocessor symbol for ANALOG_PLOT_MINIMUM_HEIGHT_SIZE
  *
  * This symbol is the minimum heigh for analog plot
  */
#define ANALOG_PLOT_MINIMUM_HEIGHT_SIZE 22

//digital plot size
/**
  * \def DIGITAL_PLOT_MINIMUM_WIDTH_SIZE
  * \brief preprocessor symbol for DIGITAL_PLOT_MINIMUM_WIDTH_SIZE
  *
  * This symbol is the minimum width for digital plot
  */
#define DIGITAL_PLOT_MINIMUM_WIDTH_SIZE 960

/**
  * \def DIGITAL_PLOT_MINIMUM_HEIGHT_SIZE
  * \brief preprocessor symbol for DIGITAL_PLOT_MINIMUM_HEIGHT_SIZE
  *
  * This symbol is the minimum heigh for digital plot
  */
#define DIGITAL_PLOT_MINIMUM_HEIGHT_SIZE 22

//color
/**
  * \def BACKGROUD_COLOR_PLOT
  * \brief preprocessor symbol for BACKGROUD_COLOR_PLOT
  *
  * This symbol is the dark grey background color for the plot
  */
#define BACKGROUD_COLOR_PLOT         25,25,25                //Dark Gray close to black

/**
  * \def GRID_COLOR_PLOT
  * \brief preprocessor symbol for GRID_COLOR_PLOT
  *
  * This symbol is the grey color for the grid of the plot
  */
#define GRID_COLOR_PLOT             255, 255, 0, 100        //RGB, R=140,   G=140,  B=140   aplha = 100

/**
  * \def AXIS_COLOR_PLOT
  * \brief preprocessor symbol for AXIS_COLOR_PLOT
  *
  * This symbol is the grey color for the axis of the plot
  */
#define AXIS_COLOR_PLOT             250, 250, 250           //RGB, R=140,   G=140,  B=140   aplha = 255

/**
  * \def AXE_GRID_COLOR_PLOT
  * \brief preprocessor symbol for AXE_GRID_COLOR_PLOT
  *
  * This symbol is the grey color for the axis grid of the plot
  */
#define AXE_GRID_COLOR_PLOT         255, 255, 0             //RGB, R=140,   G=140,  B=140   aplha = 255

//pen
/**
  * \def ANALOG_PLOT_TRACE
  * \brief preprocessor symbol for ANALOG_PLOT_TRACE
  *
  * This symbol is the blue color for the analog trace
  */
#define ANALOG_PLOT_TRACE                   0, 153, 255     //Blue

/**
  * \def DIGITAL_PLOT_TRACE
  * \brief preprocessor symbol for DIGITAL_PLOT_TRACE
  *
  * This symbol is the green color for the digital trace
  */
#define DIGITAL_PLOT_TRACE                   51, 204, 51    //green

/**
  * \def DIGITAL_PLOT_TRACE_ON
  * \brief preprocessor symbol for DIGITAL_PLOT_TRACE_ON
  *
  * This symbol is the soft green color for the digital trace label
  */
#define DIGITAL_PLOT_TRACE_ON  155, 220, 155             //soft green

/**
  * \def DIGITAL_PLOT_TRACE_ON
  * \brief preprocessor symbol for DIGITAL_PLOT_TRACE_ON
  *
  * This symbol is the soft red color for the trigger trace label
  */
#define DIGITAL_RED_PLOT_TRACE_ON 200, 155, 155         //soft red

class CommonStyle
{
public:
    //BACKGROUND
    /**
      * \fn static void setBackGroundColor(QCustomPlot *customPlot)
      * \brief Set the background color of customplot attribute
      * \param[in] customPlot is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColor(QCustomPlot *customPlot);


    /**
      * \fn static void setBackGroundColor(QLabel *label)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColor(QLabel *label);

    /**
      * \fn static void setBackGroundColor(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColor(QPushButton *pushButton);

    /**
      * \fn static void setbackGroundColorLabel(QLabel *label)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorLabel(QLabel *label);

    /**
      * \fn static void setbackGroundColorLabel(QPushButton *pushButton)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorLabel(QPushButton *pushButton);

    /**
      * \fn static void setbackGroundColorLabelUnselected(QLabel *label)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorLabelUnselected(QLabel *label);

    /**
      * \fn static void setbackGroundColorLabelUnselected(QPushButton *pushButton);
      * \brief Set the background color of pushButton attribute
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorLabelUnselected(QPushButton *pushButton);

    /**
      * \fn static void setbackGroundColorLabelPlot(QLabel *label)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorLabelPlot(QLabel *label);

    /**
      * \fn static void setbackGroundColorLabelPlotSmall(QLabel *label)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorLabelPlotSmall(QLabel *label);

    /**
      * \fn static void setbackGroundColorFrame(QFrame *frame);
      * \brief Set the background color of frame attribute
      * \param[in] frame is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorFrame(QFrame *frame);

    /**
      * \fn static void setbackGroundColorFrame(QWidget *widget);
      * \brief Set the background color of widget attribute
      * \param[in] widget is the objet which the background color will be set
      * \return void : nothing
      */
    static void setbackGroundColorFrame(QWidget *widget);

    /**
      * \fn static void setBackGroundColorPlot(QCPAxisRect *qcpAxisRect);
      * \brief Set the background color of qcpAxisRect attribute
      * \param[in] qcpAxisRect is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColorPlot(QCPAxisRect *qcpAxisRect);

    /**
      * \fn static void setBackGroundColorDILabel(QLabel *label);
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColorDILabel(QLabel *label);

    /**
      * \fn static void setBackGroundColorRedDILabel(QLabel *label)
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColorRedDILabel(QLabel *label);

    /**
      * \fn static void setBackGroundColorAISelected(QPushButton *pushButton);
      * \brief Set the background color of pushButton attribute
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColorAISelected(QPushButton *pushButton);

    /**
      * \fn static void setBackGroundColorDISelected(QPushButton *pushButton);
      * \brief Set the background color of pushButton attribute
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setBackGroundColorDISelected(QPushButton *pushButton);

    //ERROR
    /**
      * \fn static void setErrorColor(QLabel *label);
      * \brief Set the background color of label attribute
      * \param[in] label is the objet which the background color will be set
      * \return void : nothing
      */
    static void setErrorColor(QLabel *label);

    /**
      * \fn static void setErrorColor(QFrame *frame)
      * \brief Set the background color of frame attribute
      * \param[in] frame is the objet which the background color will be set
      * \return void : nothing
      */
    static void setErrorColor(QFrame *frame);

    //PLOT
    /**
      * \fn static void setStylePlot(QCustomPlot *customPlot);
      * \brief Set the style of the customPlot attribute
      * \param[in] customPlot is the objet which the style will be set
      * \return void : nothing
      */
    static void setStylePlot(QCustomPlot *customPlot);

    //pen
    //analog trace
    /**
      * \fn static void setTraceColorAnalogPlot(QCPGraph *graph);
      * \brief Set the trace color of the graph attribute, used for the analog trace
      * \param[in] graph is the objet which the trace color will be set
      * \return void : nothing
      */
    static void setTraceColorAnalogPlot(QCPGraph *graph);

    //digital trace
    /**
      * \fn static void setTraceColorDigitalPlot(QCPGraph *graph);
      * \brief Set the trace color of the graph attribute, used for the digital trace
      * \param[in] graph is the objet which the trace color will be set
      * \return void : nothing
      */
    static void setTraceColorDigitalPlot(QCPGraph *graph);

    //trigger trace
    /**
      * \fn static void setTraceColorTriggerPlot(QCPGraph *graph)
      * \brief Set the trace color of the graph attribute, used for the trigger trace
      * \param[in] graph is the objet which the trace color will be set
      * \return void : nothing
      */
    static void setTraceColorTriggerPlot(QCPGraph *graph);

    /**
      * \fn static void setTraceColorTriggerPlot(QCPItemStraightLine *line)
      * \brief Set the trace color of the line attribute, used for the trigger line
      * \param[in] line is the objet which the color will be set
      * \return void : nothing
      */
    static void setTraceColorTriggerPlot(QCPItemStraightLine *line);

    //pushbutton unselect Shape
    /**
      * \fn static void setPushButtonUnselected(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute, use when the pushButton is unselected
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setPushButtonUnselected(QPushButton *pushButton);

    /**
      * \fn static void setPushButtonBlocked(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute, use when the pushButton is blocked
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setPushButtonBlocked(QPushButton *pushButton);

    //doublspinbox Shape
    /**
      * \fn static void setSpinBoxShape(QSpinBox *spinBox)
      * \brief Set the style of spinBox attribute
      * \param[in] spinBox is the objet which the style will be set
      * \return void : nothing
      */
    static void setSpinBoxShape(QSpinBox *spinBox);
    /**
      * \fn static void setDoublespinBoxShape(QDoubleSpinBox *doubleSpinBox);
      * \brief Set the style of doubleSpinBox attribute
      * \param[in] doubleSpinBox is the objet which the style will be set
      * \return void : nothing
      */
    static void setDoublespinBoxShape(QDoubleSpinBox *doubleSpinBox);

    //main button start
    /**
      * \fn static void setStartButtonToGreen(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute, use for the main pushButton
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setStartButtonToGreen(QPushButton *pushButton);

    /**
      * \fn static void setStartButtonToRed(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute, use for the main pushButton
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setStartButtonToRed(QPushButton *pushButton);

    //button on status barre
    /**
      * \fn static void setButtonStatusBarSelect(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute, use for the tap on status bar when selected
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setButtonStatusBarSelect(QPushButton *pushButton);

    /**
      * \fn static void setButtonStatusBarUnselect(QPushButton *pushButton)
      * \brief Set the background color of pushButton attribute, use for the tap on status bar when unselected
      * \param[in] pushButton is the objet which the background color will be set
      * \return void : nothing
      */
    static void setButtonStatusBarUnselect(QPushButton *pushButton);


    //main backrgound color
    static QColor _backGroundColor;

private:
    static QColor _backGroundColorLabel;
    static QColor _backGroundColorFrame;
    static QColor _backGroundColorPlot;
    static QColor _backGroundColorPushButtonLight;
    static QColor _backGroundColorPushButtonDark;

    //ERROR
    static QColor _backGroundColorErrorFrame;
    static QColor _errorLineInTrouble;

    //PLOT
    //Grid
    static QColor _gridColorPlot;

    //Axis
    static QColor _axisColorPlot;
    static QColor _axisTickPlot;

    //pen
    //analoge trace
    static QColor _traceColorAnalogPlot;

    //digital trace
    static QColor _traceColorDigitalPlot;
    static QColor _backGroundLabelDIPlotON;
    static QColor _backGroundLabelRedDIPlotON;
};

#endif // COMMONSTYLE_H
