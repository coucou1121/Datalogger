/********************************************************************************
** Form generated from reading UI file 'gpioManager.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_GPIOMANAGER_H
#define UI_GPIOMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_GPIOManager
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButtonLedGreen;
    QPushButton *pushButtonLedAmber;
    QPushButton *pushButtonLedRed;

    void setupUi(QWidget *GPIOManager)
    {
        if (GPIOManager->objectName().isEmpty())
            GPIOManager->setObjectName(QStringLiteral("GPIOManager"));
        GPIOManager->resize(270, 98);
        gridLayout = new QGridLayout(GPIOManager);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        pushButtonLedGreen = new QPushButton(GPIOManager);
        pushButtonLedGreen->setObjectName(QStringLiteral("pushButtonLedGreen"));
        pushButtonLedGreen->setMinimumSize(QSize(80, 80));
        pushButtonLedGreen->setMaximumSize(QSize(80, 80));
        QIcon icon;
        icon.addFile(QStringLiteral(":/images/ledGreenOff.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButtonLedGreen->setIcon(icon);
        pushButtonLedGreen->setIconSize(QSize(75, 75));

        gridLayout->addWidget(pushButtonLedGreen, 0, 0, 1, 1);

        pushButtonLedAmber = new QPushButton(GPIOManager);
        pushButtonLedAmber->setObjectName(QStringLiteral("pushButtonLedAmber"));
        pushButtonLedAmber->setMinimumSize(QSize(80, 80));
        pushButtonLedAmber->setMaximumSize(QSize(80, 80));
        QIcon icon1;
        icon1.addFile(QStringLiteral(":/images/ledAmberOff.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButtonLedAmber->setIcon(icon1);
        pushButtonLedAmber->setIconSize(QSize(75, 75));

        gridLayout->addWidget(pushButtonLedAmber, 0, 1, 1, 1);

        pushButtonLedRed = new QPushButton(GPIOManager);
        pushButtonLedRed->setObjectName(QStringLiteral("pushButtonLedRed"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButtonLedRed->sizePolicy().hasHeightForWidth());
        pushButtonLedRed->setSizePolicy(sizePolicy);
        pushButtonLedRed->setMinimumSize(QSize(80, 80));
        pushButtonLedRed->setMaximumSize(QSize(80, 80));
        QIcon icon2;
        icon2.addFile(QStringLiteral(":/images/ledRedOff.png"), QSize(), QIcon::Normal, QIcon::Off);
        pushButtonLedRed->setIcon(icon2);
        pushButtonLedRed->setIconSize(QSize(75, 75));

        gridLayout->addWidget(pushButtonLedRed, 0, 2, 1, 1);


        retranslateUi(GPIOManager);

        QMetaObject::connectSlotsByName(GPIOManager);
    } // setupUi

    void retranslateUi(QWidget *GPIOManager)
    {
        GPIOManager->setWindowTitle(QApplication::translate("GPIOManager", "Form", 0));
        pushButtonLedGreen->setText(QString());
        pushButtonLedAmber->setText(QString());
        pushButtonLedRed->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class GPIOManager: public Ui_GPIOManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_GPIOMANAGER_H
