/****************************************************************************
** Meta object code from reading C++ file 'settingTriggerFunction.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "settingTriggerFunction.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settingTriggerFunction.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SettingTriggerFunction_t {
    QByteArrayData data[24];
    char stringdata[728];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SettingTriggerFunction_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SettingTriggerFunction_t qt_meta_stringdata_SettingTriggerFunction = {
    {
QT_MOC_LITERAL(0, 0, 22),
QT_MOC_LITERAL(1, 23, 39),
QT_MOC_LITERAL(2, 63, 0),
QT_MOC_LITERAL(3, 64, 5),
QT_MOC_LITERAL(4, 70, 40),
QT_MOC_LITERAL(5, 111, 42),
QT_MOC_LITERAL(6, 154, 43),
QT_MOC_LITERAL(7, 198, 41),
QT_MOC_LITERAL(8, 240, 38),
QT_MOC_LITERAL(9, 279, 44),
QT_MOC_LITERAL(10, 324, 19),
QT_MOC_LITERAL(11, 344, 11),
QT_MOC_LITERAL(12, 356, 6),
QT_MOC_LITERAL(13, 363, 15),
QT_MOC_LITERAL(14, 379, 12),
QT_MOC_LITERAL(15, 392, 19),
QT_MOC_LITERAL(16, 412, 38),
QT_MOC_LITERAL(17, 451, 39),
QT_MOC_LITERAL(18, 491, 41),
QT_MOC_LITERAL(19, 533, 42),
QT_MOC_LITERAL(20, 576, 40),
QT_MOC_LITERAL(21, 617, 37),
QT_MOC_LITERAL(22, 655, 43),
QT_MOC_LITERAL(23, 699, 28)
    },
    "SettingTriggerFunction\0"
    "_comboBoxTopLeft_currentIndexWasChanged\0"
    "\0index\0_comboBoxTopRight_currentIndexWasChanged\0"
    "_comboBoxBottomLeft_currentIndexWasChanged\0"
    "_comboBoxBottomRight_currentIndexWasChanged\0"
    "_comboBoxTopMiddle_currentIndexWasChanged\0"
    "_comboBoxMiddle_currentIndexWasChanged\0"
    "_comboBoxBottomMiddle_currentIndexWasChanged\0"
    "_errorWrongEquation\0errorNumber\0active\0"
    "comboboxAddItem\0buttonNumber\0"
    "comboboxRevmoveItem\0"
    "on_comboBoxTopLeft_currentIndexChanged\0"
    "on_comboBoxTopRight_currentIndexChanged\0"
    "on_comboBoxBottomLeft_currentIndexChanged\0"
    "on_comboBoxBottomRight_currentIndexChanged\0"
    "on_comboBoxTopMiddle_currentIndexChanged\0"
    "on_comboBoxMiddle_currentIndexChanged\0"
    "on_comboBoxBottomMiddle_currentIndexChanged\0"
    "_received_errorWrongEquation"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SettingTriggerFunction[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      18,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       8,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  104,    2, 0x06 /* Public */,
       4,    1,  107,    2, 0x06 /* Public */,
       5,    1,  110,    2, 0x06 /* Public */,
       6,    1,  113,    2, 0x06 /* Public */,
       7,    1,  116,    2, 0x06 /* Public */,
       8,    1,  119,    2, 0x06 /* Public */,
       9,    1,  122,    2, 0x06 /* Public */,
      10,    2,  125,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      13,    1,  130,    2, 0x0a /* Public */,
      15,    1,  133,    2, 0x0a /* Public */,
      16,    1,  136,    2, 0x08 /* Private */,
      17,    1,  139,    2, 0x08 /* Private */,
      18,    1,  142,    2, 0x08 /* Private */,
      19,    1,  145,    2, 0x08 /* Private */,
      20,    1,  148,    2, 0x08 /* Private */,
      21,    1,  151,    2, 0x08 /* Private */,
      22,    1,  154,    2, 0x08 /* Private */,
      23,    2,  157,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   11,   12,

 // slots: parameters
    QMetaType::Void, QMetaType::UChar,   14,
    QMetaType::Void, QMetaType::UChar,   14,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::Int,    3,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   11,   12,

       0        // eod
};

void SettingTriggerFunction::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SettingTriggerFunction *_t = static_cast<SettingTriggerFunction *>(_o);
        switch (_id) {
        case 0: _t->_comboBoxTopLeft_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 1: _t->_comboBoxTopRight_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 2: _t->_comboBoxBottomLeft_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 3: _t->_comboBoxBottomRight_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 4: _t->_comboBoxTopMiddle_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 5: _t->_comboBoxMiddle_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 6: _t->_comboBoxBottomMiddle_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 7: _t->_errorWrongEquation((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 8: _t->comboboxAddItem((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 9: _t->comboboxRevmoveItem((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 10: _t->on_comboBoxTopLeft_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 11: _t->on_comboBoxTopRight_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 12: _t->on_comboBoxBottomLeft_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 13: _t->on_comboBoxBottomRight_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->on_comboBoxTopMiddle_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->on_comboBoxMiddle_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->on_comboBoxBottomMiddle_currentIndexChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->_received_errorWrongEquation((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxTopLeft_currentIndexWasChanged)) {
                *result = 0;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxTopRight_currentIndexWasChanged)) {
                *result = 1;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxBottomLeft_currentIndexWasChanged)) {
                *result = 2;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxBottomRight_currentIndexWasChanged)) {
                *result = 3;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxTopMiddle_currentIndexWasChanged)) {
                *result = 4;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxMiddle_currentIndexWasChanged)) {
                *result = 5;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_comboBoxBottomMiddle_currentIndexWasChanged)) {
                *result = 6;
            }
        }
        {
            typedef void (SettingTriggerFunction::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingTriggerFunction::_errorWrongEquation)) {
                *result = 7;
            }
        }
    }
}

const QMetaObject SettingTriggerFunction::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_SettingTriggerFunction.data,
      qt_meta_data_SettingTriggerFunction,  qt_static_metacall, 0, 0}
};


const QMetaObject *SettingTriggerFunction::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SettingTriggerFunction::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SettingTriggerFunction.stringdata))
        return static_cast<void*>(const_cast< SettingTriggerFunction*>(this));
    return QFrame::qt_metacast(_clname);
}

int SettingTriggerFunction::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 18)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 18;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 18)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 18;
    }
    return _id;
}

// SIGNAL 0
void SettingTriggerFunction::_comboBoxTopLeft_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SettingTriggerFunction::_comboBoxTopRight_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SettingTriggerFunction::_comboBoxBottomLeft_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SettingTriggerFunction::_comboBoxBottomRight_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SettingTriggerFunction::_comboBoxTopMiddle_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SettingTriggerFunction::_comboBoxMiddle_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SettingTriggerFunction::_comboBoxBottomMiddle_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SettingTriggerFunction::_errorWrongEquation(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}
QT_END_MOC_NAMESPACE
