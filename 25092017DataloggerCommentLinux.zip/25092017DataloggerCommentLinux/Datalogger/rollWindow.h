#ifndef ROLLWINDOW_H
#define ROLLWINDOW_H

/**
  * \file rollWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief windows for the Roll menu
  */

#include <QWidget>
#include <QElapsedTimer>

#include "commonStyle.h"
#include "dataFrameSimulator.h"
#include "globalEnumatedAndExtern.h"

namespace Ui {
class RollWindow;
}

class RollWindow : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn explicit RollWindow(QWidget *parent = 0)
      * \brief constructor for RollWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit RollWindow(QWidget *parent = 0);

    /**
      * \fn  ~RollWindow()
      * \brief destructor for RollWindow
      */
    ~RollWindow();

    //direction du draw
    // if true, draw left to right, mode roll on
    // if flase, draw right to left, mode trig
    /**
      * \fn void setDrawRightToLeft(bool drawRightToLeft)
      * \brief Use to set the direction of the plotting
      * \param[in] drawRightToLeft if is true , the direction is right to left "Roll on", false is reversed "Trig"
      * \return void : nothing
      */
    void setDrawRightToLeft(bool drawRightToLeft);

    //dimention of plot
    /**
      * \fn void setSizeOfPlots(int valuePixels)
      * \brief Setter for valuePixels attribute, it's the maximum value
      * \param[in] valuePixels is the width of the plot
      * \return void : nothing
      */
    void setSizeOfPlot(int valuePixels);

    // update the plot
    /**
      * \fn void refreshPlot()
      * \brief Use to update the value in the plot
      * \return void : nothing
      */
    void refreshPlot();

private:
    Ui::RollWindow *ui;

    //key value for Trace label name
    QMap<int, QString> _TriggerTracePossible;

    /**
      * \fn void _setAllTraceName()
      * \brief set the name of all widget traces
      * \return void : nothing
      */
    void _setAllTraceName();

    /**
      * \fn  void _hideAllTrace()
      * \brief hide all widget trace
      * \return void : nothing
      */
    void _hideAllTrace();
    DataFrame *_memoDataFrame;

    //style
    //QPalette _palette;
    //CommonStyle _myStyle;
    QElapsedTimer _timerElapse;
    //void setupStyle();

    /**
      * \fn  _addValueDI1_8(quint8 value)
      * \brief add the value in trace plot
      * \param[in] value is the value in data to split to the digital plot DI1 to DI8
      * \return void : nothing
      */
    void _addValueDI1_8(quint8 value);

    /**
      * \fn  _addValueDI9_16(quint8 value)
      * \brief add the value in trace plot
      * \param[in] value is the value in data to split to the digital plot DI9 to DI16
      * \return void : nothing
      */
    void _addValueDI9_16(quint8 value);

    /**
      * \fn  _changeBrackgroudColorLabelTrace()
      * \brief change the backgroudcolor according with the value only for digital plot
      * grey for value 0
      * green for digital with value 1
      * red for tigger plot with value 1
      * \return void : nothing
      */
    void _changeBrackgroudColorLabelTrace();

    /**
      * \fn void updatePlot()
      * \brief Use to update all the selected plot
      * \return void : nothing
      */
    void _updateAllPlot();

public slots:
    void addTrace(quint8 enumTrace);
    void hideTrace(quint8 enumTrace);

    void addNewDataFrame(DataFrame *newDataFrame);
    void setRangePlotAI1(QString rangeTXT);
    void setRangePlotAI2(QString rangeTXT);
    void setRangePlotAI3(QString rangeTXT);
    void setRangePlotAI4(QString rangeTXT);

};

#endif // ROLLWINDOW_H
