#ifndef TRIGGERFUNCTIONS_H
#define TRIGGERFUNCTIONS_H

#include <QDebug>
#include "globalEnumatedAndExtern.h"
#include "dataFrame.h"

/**
  * \file triggerFunctions.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief object for evaluate the trigger equation
  *
  * [A]---logic operator---[B]
  * ------logic operator------
  * [C]---logic operator---[D]
  *
  */

/**
  * \def DIGITAL_MIN_VALUE
  * \brief preprocessor symbol for DIGITAL_MIN_VALUE
  *
  * This symbol is to set the minimum value of a digital trace, use for the trig function calculation
  */
#define DIGITAL_MIN_VALUE 0

/**
  * \def DIGITAL_MAX_VALUE
  * \brief preprocessor symbol for DIGITAL_MAX_VALUE
  *
  * This symbol is to set the maximum value of a digital trace, use for the trig function calculation
  */
#define DIGITAL_MAX_VALUE 1

/**
  * \def ANALOG_MIN_VALUE
  * \brief preprocessor symbol for ANALOG_MIN_VALUE
  *
  * This symbol is to set the minimum value of a analogic trace, use for the trig function calculation
  */
#define ANALOG_MIN_VALUE 0

/**
  * \def ANALOG_MAX_VALUE
  * \brief preprocessor symbol for ANALOG_MAX_VALUE
  *
  * This symbol is to set the maximum value of a analogic trace, use for the trig function calculation
  */
#define ANALOG_MAX_VALUE 255

class TriggerFunctions : public QObject
{
    Q_OBJECT

public:
    /**
      * \fn  explicit SettingTriggerFunction(QWidget *parent = 0)
      * \brief constructor for SettingTriggerFunction
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    TriggerFunctions();

    /**
      * \fn  void displayValue()
      * \brief display the value for debug
      * \return void : nothing
      */
    void displayValue();

    /**
      * \fn  GlobalEnumatedAndExtern::eTracePossible traceA() const
      * \brief Getter for traceA attribute
      * \return a eTracePossible
      */
    GlobalEnumatedAndExtern::eTracePossible traceA() const;

    /**
      * \fn  void setTraceA(const GlobalEnumatedAndExtern::eTracePossible &traceA)
      * \brief Setter for traceA attribute
      * \param[in] traceA is signal use for the value A in equation
      * \return void : nothing
      */
    void setTraceA(const GlobalEnumatedAndExtern::eTracePossible &traceA);

    /**
      * \fn  GlobalEnumatedAndExtern::eTracePossible traceB() const
      * \brief Getter for traceB attribute
      * \return a eTracePossible
      */
    GlobalEnumatedAndExtern::eTracePossible traceB() const;

    /**
      * \fn  void setTraceB(const GlobalEnumatedAndExtern::eTracePossible &traceB)
      * \brief Setter for traceB attribute
      * \param[in] traceA is signal use for the value B in equation
      * \return void : nothing
      */
    void setTraceB(const GlobalEnumatedAndExtern::eTracePossible &traceB);

    /**
      * \fn  GlobalEnumatedAndExtern::eTracePossible traceC() const
      * \brief Getter for traceC attribute
      * \return a eTracePossible
      */
    GlobalEnumatedAndExtern::eTracePossible traceC() const;

    /**
      * \fn  void setTraceC(const GlobalEnumatedAndExtern::eTracePossible &traceC)
      * \brief Setter for traceC attribute
      * \param[in] traceA is signal use for the value C in equation
      * \return void : nothing
      */
    void setTraceC(const GlobalEnumatedAndExtern::eTracePossible &traceC);

    /**
      * \fn  GlobalEnumatedAndExtern::eTracePossible traceD() const
      * \brief Getter for traceD attribute
      * \return a eTracePossible
      */
    GlobalEnumatedAndExtern::eTracePossible traceD() const;

    /**
      * \fn  void setTraceD(const GlobalEnumatedAndExtern::eTracePossible &traceD)
      * \brief Setter for traceD attribute
      * \param[in] traceA is signal use for the value D in equation
      * \return void : nothing
      */
    void setTraceD(const GlobalEnumatedAndExtern::eTracePossible &traceD);

    /**
      * \fn  GlobalEnumatedAndExtern::eLogicOperator logicalOperator_Top() const
      * \brief Getter for logicalOperator_Top attribute
      * \return a eLogicOperator
      */
    GlobalEnumatedAndExtern::eLogicOperator logicalOperator_Top() const;

    /**
      * \fn  void setLogicalOperator_Top(const GlobalEnumatedAndExtern::eLogicOperator &logicalOperator_Top)
      * \brief Setter for logicalOperator_Top attribute
      * \param[in] logicalOperator_Top is logical operator beetween trace A and B
      * \return void : nothing
      */
    void setLogicalOperator_Top(const GlobalEnumatedAndExtern::eLogicOperator &logicalOperator_Top);

    /**
      * \fn  GlobalEnumatedAndExtern::eLogicOperator logicalOperator_Middle() const
      * \brief Getter for logicalOperator_Middle attribute
      * \return a eLogicOperator
      */
    GlobalEnumatedAndExtern::eLogicOperator logicalOperator_Middle() const;

    /**
      * \fn  void setLogicalOperator_Middle(const GlobalEnumatedAndExtern::eLogicOperator &logicalOperator_Middle)
      * \brief Setter for logicalOperator_Middle attribute
      * \param[in] logicalOperator_Middle is logical center operator
      * \return void : nothing
      */
    void setLogicalOperator_Middle(const GlobalEnumatedAndExtern::eLogicOperator &logicalOperator_Middle);

    /**
      * \fn  GlobalEnumatedAndExtern::eLogicOperator logicalOperator_Bottom() const
      * \brief Getter for logicalOperator_Bottom attribute
      * \return a eLogicOperator
      */
    GlobalEnumatedAndExtern::eLogicOperator logicalOperator_Bottom() const;

    /**
      * \fn  void setLogicalOperator_Bottom(const GlobalEnumatedAndExtern::eLogicOperator &logicalOperator_Bottom)
      * \brief Setter for logicalOperator_Bottom attribute
      * \param[in] logicalOperator_Bottom is logical operator beetween trace C and D
      * \return void : nothing
      */
    void setLogicalOperator_Bottom(const GlobalEnumatedAndExtern::eLogicOperator &logicalOperator_Bottom);


    /**
      * \fn  bool onTrig(DataFrame *data)
      * \brief return the trigger status of the equation after evaluation
      * \param[in] data is frame to evaluate
      * \return a boolean
      */
    bool onTrig(DataFrame *data);

    /**
      * \fn  GlobalEnumatedAndExtern::eEdge btDI1Edge() const
      * \brief Getter for btDI1Edge attribute
      * \return a eEdge
      */
    GlobalEnumatedAndExtern::eEdge btDI1Edge() const;

    /**
      * \fn  void setBtDI1Edge(const GlobalEnumatedAndExtern::eEdge &btDI1Edge)
      * \brief Setter for btDI1Edge attribute
      * \param[in] btDI1Edge is selected edge for trace DI1
      * \return void : nothing
      */
    void setBtDI1Edge(const GlobalEnumatedAndExtern::eEdge &btDI1Edge);

    /**
      * \fn  GlobalEnumatedAndExtern::eEdge btDI2Edge() const
      * \brief Getter for btDI2Edge attribute
      * \return a eEdge
      */
    GlobalEnumatedAndExtern::eEdge btDI2Edge() const;

    /**
      * \fn  void setBtDI2Edge(const GlobalEnumatedAndExtern::eEdge &btDI2Edge)
      * \brief Setter for btDI2Edge attribute
      * \param[in] btDI2Edge is selected edge for trace DI2
      * \return void : nothing
      */
    void setBtDI2Edge(const GlobalEnumatedAndExtern::eEdge &btDI2Edge);

    /**
      * \fn  GlobalEnumatedAndExtern::eEdge btDI3Edge() const
      * \brief Getter for btDI3Edge attribute
      * \return a eEdge
      */
    GlobalEnumatedAndExtern::eEdge btDI3Edge() const;

    /**
      * \fn  void setBtDI3Edge(const GlobalEnumatedAndExtern::eEdge &btDI3Edge)
      * \brief Setter for btDI3Edge attribute
      * \param[in] btDI3Edge is selected edge for trace DI3
      * \return void : nothing
      */
    void setBtDI3Edge(const GlobalEnumatedAndExtern::eEdge &btDI3Edge);

    /**
      * \fn  GlobalEnumatedAndExtern::eEdge btDI4Edge() const
      * \brief Getter for btDI4Edge attribute
      * \return a eEdge
      */
    GlobalEnumatedAndExtern::eEdge btDI4Edge() const;

    /**
      * \fn  void setBtDI4Edge(const GlobalEnumatedAndExtern::eEdge &btDI4Edge)
      * \brief Setter for btDI4Edge attribute
      * \param[in] btDI4Edge is selected edge for trace DI4
      * \return void : nothing
      */
    void setBtDI4Edge(const GlobalEnumatedAndExtern::eEdge &btDI4Edge);

    /**
      * \fn  GlobalEnumatedAndExtern::eEdge btAI1Edge() const
      * \brief Getter for btAI1Edge attribute
      * \return a eEdge
      */
    GlobalEnumatedAndExtern::eEdge btAI1Edge() const;

    /**
      * \fn  void setBtAI1Edge(const GlobalEnumatedAndExtern::eEdge &btAI1Edge)
      * \brief Setter for btAI1Edge attribute
      * \param[in] btAI1Edge is selected edge for trace AI1
      * \return void : nothing
      */
    void setBtAI1Edge(const GlobalEnumatedAndExtern::eEdge &btAI1Edge);

    /**
      * \fn  GlobalEnumatedAndExtern::eEdge btAI2Edge() const
      * \brief Getter for btAI2Edge attribute
      * \return a eEdge
      */
    GlobalEnumatedAndExtern::eEdge btAI2Edge() const;

    /**
      * \fn  void setBtAI2Edge(const GlobalEnumatedAndExtern::eEdge &btAI2Edge)
      * \brief Setter for btAI2Edge attribute
      * \param[in] btAI2Edge is selected edge for trace AI2
      * \return void : nothing
      */
    void setBtAI2Edge(const GlobalEnumatedAndExtern::eEdge &btAI2Edge);

    /**
      * \fn  quint8 doubleSpinBoxDI1() const
      * \brief Getter for doubleSpinBoxDI1 attribute
      * \return a quint8
      */
    quint8 doubleSpinBoxDI1() const;

    /**
      * \fn  void setDoubleSpinBoxDI1(quint8 doubleSpinBoxDI1)
      * \brief Setter for doubleSpinBoxDI1 attribute
      * \param[in] doubleSpinBoxDI1 is value in the doublespinbox
      * \return void : nothing
      */
    void setDoubleSpinBoxDI1(quint8 doubleSpinBoxDI1);

    /**
      * \fn  quint8 doubleSpinBoxDI2() const
      * \brief Getter for doubleSpinBoxDI2 attribute
      * \return a quint8
      */
    quint8 doubleSpinBoxDI2() const;

    /**
      * \fn  void setDoubleSpinBoxDI2(quint8 doubleSpinBoxDI2)
      * \brief Setter for doubleSpinBoxDI2 attribute
      * \param[in] doubleSpinBoxDI2 is value in the doublespinbox
      * \return void : nothing
      */
    void setDoubleSpinBoxDI2(quint8 doubleSpinBoxDI2);

    /**
      * \fn  quint8 doubleSpinBoxDI3() const
      * \brief Getter for doubleSpinBoxDI3 attribute
      * \return a quint8
      */
    quint8 doubleSpinBoxDI3() const;

    /**
      * \fn  void setDoubleSpinBoxDI3(quint8 doubleSpinBoxDI3)
      * \brief Setter for doubleSpinBoxDI3 attribute
      * \param[in] doubleSpinBoxDI3 is value in the doublespinbox
      * \return void : nothing
      */
    void setDoubleSpinBoxDI3(quint8 doubleSpinBoxDI3);

    /**
      * \fn  quint8 doubleSpinBoxDI4() const
      * \brief Getter for doubleSpinBoxDI4 attribute
      * \return a quint8
      */
    quint8 doubleSpinBoxDI4() const;

    /**
      * \fn  void setDoubleSpinBoxDI4(quint8 doubleSpinBoxDI4)
      * \brief Setter for doubleSpinBoxDI4 attribute
      * \param[in] doubleSpinBoxDI4 is value in the doublespinbox
      * \return void : nothing
      */
    void setDoubleSpinBoxDI4(quint8 doubleSpinBoxDI4);

    /**
      * \fn  quint8 doubleSpinBoxAI1() const
      * \brief Getter for doubleSpinBoxAI1 attribute
      * \return a quint8
      */
    quint8 doubleSpinBoxAI1() const;

    /**
      * \fn  void setDoubleSpinBoxAI1(quint8 doubleSpinBoxAI1)
      * \brief Setter for doubleSpinBoxAI1 attribute
      * \param[in] doubleSpinBoxAI1 is value in the doublespinbox
      * \return void : nothing
      */
    void setDoubleSpinBoxAI1(quint8 doubleSpinBoxAI1);

    /**
      * \fn  quint8 doubleSpinBoxAI2() const
      * \brief Getter for doubleSpinBoxAI2 attribute
      * \return a quint8
      */
    quint8 doubleSpinBoxAI2() const;

    /**
      * \fn  void setDoubleSpinBoxAI2(quint8 doubleSpinBoxAI2)
      * \brief Setter for setDoubleSpinBoxAI2 attribute
      * \param[in] setDoubleSpinBoxAI2 is value in the doublespinbox
      * \return void : nothing
      */
    void setDoubleSpinBoxAI2(quint8 doubleSpinBoxAI2);

    /**
      * \fn   bool onTrigStatus() const
      * \brief Getter for onTrigStatus attribute
      * \return a boolean
      */
    bool onTrigStatus() const;

private:

    bool _onTrigStatus;

    quint16 _valueFunction;

    /**
      * \fn  void _setValueFunction()
      * \brief use to set the value of the trig equation accroding the setting done with the application
      * \return void : nothing
      */
    void _setValueFunction();

    /**
      * \fn  bool _checkValideEquation()
      * \brief use to check if the equation is valide, if not, a signal will be emit.
      * \return a boolean
      */
    bool _checkValideEquation();

    /**
      * \fn      quint8 _checkOnTrigTrace(quint8 trace, quint8 memoTrace,
      *                 GlobalEnumatedAndExtern::eEdge edge, quint8 minValue,
      *                 quint8 maxValue, quint8 trigValue)
      *
      * \brief use to valiate the trig of one channel , return a '1' if on trig or '0' if not trig
      * \param[in] trace is the channel to check
      * \param[in] memoTrace is the value before of the channel to check
      * \param[in] edge is the type of edge choosed on the application
      * \param[in] minValue is the minimum value for the channel
      * \param[in] maxValue is the maximum value for the channel
      * \param[in] trigValue is the trigger value set on the application, use for the analog channel
      * \return a boolean
      */
    quint8 _checkOnTrigTrace(quint8 trace, quint8 memoTrace, GlobalEnumatedAndExtern::eEdge edge, quint8 minValue, quint8 maxValue, quint8 trigValue);

    GlobalEnumatedAndExtern::eTracePossible _traceA;
    GlobalEnumatedAndExtern::eTracePossible _traceB;
    GlobalEnumatedAndExtern::eTracePossible _traceC;
    GlobalEnumatedAndExtern::eTracePossible _traceD;

    GlobalEnumatedAndExtern::eLogicOperator _logicalOperator_Top;
    GlobalEnumatedAndExtern::eLogicOperator _logicalOperator_Middle;
    GlobalEnumatedAndExtern::eLogicOperator _logicalOperator_Bottom;

    //state of edge
    GlobalEnumatedAndExtern::eEdge _btDI1Edge;
    GlobalEnumatedAndExtern::eEdge _btDI2Edge;
    GlobalEnumatedAndExtern::eEdge _btDI3Edge;
    GlobalEnumatedAndExtern::eEdge _btDI4Edge;
    GlobalEnumatedAndExtern::eEdge _btAI1Edge;
    GlobalEnumatedAndExtern::eEdge _btAI2Edge;

    //doubleSpinBox value
    quint8 _doubleSpinBoxDI1;
    quint8 _doubleSpinBoxDI2;
    quint8 _doubleSpinBoxDI3;
    quint8 _doubleSpinBoxDI4;
    quint8 _doubleSpinBoxAI1;
    quint8 _doubleSpinBoxAI2;

    //minimum Value of trace in pulse
    quint8 _minValueTraceA;
    quint8 _minValueTraceB;
    quint8 _minValueTraceC;
    quint8 _minValueTraceD;

    //maximum Value of trace in pulse
    quint8 _maxValueTraceA;
    quint8 _maxValueTraceB;
    quint8 _maxValueTraceC;
    quint8 _maxValueTraceD;

    //trig value
    quint8 _trigValueTraceA;
    quint8 _trigValueTraceB;
    quint8 _trigValueTraceC;
    quint8 _trigValueTraceD;

    //analysed frame
    DataFrame *_newFrame;
    DataFrame *_memoFrame;

signals:
   void _errorWrongEquation(quint8 errorNumber,bool active);
};

#endif // TRIGGERFUNCTIONS_H
