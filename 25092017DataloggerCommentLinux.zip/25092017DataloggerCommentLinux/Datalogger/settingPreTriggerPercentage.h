#ifndef SETTINGPRETRIGGERPERCENTAGE_H
#define SETTINGPRETRIGGERPERCENTAGE_H

/**
  * \file settingPreTriggerPercentage.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Frame in setting menu for the pre trigger percentage setting
  */

#include <QFrame>
#include <QDebug>
#include "commonStyle.h"


namespace Ui {
class SettingPreTriggerPercentage;
}

class SettingPreTriggerPercentage : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn  explicit SettingPreTriggerPercentage(QWidget *parent = 0)
      * \brief constructor for SettingPreTriggerPercentage
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit SettingPreTriggerPercentage(QWidget *parent = 0);

    /**
      * \fn  ~SettingPreTriggerPercentage()
      * \brief destructor for SettingPreTriggerPercentage
      */
    ~SettingPreTriggerPercentage();

    /**
      * \fn  void setMaximumRange(const quint16 &maximumRange)
      * \brief Setter for maximumRange attribute
      * \param[in] maximumRange is the maximum saving time
      * \return void : nothing
      */
    void setMaximumRange(const quint16 &maximumRange);

    /**
      * \fn  void setStepOnClick(const quint8 &stepOnClick)
      * \brief Setter for stepOnClick attribute
      * \param[in] stepOnClick is the step when clic on the side flow
      * \return void : nothing
      */
    void setStepOnClick(const quint8 &stepOnClick);

private:
    Ui::SettingPreTriggerPercentage *ui;

    /**
      * \fn  void setupStyle()
      * \brief use to set the style of this object.
      * \return void : nothing
      */
    void setupStyle();

    //maximum reccord time
    quint16 _maximumRange;

    //step for one click
    quint8 _stepOnClick;

private slots:
    void on_spinBoxTimeBeforeTrig_valueChanged(int arg1);
    void on_spinBoxTimeAfterTrig_valueChanged(int arg1);

signals:
    void _percentPreTriggerWasChanged(double percent);

};

#endif // SETTINGPRETRIGGERPERCENTAGE_H
